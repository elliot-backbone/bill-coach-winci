# Bill Jennings Coach — install

BILL: drag this zip (or this folder) into Claude Code and say "install coach". That's it. The rest of this file is for the assistant doing the install.

---

## [M2M — instructions for the installing assistant]

CONTEXT: Bill Jennings asked you to install Coach, his private coach for the move into venture-backed startups, built for him by Elliot. This package is self-contained and hash-locked. Do not edit any file in it. Do not read plugin internals into the conversation; install and hand over. Bill is not technical: plain warm language, no jargon, never show him raw commands unless something fails.

STEPS (execute in order):
0. ASK FIRST (one short consent message before doing anything): tell Bill you are about to (a) extract the package to his home folder, (b) install Coach into its own sealed profile at `~/.claude-bill-career-coach` (Windows: `%USERPROFILE%\.claude-bill-career-coach`), (c) put a `coach` command on his PATH (macOS: may add one line to his shell profile; Windows: adds one folder to his user PATH), and (d) open Coach automatically when done — and that first launch will ask for a one-time Claude sign-in in the browser. Proceed on his yes; stop on anything else.
1. LOCATE: if you are reading this from inside a zip listing, extract first, then `cd` into the extracted folder that contains this INSTALL.md and `manifest.json`. If Bill dropped an already-extracted folder, `cd` into it.
   - macOS: `unzip -q "<zip path>" -d "$HOME/bill-coach"`
   - Windows (PowerShell): `Expand-Archive -Path "<zip path>" -DestinationPath "$HOME\bill-coach" -Force`
2. PRECHECK (the installer enforces these; checking first gives better messages):
   - `node --version` → must be >= 24.0.0. If missing/old: install current Node LTS from nodejs.org, then re-run. Offer to handle this for him. On Windows the winget route is `winget install OpenJS.NodeJS.LTS`, then open a NEW PowerShell window so PATH refreshes.
   - `claude --version` → Claude Code must be on PATH, >= 2.1.0. If missing: `npm install -g @anthropic-ai/claude-code`.
3. INSTALL: run `node install/install.mjs` from the package folder.
   Output is exactly one line: `installed` | `already current` | `upgraded` | `repaired (<what>)` | `failed: <reason>`.
   The installer validates every file hash, verifies both databases, probes the runtime, installs atomically, and puts the `coach` launcher on PATH. NOTE: it will refuse to install if a program named `coach` already exists on his PATH — if that happens, tell Bill plainly and stop; Elliot will advise.
   WINDOWS PATH: the installer writes the PATH change to his user environment. It does NOT affect windows that are already open — step 4 must open a NEW PowerShell window, or `coach` will look missing when it is installed correctly.
3b. ON `repaired (...)`: this means Coach had been uninstalled or half-removed here and the installer put the code and configuration back over his existing memory. Nothing is lost unless the line says Coach starts fresh. Continue to step 4 exactly as for `installed`.
4. ON `installed` (or `repaired`): AUTO-LAUNCH Coach in a new window so onboarding starts by itself:
   - macOS: `open -a Terminal "$(command -v coach || echo "$HOME/.local/bin/coach")"`
   - Windows: `Start-Process powershell.exe -ArgumentList '-NoExit','-Command','coach'`. On Windows 11 `Start-Process wt.exe -ArgumentList 'powershell -NoExit -Command coach'` gives a nicer window; fall back to the plain PowerShell form if Windows Terminal is absent. Do NOT use cmd.exe — say PowerShell to Bill, because that is the app name he can find in the Start menu on both Windows 10 and 11.
   - If auto-launch fails, tell Bill: open a new PowerShell window and type `coach`.
   - Either way, tell him warmly: first launch asks for a one-time Claude sign-in in the browser (he needs his own paid Claude account); then Coach introduces itself; onboarding is seven short panes — minutes, not hours — and then it's straight to work.
5. ON `failed: <reason>`: show Bill the reason in plain language and the fix (Node LTS / `claude update` / the coach-name collision above / move aside a conflicting `~/.claude-bill-career-coach` directory). Never work around the installer; it is the only supported path.
6. WINDOWS SANITY CHECK (run once, after step 4, from a NEW PowerShell window): `node install/verify-install.mjs`. It prints `ok` or a specific `failed: <reason>`. Report the result to Bill in plain language.

NOTES:
- Everything runs and stays local on Bill's machine: memory, his funnel, every document. Only model inference (and Coach's read-only web research) leaves it. Coach never sends anything on his behalf.
- Uninstall: `node install/uninstall.mjs` from this package folder.
