#!/usr/bin/env node
// Bill Jennings Coach — installer.
//
// Run from the extracted package:  node install/install.mjs
// Prints exactly one line on stdout:
//   installed | already current | upgraded | repaired (<what>) | failed: <reason>
//
// The package root (one directory above this file) must contain:
//   manifest.json  install/  launcher/  plugin/  library/library.sqlite  state-template/
//
// Installed layout (everything derives from $BILL_COACH_HOME, default $HOME):
//   ~/.claude-bill-career-coach/                       CLAUDE_CONFIG_DIR (sealed profile)
//     settings.json                                     rendered sealed-settings.template.json
//     workspace/                                        cwd for the coach session
//     mcp/coach-mcp.json                                rendered sealed-mcp.template.json
//     skills/bill-career-coach -> plugin dir           skills-dir plugin discovery entry
//     plugins/data/bill-career-coach-skills-dir/       plugin code (immutable per version)
//       library/library.sqlite                          immutable bundled library
//       state/coach.sqlite                              durable user state
//       state_meta/app.json                             installed version marker
//       backups/  tmp/
//
// This file is also the shared library for upgrade.mjs and uninstall.mjs.
// No dependencies. Node >= 24.0.0 (node:sqlite with FTS5).

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawn, spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

export const APP_NAME = 'bill-career-coach';
export const PROFILE_DIR_NAME = '.claude-bill-career-coach';
export const PLUGIN_DATA_DIR_NAME = 'bill-career-coach-skills-dir';
export const LAUNCHER_NAME = 'coach';
// Node 22.13's bundled SQLite (3.47.2) has no FTS5 module on ANY platform, and
// the coach runtime's search depends on it. FTS5 arrives with Node 24 (SQLite
// 3.53.1). Verified across linux/darwin/win32 on 22.13, 24.x and 26.x.
export const MIN_NODE = '24.0.0';
export const MIN_CLAUDE = '2.1.0';
export const PATH_BLOCK_BEGIN = '# bill-coach PATH >>>';
export const PATH_BLOCK_END = '# bill-coach PATH <<<';
export const IS_WINDOWS = process.platform === 'win32';
export const PURGE_PHRASE = 'delete bill coach memory';
// Top-level entries of plugin/ that are versioned code, replaced on upgrade.
export const CODE_ENTRIES = ['.claude-plugin', 'skills', 'hooks', '.mcp.json', 'coach', 'lenses', 'runtime'];
export const EXPECTED_TOOLS = ['bill_command', 'end_coach', 'get_context', 'inspect_memory', 'save_coaching_state', 'search_library', 'search_state', 'start_coach', 'sync_source', 'update_state'];
const REQUIRED_MEMBERS = [
  'install/install.mjs',
  'install/upgrade.mjs',
  'install/uninstall.mjs',
  'install/verify-install.mjs',
  'launcher/coach.mjs',
  'launcher/sealed-settings.template.json',
  'launcher/sealed-mcp.template.json',
  'plugin/.claude-plugin/plugin.json',
  'plugin/runtime/server.mjs',
  'library/library.sqlite',
  'state-template/coach.sqlite',
];

// ---------------------------------------------------------------- paths

export function coachHome() {
  return process.env.BILL_COACH_HOME || os.homedir();
}

export function coachPaths(home = coachHome()) {
  const profile = path.join(home, PROFILE_DIR_NAME);
  const pluginDir = path.join(profile, 'plugins', 'data', PLUGIN_DATA_DIR_NAME);
  return {
    home,
    profile,
    settings: path.join(profile, 'settings.json'),
    workspace: path.join(profile, 'workspace'),
    mcpDir: path.join(profile, 'mcp'),
    mcpConfig: path.join(profile, 'mcp', 'coach-mcp.json'),
    skillsDir: path.join(profile, 'skills'),
    skillsLink: path.join(profile, 'skills', APP_NAME),
    pluginDir,
    serverEntry: path.join(pluginDir, 'runtime', 'server.mjs'),
    libraryDb: path.join(pluginDir, 'library', 'library.sqlite'),
    stateDir: path.join(pluginDir, 'state'),
    stateDb: path.join(pluginDir, 'state', 'coach.sqlite'),
    stateMetaDir: path.join(pluginDir, 'state_meta'),
    marker: path.join(pluginDir, 'state_meta', 'app.json'),
    backups: path.join(pluginDir, 'backups'),
    tmp: path.join(pluginDir, 'tmp'),
  };
}

// ---------------------------------------------------------------- small utils

export function versionCompare(a, b) {
  const pa = String(a).split('.').map((n) => parseInt(n, 10) || 0);
  const pb = String(b).split('.').map((n) => parseInt(n, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i += 1) {
    const d = (pa[i] ?? 0) - (pb[i] ?? 0);
    if (d !== 0) return d < 0 ? -1 : 1;
  }
  return 0;
}

export function sha256File(p) {
  return crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
}

// SQLite writes -wal/-shm/-journal beside a database. They are volatile, machine-local
// and meaningless outside the process that made them: never shipped, never copied,
// never validated. A stray one in the package directory is ignored, not an error.
export function isSqliteSidecar(name) {
  return /\.sqlite(-wal|-shm|-journal)$/.test(name);
}

export class InstallError extends Error {}

function fail(reason) {
  throw new InstallError(reason);
}

function randSuffix() {
  return crypto.randomBytes(5).toString('hex');
}

/** Substitute __TOKEN__ placeholders with JSON-escaped values in raw JSON text. */
export function renderTemplate(text, subs) {
  let out = text;
  for (const [token, value] of Object.entries(subs)) {
    out = out.split(token).join(JSON.stringify(String(value)).slice(1, -1));
  }
  if (/__[A-Z0-9_]+__/.test(out)) fail(`template still contains unsubstituted placeholders`);
  JSON.parse(out); // must be valid JSON after substitution
  return out;
}

async function openDb(dbPath, options) {
  const { DatabaseSync } = await import('node:sqlite');
  return new DatabaseSync(dbPath, options);
}

export async function integrityCheck(dbPath) {
  let db;
  try {
    db = await openDb(dbPath, { readOnly: true });
    const row = db.prepare('PRAGMA integrity_check').get();
    const value = row ? Object.values(row)[0] : null;
    if (value !== 'ok') fail(`integrity check failed for ${dbPath}: ${value}`);
  } catch (err) {
    if (err instanceof InstallError) throw err;
    fail(`cannot verify database ${dbPath}: ${err.message}`);
  } finally {
    try { db?.close(); } catch { /* already closed */ }
  }
}

export async function readStateSchemaVersion(dbPath) {
  let db;
  try {
    db = await openDb(dbPath, { readOnly: true });
    const row = db.prepare(`SELECT value FROM state_meta WHERE key = 'schema_version'`).get();
    if (!row) fail(`state database ${dbPath} has no schema_version`);
    return parseInt(row.value, 10);
  } catch (err) {
    if (err instanceof InstallError) throw err;
    fail(`cannot read schema version from ${dbPath}: ${err.message}`);
  } finally {
    try { db?.close(); } catch { /* already closed */ }
  }
  return 0; // unreachable
}

// ---------------------------------------------------------------- platform layer
//
// Windows differs from macOS/Linux in four ways that matter here:
//   1. executability comes from the file extension (PATHEXT), not a mode bit;
//   2. a `#!` shebang is not honoured, so the launcher needs a .cmd shim;
//   3. PATH persists in the user Environment registry key, not a shell rc file;
//   4. directory symlinks need elevation, but junctions do not.
// Everything below is the single place those differences are expressed.

/** Executable extensions, lowercased, in PATHEXT order. Empty on POSIX. */
export function pathExtensions() {
  if (!IS_WINDOWS) return [''];
  const raw = process.env.PATHEXT || '.COM;.EXE;.BAT;.CMD';
  return raw.split(';').map((e) => e.trim().toLowerCase()).filter(Boolean);
}

/** Every filename a bare command could resolve to in one directory. */
export function commandCandidates(dir, name) {
  if (!IS_WINDOWS) return [path.join(dir, name)];
  return pathExtensions().map((ext) => path.join(dir, `${name}${ext}`));
}

/** The launcher's on-disk filename: a .cmd shim on Windows, the script itself elsewhere. */
export function launcherFileName() {
  return IS_WINDOWS ? `${LAUNCHER_NAME}.cmd` : LAUNCHER_NAME;
}

/**
 * spawn/spawnSync options for a resolved binary. Node refuses to execute .cmd and
 * .bat files without a shell (CVE-2024-27980), which is exactly what `claude` is
 * on Windows, so those need shell:true.
 */
export function spawnOptionsFor(bin, base = {}) {
  if (IS_WINDOWS && /\.(cmd|bat)$/i.test(bin)) return { ...base, shell: true };
  return base;
}

/** Quote one argument for cmd.exe. */
function cmdQuote(s) {
  return /[\s"&|<>^()]/.test(String(s)) ? `"${String(s).replace(/"/g, '""')}"` : String(s);
}

/**
 * Build a single command string for cmd.exe. Node 24 deprecates passing an args
 * array alongside shell:true (DEP0190) because it concatenates without escaping,
 * so we do the quoting ourselves and hand the shell one string.
 */
export function shellCommandFor(bin, args = []) {
  return [cmdQuote(bin), ...args.map(cmdQuote)].join(' ');
}

/** spawnSync that routes .cmd/.bat through cmd.exe without tripping DEP0190. */
export function spawnSyncCompat(bin, args, opts = {}) {
  if (IS_WINDOWS && /\.(cmd|bat)$/i.test(bin)) {
    return spawnSync(shellCommandFor(bin, args), { ...opts, shell: true });
  }
  return spawnSync(bin, args, opts);
}

/** Directory symlink on POSIX, junction on Windows (no elevation required). */
export function linkDirSync(target, linkPath) {
  fs.symlinkSync(target, linkPath, IS_WINDOWS ? 'junction' : 'dir');
}

/** chmod is meaningless on Windows; skip rather than fail. */
export function chmodIfPosix(p, mode) {
  if (IS_WINDOWS) return;
  fs.chmodSync(p, mode);
}

/** Block the current thread without a dependency. Used only between rm retries. */
function sleepSync(ms) {
  Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms);
}

/**
 * Best-effort recursive delete. Windows refuses to unlink a file another
 * process still holds open and briefly keeps handles alive after that process
 * exits, so a delete that is correct on POSIX can transiently fail there.
 * Retries the Windows-specific error codes, then gives up quietly — the caller
 * is always removing a scratch directory, never something correctness depends on.
 */
export function rmBestEffort(target, { attempts = 12, delayMs = 125 } = {}) {
  const RETRYABLE = new Set(['EBUSY', 'EPERM', 'ENOTEMPTY', 'EACCES', 'EMFILE']);
  for (let i = 0; i < attempts; i += 1) {
    try {
      fs.rmSync(target, { recursive: true, force: true });
      return true;
    } catch (err) {
      if (!RETRYABLE.has(err.code) || i === attempts - 1) return false;
      sleepSync(delayMs);
    }
  }
  return false;
}

/** Read the persisted user PATH. Windows: registry via PowerShell. POSIX: n/a. */
function readWindowsUserPath() {
  const res = spawnSync(
    'powershell.exe',
    ['-NoProfile', '-NonInteractive', '-Command', "[Environment]::GetEnvironmentVariable('Path','User')"],
    { encoding: 'utf8', timeout: 20000 },
  );
  if (res.error || res.status !== 0) return null;
  return String(res.stdout).replace(/\r?\n$/, '');
}

/**
 * Prepend `dir` to the persisted user PATH on Windows. Idempotent. Uses the
 * .NET Environment API rather than `setx`, which silently truncates at 1024
 * characters and would corrupt a long PATH.
 */
export function ensureWindowsPathEntry(dir) {
  const current = readWindowsUserPath();
  if (current === null) fail('could not read your Windows user PATH (PowerShell unavailable)');
  const parts = current.split(';').filter(Boolean);
  const already = parts.some((p) => {
    try { return path.resolve(p).toLowerCase() === path.resolve(dir).toLowerCase(); } catch { return false; }
  });
  if (already) return false;
  const next = [dir, ...parts].join(';');
  const res = spawnSync(
    'powershell.exe',
    ['-NoProfile', '-NonInteractive', '-Command',
      `[Environment]::SetEnvironmentVariable('Path', ${JSON.stringify(next)}, 'User')`],
    { encoding: 'utf8', timeout: 20000 },
  );
  if (res.error || res.status !== 0) fail(`could not update your Windows user PATH: ${res.stderr || 'unknown error'}`);
  return true;
}

/** Remove `dir` from the persisted user PATH on Windows. Idempotent. */
export function removeWindowsPathEntry(dir) {
  const current = readWindowsUserPath();
  if (current === null) return false;
  const parts = current.split(';').filter(Boolean);
  const kept = parts.filter((p) => {
    try { return path.resolve(p).toLowerCase() !== path.resolve(dir).toLowerCase(); } catch { return true; }
  });
  if (kept.length === parts.length) return false;
  spawnSync(
    'powershell.exe',
    ['-NoProfile', '-NonInteractive', '-Command',
      `[Environment]::SetEnvironmentVariable('Path', ${JSON.stringify(kept.join(';'))}, 'User')`],
    { encoding: 'utf8', timeout: 20000 },
  );
  return true;
}

// ---------------------------------------------------------------- environment gates

export async function nodeGate() {
  if (versionCompare(process.versions.node, MIN_NODE) < 0) {
    fail(`Node >= ${MIN_NODE} required (found ${process.versions.node}); install current Node LTS from nodejs.org`);
  }
  let sqlite;
  try {
    sqlite = await import('node:sqlite');
  } catch {
    fail(`this Node build lacks node:sqlite; install standard Node >= ${MIN_NODE} from nodejs.org`);
  }
  // Check the capability, not just the version: a Node built without FTS5 would
  // otherwise sail through here and fail deep inside start_coach with an opaque
  // "internal error", which tells the user nothing they can act on.
  try {
    const probe = new sqlite.DatabaseSync(':memory:');
    try {
      probe.exec('CREATE VIRTUAL TABLE fts5_probe USING fts5(x)');
    } finally {
      probe.close();
    }
  } catch (err) {
    fail(
      `this Node build has no SQLite FTS5 module (${err.message}); coach search requires it. ` +
      `Install Node >= ${MIN_NODE} from nodejs.org and re-run.`
    );
  }
}

export function claudeVersionOf(bin) {
  const res = spawnSyncCompat(bin, ['--version'], { encoding: 'utf8', timeout: 15000 });
  if (res.error || res.status !== 0) return null;
  const m = String(res.stdout).match(/(\d+\.\d+\.\d+)/);
  return m ? m[1] : null;
}

function isExecutableFile(p) {
  try {
    const st = fs.statSync(p);
    if (!st.isFile()) return false;
    // Windows has no exec bit: X_OK succeeds for every readable file, so the
    // extension is the only real signal. Callers pass PATHEXT candidates.
    if (IS_WINDOWS) return pathExtensions().includes(path.extname(p).toLowerCase());
    fs.accessSync(p, fs.constants.X_OK);
    return true;
  } catch {
    return false;
  }
}

function realpathOrNull(p) {
  try { return fs.realpathSync(p); } catch { return null; }
}

/**
 * Find the official claude binary on PATH. `excludeDirs` removes the launcher's
 * own directory so the launcher can never resolve to itself or shadow claude.
 */
export function resolveClaude({ excludeDirs = [] } = {}) {
  const excluded = new Set(excludeDirs.map((d) => realpathOrNull(d)).filter(Boolean));
  for (const entry of (process.env.PATH || '').split(path.delimiter)) {
    if (!entry) continue;
    const real = realpathOrNull(entry);
    if (real && excluded.has(real)) continue;
    for (const candidate of commandCandidates(entry, 'claude')) {
      if (!isExecutableFile(candidate)) continue;
      return { bin: candidate, dir: entry };
    }
  }
  return null;
}

export function claudeGate() {
  const found = resolveClaude();
  if (!found) {
    fail(
      `Claude Code not found on PATH; install it first ` +
      `(see claude.com/claude-code, e.g. \`npm install -g @anthropic-ai/claude-code\`) and re-run`
    );
  }
  const version = claudeVersionOf(found.bin);
  if (!version) fail(`could not determine Claude Code version from ${found.bin}`);
  if (versionCompare(version, MIN_CLAUDE) < 0) {
    fail(`Claude Code >= ${MIN_CLAUDE} required (found ${version}); run \`claude update\` and re-run`);
  }
  return { ...found, version };
}

// ---------------------------------------------------------------- manifest validation

export function packageRootFromInstaller(installerFileUrl) {
  return path.dirname(path.dirname(fileURLToPath(installerFileUrl)));
}

function listPackageFiles(root) {
  const files = [];
  const walk = (rel) => {
    const abs = rel ? path.join(root, rel) : root;
    for (const name of fs.readdirSync(abs)) {
      if (name === '.DS_Store' || name === '__MACOSX') continue;
      if (isSqliteSidecar(name)) continue; // volatile; never declared in the manifest
      const childRel = rel ? `${rel}/${name}` : name;
      const st = fs.lstatSync(path.join(root, childRel));
      if (st.isSymbolicLink()) fail(`package contains a symlink: ${childRel}`);
      if (st.isDirectory()) walk(childRel);
      else if (st.isFile()) files.push({ rel: childRel, mode: st.mode });
      else fail(`package contains an unsupported file type: ${childRel}`);
    }
  };
  walk('');
  return files;
}

/** Validate manifest.json and every shipped file. Returns the parsed manifest. */
export function validatePackage(pkgRoot) {
  const root = realpathOrNull(pkgRoot);
  if (!root) fail(`package directory not found: ${pkgRoot}`);
  const manifestPath = path.join(root, 'manifest.json');
  if (!fs.existsSync(manifestPath)) fail('manifest.json missing from package');
  let manifest;
  try {
    manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
  } catch (err) {
    fail(`manifest.json is not valid JSON: ${err.message}`);
  }
  if (manifest.name !== APP_NAME) fail(`manifest name must be ${APP_NAME}`);
  if (!/^\d+\.\d+\.\d+$/.test(String(manifest.version || ''))) fail('manifest version must be x.y.z');
  if (!Number.isInteger(manifest.schema_version) || manifest.schema_version < 1) {
    fail('manifest schema_version must be a positive integer');
  }
  if (!Array.isArray(manifest.files) || manifest.files.length === 0) fail('manifest files list missing');
  if (manifest.min_node && versionCompare(process.versions.node, manifest.min_node) < 0) {
    fail(`Node >= ${manifest.min_node} required (found ${process.versions.node})`);
  }

  const declared = new Map();
  for (const entry of manifest.files) {
    const rel = entry?.path;
    if (typeof rel !== 'string' || rel.length === 0) fail('manifest file entry without path');
    if (rel.includes('\\') || path.isAbsolute(rel) || rel.split('/').some((s) => s === '..' || s === '' || s === '.')) {
      fail(`manifest path is not a safe relative path: ${rel}`);
    }
    if (!/^[0-9a-f]{64}$/.test(String(entry.sha256 || ''))) fail(`manifest entry has no valid sha256: ${rel}`);
    if (declared.has(rel)) fail(`manifest lists ${rel} twice`);
    declared.set(rel, entry);
  }

  const present = listPackageFiles(root);
  const presentSet = new Set(present.map((f) => f.rel));
  for (const { rel, mode } of present) {
    if (rel === 'manifest.json') continue;
    const entry = declared.get(rel);
    if (!entry) fail(`undeclared file in package: ${rel}`);
    if ((mode & 0o111) !== 0 && entry.executable !== true) fail(`undeclared executable in package: ${rel}`);
    const actual = sha256File(path.join(root, rel));
    if (actual !== entry.sha256) fail(`hash mismatch for ${rel}`);
  }
  for (const rel of declared.keys()) {
    if (!presentSet.has(rel)) fail(`file listed in manifest but missing from package: ${rel}`);
  }
  for (const rel of REQUIRED_MEMBERS) {
    if (!presentSet.has(rel)) fail(`required package member missing: ${rel}`);
  }
  if (manifest.min_claude && versionCompare(manifest.min_claude, MIN_CLAUDE) < 0) {
    fail(`manifest min_claude ${manifest.min_claude} is below the supported floor ${MIN_CLAUDE}`);
  }
  return manifest;
}

// ---------------------------------------------------------------- version marker

export function readMarker(P = coachPaths()) {
  try {
    const marker = JSON.parse(fs.readFileSync(P.marker, 'utf8'));
    if (marker && marker.name === APP_NAME && typeof marker.version === 'string') return marker;
  } catch { /* absent or unreadable -> not installed */ }
  return null;
}

export function writeMarker(P, manifest) {
  fs.mkdirSync(path.dirname(P.marker), { recursive: true });
  const tmp = `${P.marker}.tmp-${randSuffix()}`;
  fs.writeFileSync(tmp, `${JSON.stringify({
    name: APP_NAME,
    version: manifest.version,
    schema_version: manifest.schema_version,
    installed_at: new Date().toISOString(),
  }, null, 2)}\n`);
  fs.renameSync(tmp, P.marker);
}

// ---------------------------------------------------------------- MCP lifecycle probe

/**
 * Spawn runtime/server.mjs over stdio and drive: initialize -> tools/list ->
 * start_coach -> end_coach. Model-free, 10s budget. Verifies protocol-clean
 * stdout (every line is JSON) and exactly the seven declared tools.
 */
export function probeServer(serverPath, dataDir, { timeoutMs = 10000 } = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(process.execPath, [serverPath], {
      env: { ...process.env, BILL_COACH_DATA_DIR: dataDir },
      stdio: ['pipe', 'pipe', 'pipe'],
    });
    let stdoutBuf = '';
    let stderrBuf = '';
    let nextId = 1;
    const pending = new Map();
    let settled = false;

    const settle = (err) => {
      if (err) reject(err instanceof InstallError ? err : new InstallError(`server probe failed: ${err.message}`));
      else resolve();
    };

    const finish = (err) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      // Wait for the child to be genuinely gone before resolving. Windows holds
      // the probe databases locked until the process has exited and its stdio
      // handles are closed, and the caller deletes that directory the moment
      // this resolves — POSIX would happily unlink files that are still open,
      // Windows fails the whole install with EBUSY.
      if (child.exitCode !== null || child.signalCode !== null) { settle(err); return; }
      let done = false;
      let hardTimer = null;
      const finalize = () => {
        if (done) return;
        done = true;
        if (hardTimer) clearTimeout(hardTimer);
        settle(err);
      };
      child.once('close', finalize);
      try {
        child.kill('SIGTERM');
      } catch {
        finalize();
        return;
      }
      // A wedged child must not hang the installer: escalate, then give the OS
      // a moment to release the handles.
      hardTimer = setTimeout(() => {
        try { child.kill('SIGKILL'); } catch { /* gone */ }
        setTimeout(finalize, 250);
      }, 2000);
    };
    const timer = setTimeout(() => {
      finish(new InstallError(`server probe timed out after ${timeoutMs}ms${stderrBuf ? `; stderr: ${stderrBuf.slice(0, 400)}` : ''}`));
    }, timeoutMs);

    const send = (msg) => child.stdin.write(`${JSON.stringify(msg)}\n`);
    const request = (method, params) => new Promise((res, rej) => {
      const id = nextId++;
      pending.set(id, { res, rej });
      send({ jsonrpc: '2.0', id, method, params });
    });

    child.on('error', (err) => finish(new InstallError(`cannot spawn server: ${err.message}`)));
    child.on('exit', (code) => {
      if (!settled) finish(new InstallError(`server exited early (code ${code})${stderrBuf ? `; stderr: ${stderrBuf.slice(0, 400)}` : ''}`));
    });
    child.stderr.on('data', (d) => { stderrBuf += String(d); });
    child.stdout.on('data', (d) => {
      stdoutBuf += String(d);
      let idx;
      while ((idx = stdoutBuf.indexOf('\n')) >= 0) {
        const line = stdoutBuf.slice(0, idx).trim();
        stdoutBuf = stdoutBuf.slice(idx + 1);
        if (!line) continue;
        let msg;
        try {
          msg = JSON.parse(line);
        } catch {
          finish(new InstallError(`server stdout is not protocol-clean JSON: ${line.slice(0, 200)}`));
          return;
        }
        if (msg.id !== undefined && pending.has(msg.id)) {
          const p = pending.get(msg.id);
          pending.delete(msg.id);
          if (msg.error) p.rej(new InstallError(`server returned error for request ${msg.id}: ${msg.error.message || JSON.stringify(msg.error)}`));
          else p.res(msg.result);
        }
        // notifications and unmatched ids are ignored
      }
    });

    const toolResultJson = (result, tool) => {
      if (!result || result.isError) fail(`${tool} probe call failed: ${JSON.stringify(result?.content ?? result).slice(0, 400)}`);
      const text = (result.content || []).find((c) => c && c.type === 'text')?.text;
      if (!text) fail(`${tool} probe call returned no text content`);
      try {
        return JSON.parse(text);
      } catch {
        fail(`${tool} probe call returned non-JSON content`);
      }
      return null; // unreachable
    };

    (async () => {
      const init = await request('initialize', {
        protocolVersion: '2025-06-18',
        capabilities: {},
        clientInfo: { name: 'bill-coach-installer', version: '1.3.2' },
      });
      if (!init || typeof init !== 'object') fail('initialize returned no result');
      send({ jsonrpc: '2.0', method: 'notifications/initialized' });

      const tools = await request('tools/list', {});
      const names = (tools?.tools || []).map((t) => t.name).sort();
      const expected = [...EXPECTED_TOOLS].sort();
      if (JSON.stringify(names) !== JSON.stringify(expected)) {
        fail(`server tools mismatch; expected [${expected.join(', ')}], got [${names.join(', ')}]`);
      }

      const started = toolResultJson(await request('tools/call', {
        name: 'start_coach',
        arguments: { user_message: 'installation verification probe', now: new Date().toISOString() },
      }), 'start_coach');
      const sessionId = started.session_id;
      if (!sessionId) fail('start_coach probe returned no session_id');

      toolResultJson(await request('tools/call', {
        name: 'end_coach',
        arguments: {
          session_id: sessionId,
          expected_session_version: Number.isInteger(started.session_version) ? started.session_version : 1,
          judgment: 'installation verification probe',
          next_move: 'none; installation verification probe',
        },
      }), 'end_coach');
    })().then(() => finish(null), (err) => finish(err));
  });
}

/** Full verification of a plugin tree: db integrity + MCP lifecycle probe on copies. */
export async function verifyPluginTree(pluginDir, { stateDb, libraryDb, scratchParent }) {
  await integrityCheck(libraryDb);
  await integrityCheck(stateDb);
  const probeDir = path.join(scratchParent, `probe-${randSuffix()}`);
  try {
    fs.mkdirSync(path.join(probeDir, 'state'), { recursive: true });
    fs.mkdirSync(path.join(probeDir, 'library'), { recursive: true });
    fs.copyFileSync(stateDb, path.join(probeDir, 'state', 'coach.sqlite'));
    fs.copyFileSync(libraryDb, path.join(probeDir, 'library', 'library.sqlite'));
    await probeServer(path.join(pluginDir, 'runtime', 'server.mjs'), probeDir);
  } finally {
    // Never let scratch cleanup fail the install: the probe dir lives under the
    // plugin's own tmp/, so a stragglingly-locked file is harmless.
    rmBestEffort(probeDir);
  }
}

// ---------------------------------------------------------------- launcher + PATH block

/** The launcher command is the generic word `coach`; never shadow an existing binary. */
function assertNoCoachCollision(installBinDir) {
  const entries = (process.env.PATH || '').split(path.delimiter).filter(Boolean);
  for (const dir of entries) {
    if (path.resolve(dir) === path.resolve(installBinDir)) continue;
    for (const candidate of commandCandidates(dir, LAUNCHER_NAME)) {
      try {
        const st = fs.statSync(candidate);
        if (st.isFile()) {
          throw new Error(
            `a program named "${LAUNCHER_NAME}" already exists at ${candidate}; ` +
            'refusing to shadow it. Remove or rename it, then re-run the installer.'
          );
        }
      } catch (err) {
        if (err && err.code !== 'ENOENT') throw err;
      }
    }
  }
}


function isUserWritableDir(p) {
  try {
    const st = fs.statSync(p);
    if (!st.isDirectory()) return false;
    if (typeof process.getuid === 'function' && st.uid !== process.getuid()) return false;
    fs.accessSync(p, fs.constants.W_OK | fs.constants.X_OK);
    return true;
  } catch {
    return false;
  }
}

export function shellProfileFile(home = coachHome()) {
  const shell = path.basename(process.env.SHELL || '');
  if (shell === 'zsh') {
    const zprofile = path.join(home, '.zprofile');
    const zshrc = path.join(home, '.zshrc');
    if (fs.existsSync(zprofile)) return zprofile;
    if (fs.existsSync(zshrc)) return zshrc;
    return zprofile;
  }
  if (shell === 'bash') return path.join(home, '.bash_profile');
  return path.join(home, '.profile');
}

/** Where the launcher lands when no writable PATH directory precedes claude. */
export function defaultLauncherDir(home = coachHome()) {
  if (!IS_WINDOWS) return path.join(home, '.local', 'bin');
  const localAppData = process.env.LOCALAPPDATA || path.join(home, 'AppData', 'Local');
  return path.join(localAppData, 'Programs', 'bill-coach', 'bin');
}

export function pickLauncherDir(claudeDir, home = coachHome()) {
  const claudeReal = realpathOrNull(claudeDir);
  const fallback = defaultLauncherDir(home);

  // Windows: always use our own per-user directory. The "reuse a writable PATH
  // directory" heuristic below is safe on POSIX, where those are user-owned bin
  // dirs, but on Windows an administrator's writable PATH includes places like
  // C:\Program Files\PowerShell\7 — observed in CI. Dropping coach.cmd into
  // another product's install directory is unpredictable and would vanish when
  // that product updates.
  if (IS_WINDOWS) {
    const fallbackReal = realpathOrNull(fallback);
    const alreadyOnPath = (process.env.PATH || '').split(path.delimiter).some((entry) => {
      if (!entry) return false;
      const real = realpathOrNull(entry);
      return entry === fallback || (real && fallbackReal && real === fallbackReal);
    });
    return { dir: fallback, needsPathBlock: !alreadyOnPath };
  }

  const before = [];
  for (const entry of (process.env.PATH || '').split(path.delimiter)) {
    if (!entry) continue;
    const real = realpathOrNull(entry);
    if (real && claudeReal && real === claudeReal) break;
    before.push({ entry, real });
  }
  for (const { entry } of before) {
    if (isUserWritableDir(entry)) return { dir: entry, needsPathBlock: false };
  }
  const fallbackReal = realpathOrNull(fallback);
  const onPathBeforeClaude = before.some(({ entry, real }) => entry === fallback || (real && fallbackReal && real === fallbackReal));
  return { dir: fallback, needsPathBlock: !onPathBeforeClaude };
}

export function ensurePathBlock(profileFile) {
  const block = `\n${PATH_BLOCK_BEGIN}\nexport PATH="$HOME/.local/bin:$PATH"\n${PATH_BLOCK_END}\n`;
  const existing = fs.existsSync(profileFile) ? fs.readFileSync(profileFile, 'utf8') : '';
  if (existing.includes(PATH_BLOCK_BEGIN)) return false;
  fs.mkdirSync(path.dirname(profileFile), { recursive: true });
  fs.appendFileSync(profileFile, block);
  return true;
}

export function removePathBlocks(home = coachHome()) {
  const candidates = ['.zprofile', '.zshrc', '.bash_profile', '.profile'].map((f) => path.join(home, f));
  let removed = false;
  for (const file of candidates) {
    if (!fs.existsSync(file)) continue;
    const text = fs.readFileSync(file, 'utf8');
    if (!text.includes(PATH_BLOCK_BEGIN)) continue;
    const pattern = new RegExp(`\\n?${PATH_BLOCK_BEGIN.replace(/[#>]/g, '\\$&')}[\\s\\S]*?${PATH_BLOCK_END.replace(/[#<]/g, '\\$&')}\\n?`, 'g');
    fs.writeFileSync(file, text.replace(pattern, '\n').replace(/\n{3,}$/g, '\n'));
    removed = true;
  }
  return removed;
}

/** Write one file atomically, replacing any existing content. Returns true if it changed. */
function writeFileIfChanged(target, source, mode) {
  const current = fs.existsSync(target) ? fs.readFileSync(target, 'utf8') : null;
  if (current === source) return false;
  const tmp = `${target}.tmp-${randSuffix()}`;
  fs.writeFileSync(tmp, source, mode === undefined ? undefined : { mode });
  fs.renameSync(tmp, target);
  return true;
}

/**
 * The Windows shim. Windows ignores `#!`, so `coach` is a .cmd that hands the
 * real launcher to node. `%~dp0` keeps it relocatable and endlocal/exit
 * preserves the launcher's exit code.
 */
export function renderWindowsShim() {
  return [
    '@echo off',
    'setlocal',
    'set "COACH_SCRIPT=%~dp0coach.mjs"',
    'node "%COACH_SCRIPT%" %*',
    'endlocal & exit /b %ERRORLEVEL%',
    '',
  ].join('\r\n');
}

/** Install the launcher command. Idempotent; never touches a file named claude. */
export function installLauncher(pkgRoot, claudeDir, home = coachHome()) {
  const source = fs.readFileSync(path.join(pkgRoot, 'launcher', 'coach.mjs'), 'utf8');
  if (!source.startsWith('#!/usr/bin/env node')) fail('launcher source is missing its node shebang');
  const { dir, needsPathBlock } = pickLauncherDir(claudeDir, home);
  assertNoCoachCollision(dir);
  const target = path.join(dir, launcherFileName());
  if (path.basename(target, path.extname(target)) === 'claude') fail('refusing to write over a claude binary'); // defensive, unreachable
  fs.mkdirSync(dir, { recursive: true });

  let changed;
  if (IS_WINDOWS) {
    // Two files: the shim on PATH, and the launcher script it calls.
    const scriptChanged = writeFileIfChanged(path.join(dir, `${LAUNCHER_NAME}.mjs`), source);
    const shimChanged = writeFileIfChanged(target, renderWindowsShim());
    changed = scriptChanged || shimChanged;
  } else {
    changed = writeFileIfChanged(target, source, 0o755);
    chmodIfPosix(target, 0o755);
  }

  let pathBlockAdded = false;
  if (needsPathBlock) {
    pathBlockAdded = IS_WINDOWS ? ensureWindowsPathEntry(dir) : ensurePathBlock(shellProfileFile(home));
  }
  return { target, changed, pathBlockAdded };
}

export function removeLauncher(home = coachHome()) {
  const removed = [];
  const seen = new Set();
  const dirs = (process.env.PATH || '').split(path.delimiter).filter(Boolean);
  dirs.push(defaultLauncherDir(home));
  for (const dir of dirs) {
    // On Windows the launcher is a pair: coach.cmd on PATH plus coach.mjs beside it.
    const targets = IS_WINDOWS
      ? [path.join(dir, `${LAUNCHER_NAME}.cmd`), path.join(dir, `${LAUNCHER_NAME}.mjs`)]
      : [path.join(dir, LAUNCHER_NAME)];
    for (const target of targets) {
      const real = realpathOrNull(target);
      if (!real || seen.has(real)) continue;
      seen.add(real);
      try {
        const text = fs.readFileSync(target, 'utf8');
        // Only remove our own launcher. The shim names coach.mjs rather than the
        // profile dir, so accept either fingerprint.
        const ours = text.includes(PROFILE_DIR_NAME) || text.includes(`${LAUNCHER_NAME}.mjs`);
        if (ours) {
          fs.rmSync(target);
          removed.push(target);
          if (IS_WINDOWS) removeWindowsPathEntry(dir);
        }
      } catch { /* not a readable file */ }
    }
  }
  if (!IS_WINDOWS) removePathBlocks(home);
  return removed;
}

// ---------------------------------------------------------------- install

function copyPluginCode(pkgRoot, destPluginDir, manifest) {
  const srcPlugin = path.join(pkgRoot, 'plugin');
  for (const name of fs.readdirSync(srcPlugin)) {
    if (name === '.DS_Store') continue;
    fs.cpSync(path.join(srcPlugin, name), path.join(destPluginDir, name), { recursive: true });
  }
  // Manifest is the single source of executable bits.
  for (const entry of manifest.files) {
    if (entry.executable === true && entry.path.startsWith('plugin/')) {
      const rel = entry.path.slice('plugin/'.length);
      chmodIfPosix(path.join(destPluginDir, rel), 0o755);
    }
  }
}

export function renderSealedConfigs(pkgRoot, P) {
  const settings = renderTemplate(
    fs.readFileSync(path.join(pkgRoot, 'launcher', 'sealed-settings.template.json'), 'utf8'),
    { __PLUGIN_DIR__: P.pluginDir, __DATA_DIR__: P.pluginDir, __PROFILE_DIR__: P.profile },
  );
  const mcp = renderTemplate(
    fs.readFileSync(path.join(pkgRoot, 'launcher', 'sealed-mcp.template.json'), 'utf8'),
    { __PLUGIN_DIR__: P.pluginDir, __DATA_DIR__: P.pluginDir, __PROFILE_DIR__: P.profile },
  );
  return { settings, mcp };
}

async function freshInstall(pkgRoot, manifest, claude, P) {
  if (fs.existsSync(P.profile)) {
    const entries = fs.readdirSync(P.profile).filter((n) => n !== '.DS_Store');
    if (entries.length > 0) {
      fail(`existing directory ${P.profile} has no coach version marker; move it aside or run uninstall first`);
    }
    fs.rmSync(P.profile, { recursive: true, force: true });
  }

  const stage = path.join(P.home, `${PROFILE_DIR_NAME}.stage-${randSuffix()}`);
  try {
    // Stage the whole profile, then verify, then one atomic rename into place.
    const SP = { ...P }; // final paths (used inside rendered configs)
    const stagePlugin = path.join(stage, 'plugins', 'data', PLUGIN_DATA_DIR_NAME);
    fs.mkdirSync(path.join(stage, 'workspace'), { recursive: true });
    fs.mkdirSync(path.join(stage, 'mcp'), { recursive: true });
    fs.mkdirSync(path.join(stage, 'skills'), { recursive: true });
    fs.mkdirSync(stagePlugin, { recursive: true });

    const { settings, mcp } = renderSealedConfigs(pkgRoot, SP);
    fs.writeFileSync(path.join(stage, 'settings.json'), settings);
    fs.writeFileSync(path.join(stage, 'mcp', 'coach-mcp.json'), mcp);

    copyPluginCode(pkgRoot, stagePlugin, manifest);
    fs.mkdirSync(path.join(stagePlugin, 'library'), { recursive: true });
    fs.copyFileSync(path.join(pkgRoot, 'library', 'library.sqlite'), path.join(stagePlugin, 'library', 'library.sqlite'));

    // Durable state from template ONLY because this is a fresh install (no prior state exists).
    fs.mkdirSync(path.join(stagePlugin, 'state'), { recursive: true });
    for (const name of fs.readdirSync(path.join(pkgRoot, 'state-template'))) {
      if (name === '.DS_Store') continue;
      // Copying a -wal/-shm from the build machine hands SQLite a foreign view of
      // this database; the template ships clean and the runtime makes its own.
      if (isSqliteSidecar(name)) continue;
      fs.copyFileSync(path.join(pkgRoot, 'state-template', name), path.join(stagePlugin, 'state', name));
    }
    fs.mkdirSync(path.join(stagePlugin, 'backups'), { recursive: true });
    fs.mkdirSync(path.join(stagePlugin, 'tmp'), { recursive: true });

    // skills-dir discovery entry -> plugin dir (final path; dangling until rename lands).
    // Junction on Windows: a directory symlink there needs admin or Developer Mode.
    linkDirSync(SP.pluginDir, path.join(stage, 'skills', APP_NAME));

    const stagedSchema = await readStateSchemaVersion(path.join(stagePlugin, 'state', 'coach.sqlite'));
    if (stagedSchema !== manifest.schema_version) {
      fail(`state template schema ${stagedSchema} does not match manifest schema_version ${manifest.schema_version}`);
    }
    await verifyPluginTree(stagePlugin, {
      stateDb: path.join(stagePlugin, 'state', 'coach.sqlite'),
      libraryDb: path.join(stagePlugin, 'library', 'library.sqlite'),
      scratchParent: path.join(stagePlugin, 'tmp'),
    });

    fs.mkdirSync(path.join(stagePlugin, 'state_meta'), { recursive: true });
    writeMarker({ marker: path.join(stagePlugin, 'state_meta', 'app.json') }, manifest);

    fs.renameSync(stage, P.profile);
  } catch (err) {
    // Best-effort: a cleanup failure here would mask the real reason the
    // install failed, which is the only thing the user can act on.
    rmBestEffort(stage);
    throw err;
  }

  try {
    const launcher = installLauncher(pkgRoot, claude.dir, P.home);
    if (launcher.pathBlockAdded) {
      process.stderr.write(`note: added ${path.join(P.home, '.local', 'bin')} to PATH in ${shellProfileFile(P.home)}; open a new terminal before running ${LAUNCHER_NAME}\n`);
    }
  } catch (err) {
    fs.rmSync(P.profile, { recursive: true, force: true }); // roll back: nothing half-installed
    throw err;
  }
  return 'installed';
}

/** Main entry. Returns 'installed' | 'already current' | 'upgraded'; throws InstallError on failure. */
// ---------------------------------------------------------------- repair

/**
 * Everything a working install needs beyond the version marker. The marker lives in
 * state_meta/, which uninstall.mjs deliberately preserves along with the memory, so
 * a marker on its own proves only that Coach was once installed here — not that the
 * code and configuration are still on disk.
 */
export function missingInstallParts(P = coachPaths()) {
  const missing = [];
  for (const [what, target] of [
    ['settings', P.settings],
    ['MCP configuration', P.mcpConfig],
    ['workspace', P.workspace],
    ['skills entry', P.skillsLink],
    ['runtime', P.serverEntry],
    ['library', P.libraryDb],
    ['memory database', P.stateDb],
  ]) {
    if (!fs.existsSync(target)) missing.push(what); // follows links: a dangling one counts as missing
  }
  for (const name of CODE_ENTRIES) {
    if (!fs.existsSync(path.join(P.pluginDir, name))) missing.push(`plugin ${name}`);
  }
  return missing;
}

/**
 * Re-lay code and configuration over an install whose durable data survived — the
 * state left by `uninstall.mjs` without --purge-data, or by a half-finished run.
 * state/, backups/ and state_meta/ are never touched. This is what makes
 * uninstall -> reinstall safe: it used to report `already current` over a gutted
 * profile and leave a launcher that could not start.
 */
async function repairInstall(pkgRoot, manifest, claude, P, missing) {
  if (fs.existsSync(P.stateDb)) {
    // Repair lays down THIS package. Moving an older state across schema versions is
    // the upgrader's job and it needs a complete install to run.
    const live = await readStateSchemaVersion(P.stateDb);
    if (live !== manifest.schema_version) {
      fail(
        `the memory database here is schema ${live} but this package is schema ${manifest.schema_version}; ` +
        'it cannot be repaired by this package — ask Elliot before going further, the memory is intact at ' +
        `${P.stateDb}`
      );
    }
  }

  for (const dir of [P.workspace, P.mcpDir, P.skillsDir, P.pluginDir, P.backups, P.tmp]) {
    fs.mkdirSync(dir, { recursive: true });
  }

  const { settings, mcp } = renderSealedConfigs(pkgRoot, P);
  fs.writeFileSync(P.settings, settings);
  fs.writeFileSync(P.mcpConfig, mcp);

  for (const name of CODE_ENTRIES) rmBestEffort(path.join(P.pluginDir, name));
  copyPluginCode(pkgRoot, P.pluginDir, manifest);

  if (!fs.existsSync(P.libraryDb)) {
    fs.mkdirSync(path.dirname(P.libraryDb), { recursive: true });
    fs.copyFileSync(path.join(pkgRoot, 'library', 'library.sqlite'), P.libraryDb);
  }

  let freshState = false;
  if (!fs.existsSync(P.stateDb)) {
    fs.mkdirSync(P.stateDir, { recursive: true });
    for (const name of fs.readdirSync(path.join(pkgRoot, 'state-template'))) {
      if (name === '.DS_Store' || isSqliteSidecar(name)) continue;
      fs.copyFileSync(path.join(pkgRoot, 'state-template', name), path.join(P.stateDir, name));
    }
    freshState = true;
  }

  rmBestEffort(P.skillsLink); // may exist as a dangling link
  linkDirSync(P.pluginDir, P.skillsLink);

  await verifyPluginTree(P.pluginDir, {
    stateDb: P.stateDb,
    libraryDb: P.libraryDb,
    scratchParent: P.tmp,
  });
  writeMarker(P, manifest);
  installLauncher(pkgRoot, claude.dir, P.home);

  const what = missing.join(', ');
  return freshState
    ? `repaired (${what}; no memory was found, so Coach starts fresh)`
    : `repaired (${what}; memory preserved)`;
}

export async function performInstall(pkgRoot) {
  await nodeGate();
  const manifest = validatePackage(pkgRoot);
  const claude = claudeGate();
  if (manifest.min_claude && versionCompare(claude.version, manifest.min_claude) < 0) {
    fail(`Claude Code >= ${manifest.min_claude} required (found ${claude.version}); run \`claude update\` and re-run`);
  }
  const P = coachPaths();
  const marker = readMarker(P);

  if (marker) {
    // A marker with pieces missing is the uninstall -> reinstall case; re-lay this
    // package over the surviving memory rather than declaring the install healthy.
    const missing = missingInstallParts(P);
    if (missing.length > 0) return repairInstall(pkgRoot, manifest, claude, P, missing);
  }

  if (marker && versionCompare(marker.version, manifest.version) === 0) {
    installLauncher(pkgRoot, claude.dir, P.home); // repair only; content-compare makes this a no-op
    return 'already current';
  }
  if (marker) {
    const { performUpgrade } = await import('./upgrade.mjs');
    await performUpgrade(pkgRoot, { manifest, claude });
    return 'upgraded';
  }
  return freshInstall(pkgRoot, manifest, claude, P);
}

// ---------------------------------------------------------------- CLI

export function isMain(metaUrl) {
  if (!process.argv[1]) return false;
  try {
    return fs.realpathSync(fileURLToPath(metaUrl)) === fs.realpathSync(path.resolve(process.argv[1]));
  } catch {
    return false;
  }
}

export async function runCli(fn) {
  try {
    const result = await fn();
    process.stdout.write(`${result}\n`);
    process.exitCode = 0;
  } catch (err) {
    const reason = err instanceof InstallError ? err.message : `unexpected error: ${err?.stack || err}`;
    process.stdout.write(`failed: ${reason}\n`);
    process.exitCode = 1;
  }
}

if (isMain(import.meta.url)) {
  // Deliberately not awaited: upgrade.mjs is dynamically imported during the run and
  // circularly imports this module, which must therefore finish evaluating first.
  runCli(() => performInstall(packageRootFromInstaller(import.meta.url)));
}
