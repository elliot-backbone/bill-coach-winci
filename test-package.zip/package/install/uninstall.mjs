#!/usr/bin/env node
// Bill Jennings Coach — uninstaller.
//
//   node install/uninstall.mjs
//     Removes the coach application: launcher command, tagged PATH block, sealed
//     profile configuration and plugin code. PRESERVES durable memory
//     (state/coach.sqlite), backups/, the bundled library and workspace/.
//     Re-running the installer afterwards repairs the install in place.
//
//   node install/uninstall.mjs --purge-data --confirm "delete bill coach memory"
//     Additionally deletes ALL coach data. Requires exactly both flags and exactly
//     that confirmation phrase; any other phrase is refused. The directory to be
//     deleted is printed before deletion.

import fs from 'node:fs';
import path from 'node:path';
import {
  CODE_ENTRIES,
  InstallError,
  PLUGIN_DATA_DIR_NAME,
  PURGE_PHRASE,
  coachPaths,
  isMain,
  removeLauncher,
  runCli,
} from './install.mjs';

const PRESERVED = new Set(['state', 'backups', 'state_meta', 'library']);

function rm(p) {
  fs.rmSync(p, { recursive: true, force: true });
}

/** Remove app code and configuration, keeping only the durable data dirs. */
export function uninstallPreservingState(P = coachPaths()) {
  removeLauncher(P.home);
  if (!fs.existsSync(P.profile)) return { preserved: null };

  const pluginParent = path.join(P.profile, 'plugins');
  const dataParent = path.join(pluginParent, 'data');
  for (const name of fs.readdirSync(P.profile)) {
    // workspace/ holds the documents Coach wrote for Bill; it is his, not ours.
    if (name !== 'plugins' && name !== 'workspace') rm(path.join(P.profile, name));
  }
  if (fs.existsSync(pluginParent)) {
    for (const name of fs.readdirSync(pluginParent)) {
      if (name !== 'data') rm(path.join(pluginParent, name));
    }
  }
  if (fs.existsSync(dataParent)) {
    for (const name of fs.readdirSync(dataParent)) {
      if (name !== PLUGIN_DATA_DIR_NAME) rm(path.join(dataParent, name));
    }
  }
  if (!fs.existsSync(P.pluginDir)) return { preserved: null };
  for (const name of fs.readdirSync(P.pluginDir)) {
    if (!PRESERVED.has(name)) rm(path.join(P.pluginDir, name));
  }
  return { preserved: P.pluginDir };
}

export function purgeAll(P = coachPaths()) {
  removeLauncher(P.home);
  rm(P.profile);
}

export function parseArgs(argv) {
  const args = { purgeData: false, confirm: null, unknown: [] };
  for (let i = 0; i < argv.length; i += 1) {
    const a = argv[i];
    if (a === '--purge-data') args.purgeData = true;
    else if (a === '--confirm') args.confirm = argv[++i] ?? '';
    else if (a.startsWith('--confirm=')) args.confirm = a.slice('--confirm='.length);
    else args.unknown.push(a);
  }
  return args;
}

export async function performUninstall(argv) {
  const args = parseArgs(argv);
  if (args.unknown.length > 0) throw new InstallError(`unknown argument: ${args.unknown[0]}`);
  const P = coachPaths();

  const wantsPurge = args.purgeData || args.confirm !== null;
  if (!wantsPurge) {
    const { preserved } = uninstallPreservingState(P);
    return preserved ? `uninstalled (memory preserved at ${preserved})` : 'uninstalled';
  }

  if (!args.purgeData || args.confirm === null) {
    throw new InstallError(`purge refused: requires BOTH --purge-data and --confirm "${PURGE_PHRASE}"`);
  }
  process.stdout.write(`will delete: ${P.profile}\n`);
  if (args.confirm !== PURGE_PHRASE) {
    throw new InstallError(`purge refused: confirmation phrase does not match "${PURGE_PHRASE}"`);
  }
  purgeAll(P);
  return 'purged';
}

if (isMain(import.meta.url)) {
  runCli(() => performUninstall(process.argv.slice(2)));
}
