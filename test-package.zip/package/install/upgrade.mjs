#!/usr/bin/env node
// Bill Jennings Coach — upgrader.
//
// Run from the extracted package:  node install/upgrade.mjs
// Prints exactly one line on stdout: upgraded | already current | failed: <reason>
//
// Order of operations:
//   1. validate the package (manifest structure + hashes) and environment gates
//   2. back up state/coach.sqlite into backups/ (latest successful + one predecessor kept)
//   3. stage new code + library beside the live plugin dir; hash and integrity checks
//   4. migrate a COPY of the state db when schema_version differs (migrations registry below)
//   5. model-free MCP lifecycle probe against the staged runtime and migrated state copy
//   6. swap code/library (and migrated state when applicable) into place; the prior
//      version is parked next to the live dir and restored on any swap failure
//   7. only after a fully verified swap: drop the parked prior version, prune backups

import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {
  CODE_ENTRIES,
  InstallError,
  chmodIfPosix,
  rmBestEffort,
  claudeGate,
  coachPaths,
  installLauncher,
  integrityCheck,
  isMain,
  nodeGate,
  packageRootFromInstaller,
  readMarker,
  readStateSchemaVersion,
  renderSealedConfigs,
  runCli,
  validatePackage,
  verifyPluginTree,
  versionCompare,
  writeMarker,
} from './install.mjs';

/**
 * State schema migrations, keyed by TARGET schema version. Each entry upgrades a
 * database from (target - 1) to target; the harness wraps each step in a transaction
 * and sets state_meta.schema_version after it succeeds.
 *
 * Deliberately empty for 1.0.2 (schema v3): no earlier version was ever installed
 * for the principal, so upgrades from pre-1.0.2 states are unsupported by design
 * (fresh install instead). Future migrations start at 4.
 */
export const MIGRATIONS = {
  /**
   * 2: `people` becomes `principal_profile`.
   *
   * The table was never a directory of humans — it holds ONE row, read
   * unconditionally into every orientation, and it is the only channel by which
   * Bill's own corrections to the always-on model can persist. Under the old name
   * it read like a contacts list, which invites network contacts into always-on
   * context and leaves the real purpose undiscoverable. `contacts` is, and stays,
   * the network directory.
   *
   * Runs against a COPY of the database; the swap only happens after the probe.
   */
  2: (db) => {
    const has = (name) => db.prepare(`SELECT COUNT(*) AS n FROM sqlite_master WHERE type = 'table' AND name = ?`).get(name).n > 0;
    if (has('principal_profile')) return; // already migrated
    if (!has('people')) throw new Error('migration 2: neither people nor principal_profile is present');
    db.exec('ALTER TABLE people RENAME TO principal_profile');
    // Seed the model only when the rename left it empty, and leave it UNCONFIRMED:
    // it is a proposal Bill rules on, never a fact asserted about him.
    const empty = db.prepare('SELECT COUNT(*) AS n FROM principal_profile').get().n === 0;
    if (empty) {
      const now = new Date().toISOString();
      db.prepare(`INSERT INTO principal_profile (id, name, role, strengths_json, focus_areas_json, working_model, confirmed, source_ids_json, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, 0, ?, ?, ?)`)
        .run('principal-bill', 'Bill Jennings', 'the principal — the person Coach works for',
          JSON.stringify(['high-ticket closing', 'founder-led sales motions', 'building and coaching a first commercial team', 'funnels and events as pipeline generation']),
          JSON.stringify(['finding the right room, not just a job', 'a first-commercial-hire role at a funded seed-stage company', 'a story sharp enough that the move looks inevitable']),
          'Writes terse; fragments and single words are complete instructions. Glass-half-full extrovert — never remind him to think positive. Corrections outrank everything here.',
          JSON.stringify(['elliot-briefing']), now, now);
    }
  },
  /**
   * 3: `confirmed` is deleted from memories and principal_profile.
   *
   * It was a two-tier confidence model that gated nothing useful and coloured
   * everything: a record marked "proposed" invites the coach to hedge on what it
   * already knows and to re-ask Bill for things on file. Data is data. Provenance is
   * still recorded on every row via source_ids, and a correction from Bill supersedes
   * the record it corrects — that is the whole trust model, and it needs no tier.
   */
  3: (db) => {
    const cols = (t) => db.prepare(`SELECT name FROM pragma_table_info('${t}')`).all().map((r) => r.name);
    for (const table of ['memories', 'principal_profile']) {
      if (cols(table).includes('confirmed')) db.exec(`ALTER TABLE ${table} DROP COLUMN confirmed`);
    }
  },
};

function setSchemaVersion(db, version) {
  db.prepare(`UPDATE state_meta SET value = ?, updated_at = ? WHERE key = 'schema_version'`)
    .run(String(version), new Date().toISOString());
}

export async function migrateStateCopy(workDb, fromVersion, toVersion) {
  if (fromVersion === toVersion) return;
  if (fromVersion > toVersion) {
    throw new InstallError(`installed state schema ${fromVersion} is newer than package schema ${toVersion}; downgrade is not supported`);
  }
  const { DatabaseSync } = await import('node:sqlite');
  const db = new DatabaseSync(workDb);
  try {
    for (let target = fromVersion + 1; target <= toVersion; target += 1) {
      const step = MIGRATIONS[target];
      if (!step) throw new InstallError(`no migration path from state schema ${target - 1} to ${target}`);
      db.exec('BEGIN');
      try {
        step(db, { setSchemaVersion });
        setSchemaVersion(db, target);
        db.exec('COMMIT');
      } catch (err) {
        try { db.exec('ROLLBACK'); } catch { /* already rolled back */ }
        throw err instanceof InstallError ? err : new InstallError(`migration to schema ${target} failed: ${err.message}`);
      }
    }
  } finally {
    db.close();
  }
  const after = await readStateSchemaVersion(workDb);
  if (after !== toVersion) throw new InstallError(`migration finished on schema ${after}, expected ${toVersion}`);
}

// Runtime-acquired sources (sync_source appends, source_group 'sync:*') must survive a
// library replacement: merge them forward into the staged new library before the swap.
async function mergeForwardSyncedSources(livePath, stagedPath) {
  if (!fs.existsSync(livePath)) return 0;
  const { DatabaseSync } = await import('node:sqlite');
  const db = new DatabaseSync(stagedPath);
  let merged = 0;
  try {
    db.exec('PRAGMA foreign_keys = ON');
    db.prepare('ATTACH DATABASE ? AS live').run(livePath);
    const docs = db.prepare(`SELECT * FROM live.documents WHERE source_group LIKE 'sync:%'`).all();
    db.exec('BEGIN');
    for (const d of docs) {
      if (db.prepare(`SELECT 1 FROM documents WHERE id = ? OR content_sha256 = ?`).get(d.id, d.content_sha256)) continue;
      db.prepare(`INSERT INTO documents (id, kind, title, author, occurred_at, captured_at, authority_rank,
          authority_scope, media_type, language, source_group, external_id, parent_id, raw_content,
          extracted_text, content_sha256, status, attributes_json)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, ?, ?, ?, ?, ?)`)
        .run(d.id, d.kind, d.title, d.author, d.occurred_at, d.captured_at, d.authority_rank,
          d.authority_scope, d.media_type, d.language, d.source_group, d.external_id, d.raw_content,
          d.extracted_text, d.content_sha256, d.status, d.attributes_json);
      for (const c of db.prepare(`SELECT * FROM live.chunks WHERE document_id = ? ORDER BY sequence`).all(d.id)) {
        db.prepare(`INSERT INTO chunks (document_id, sequence, heading, speaker, started_at, ended_at, text, token_count, content_sha256, attributes_json)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
          .run(c.document_id, c.sequence, c.heading, c.speaker, c.started_at, c.ended_at, c.text, c.token_count, c.content_sha256, c.attributes_json);
      }
      for (const e of db.prepare(`SELECT * FROM live.document_entities WHERE document_id = ?`).all(d.id)) {
        db.prepare(`INSERT OR IGNORE INTO document_entities (document_id, entity, role) VALUES (?, ?, ?)`).run(e.document_id, e.entity, e.role);
      }
      for (const t of db.prepare(`SELECT * FROM live.document_topics WHERE document_id = ?`).all(d.id)) {
        db.prepare(`INSERT OR IGNORE INTO document_topics (document_id, topic) VALUES (?, ?)`).run(t.document_id, t.topic);
      }
      merged += 1;
    }
    // Relations last, and only where both endpoints exist in the merged library.
    for (const r of db.prepare(`
      SELECT r.* FROM live.document_relations r
      JOIN live.documents d ON d.id = r.from_document_id
      WHERE d.source_group LIKE 'sync:%'`).all()) {
      const both = db.prepare(`SELECT (SELECT 1 FROM documents WHERE id = ?) a, (SELECT 1 FROM documents WHERE id = ?) b`).get(r.from_document_id, r.to_document_id);
      if (both.a && both.b) {
        db.prepare(`INSERT OR IGNORE INTO document_relations (from_document_id, relation, to_document_id) VALUES (?, ?, ?)`)
          .run(r.from_document_id, r.relation, r.to_document_id);
        if (r.relation === 'supersedes') {
          db.prepare(`UPDATE documents SET status = 'superseded' WHERE id = ? AND status = 'active'`).run(r.to_document_id);
        }
      }
    }
    db.exec('COMMIT');
    db.exec('DETACH DATABASE live');
  } catch (err) {
    try { db.exec('ROLLBACK'); } catch { /* not in a transaction */ }
    db.close();
    throw err;
  }
  db.close();
  return merged;
}

function backupStateDb(P, oldVersion) {
  fs.mkdirSync(P.backups, { recursive: true });
  const stamp = new Date().toISOString().replace(/[-:]/g, '').replace(/\..*/, '');
  const target = path.join(P.backups, `coach-v${oldVersion}-${stamp}.sqlite`);
  fs.copyFileSync(P.stateDb, target);
  return target;
}

export function pruneBackups(P, keep = 2) {
  if (!fs.existsSync(P.backups)) return;
  const entries = fs.readdirSync(P.backups)
    .filter((n) => /^coach-v.+\.sqlite$/.test(n))
    .map((n) => ({ n, mtime: fs.statSync(path.join(P.backups, n)).mtimeMs }))
    .sort((a, b) => b.mtime - a.mtime);
  for (const { n } of entries.slice(keep)) fs.rmSync(path.join(P.backups, n), { force: true });
}

export async function performUpgrade(pkgRoot, preflight = {}) {
  await nodeGate();
  const manifest = preflight.manifest ?? validatePackage(pkgRoot);
  const claude = preflight.claude ?? claudeGate();
  const P = coachPaths();
  const marker = readMarker(P);
  if (!marker) throw new InstallError(`no installed coach found at ${P.profile}; run install/install.mjs instead`);

  const cmp = versionCompare(manifest.version, marker.version);
  if (cmp === 0) return 'already current';
  if (cmp < 0) throw new InstallError(`installed version ${marker.version} is newer than package version ${manifest.version}`);

  const rand = crypto.randomBytes(5).toString('hex');
  const dataParent = path.dirname(P.pluginDir);
  const stage = path.join(dataParent, `.stage-${rand}`);
  const workDir = path.join(P.tmp, `migrate-${rand}`);
  fs.mkdirSync(P.tmp, { recursive: true });

  // 1. Back up durable state before anything else.
  backupStateDb(P, marker.version);

  let prev = null;
  let workDb = null;
  let schemaChanged = false;
  try {
    // 2. Stage new code + library.
    fs.mkdirSync(stage, { recursive: true });
    const srcPlugin = path.join(pkgRoot, 'plugin');
    for (const name of fs.readdirSync(srcPlugin)) {
      if (name === '.DS_Store') continue;
      fs.cpSync(path.join(srcPlugin, name), path.join(stage, name), { recursive: true });
    }
    for (const entry of manifest.files) {
      if (entry.executable === true && entry.path.startsWith('plugin/')) {
        chmodIfPosix(path.join(stage, entry.path.slice('plugin/'.length)), 0o755);
      }
    }
    fs.mkdirSync(path.join(stage, 'library'), { recursive: true });
    fs.copyFileSync(path.join(pkgRoot, 'library', 'library.sqlite'), path.join(stage, 'library', 'library.sqlite'));
    const mergedForward = await mergeForwardSyncedSources(
      path.join(P.pluginDir, 'library', 'library.sqlite'),
      path.join(stage, 'library', 'library.sqlite'),
    );
    if (mergedForward > 0) process.stderr.write(`merged forward ${mergedForward} runtime-synced source document(s)\n`);
    await integrityCheck(path.join(stage, 'library', 'library.sqlite'));

    // 3. Migrate a copy of the live state db.
    fs.mkdirSync(workDir, { recursive: true });
    workDb = path.join(workDir, 'coach.sqlite');
    fs.copyFileSync(P.stateDb, workDb);
    const currentSchema = await readStateSchemaVersion(workDb);
    schemaChanged = currentSchema !== manifest.schema_version;
    await migrateStateCopy(workDb, currentSchema, manifest.schema_version);
    await integrityCheck(workDb);

    // 4. Probe the staged runtime with the migrated state and new library (on copies).
    await verifyPluginTree(stage, {
      stateDb: workDb,
      libraryDb: path.join(stage, 'library', 'library.sqlite'),
      scratchParent: workDir,
    });
  } catch (err) {
    rmBestEffort(stage);
    rmBestEffort(workDir);
    throw err;
  }

  // 5. Swap. The prior version is parked beside the live dir until success.
  prev = path.join(dataParent, `.prev-${marker.version}-${rand}`);
  const swappable = [...CODE_ENTRIES, 'library'];
  const parked = [];
  const placed = [];
  const priorSettings = fs.existsSync(P.settings) ? fs.readFileSync(P.settings, 'utf8') : null;
  const priorMcp = fs.existsSync(P.mcpConfig) ? fs.readFileSync(P.mcpConfig, 'utf8') : null;
  let stateSwapped = false;
  try {
    fs.mkdirSync(prev, { recursive: true });
    for (const name of swappable) {
      const live = path.join(P.pluginDir, name);
      if (fs.existsSync(live)) {
        fs.renameSync(live, path.join(prev, name));
        parked.push(name);
      }
    }
    for (const name of fs.readdirSync(stage)) {
      fs.renameSync(path.join(stage, name), path.join(P.pluginDir, name));
      placed.push(name);
    }
    if (schemaChanged) {
      fs.renameSync(P.stateDb, path.join(prev, 'coach.sqlite.pre-migration'));
      fs.renameSync(workDb, P.stateDb);
      stateSwapped = true;
    }
    // Re-render sealed configs from the new package (templates may have changed).
    const rendered = renderSealedConfigs(pkgRoot, P);
    fs.writeFileSync(P.settings, rendered.settings);
    fs.writeFileSync(P.mcpConfig, rendered.mcp);
    writeMarker(P, manifest);
  } catch (err) {
    // Roll back to the parked prior version and prior state.
    for (const name of placed) fs.rmSync(path.join(P.pluginDir, name), { recursive: true, force: true });
    for (const name of parked) {
      try { fs.renameSync(path.join(prev, name), path.join(P.pluginDir, name)); } catch { /* keep restoring */ }
    }
    if (stateSwapped) {
      try {
        fs.rmSync(P.stateDb, { force: true });
        fs.renameSync(path.join(prev, 'coach.sqlite.pre-migration'), P.stateDb);
      } catch { /* backup in backups/ still holds the state */ }
    }
    if (priorSettings !== null) fs.writeFileSync(P.settings, priorSettings);
    if (priorMcp !== null) fs.writeFileSync(P.mcpConfig, priorMcp);
    try { writeMarker(P, { version: marker.version, schema_version: marker.schema_version }); } catch { /* marker restore best effort */ }
    rmBestEffort(prev);
    rmBestEffort(stage);
    rmBestEffort(workDir);
    throw err instanceof InstallError ? err : new InstallError(`upgrade swap failed: ${err.message}`);
  }

  // 6. Verified: drop the parked prior version, refresh launcher, prune backups.
  rmBestEffort(prev);
  rmBestEffort(stage);
  rmBestEffort(workDir);
  installLauncher(pkgRoot, claude.dir, P.home);
  pruneBackups(P, 2);
  return 'upgraded';
}

if (isMain(import.meta.url)) {
  runCli(() => performUpgrade(packageRootFromInstaller(import.meta.url)));
}
