#!/usr/bin/env node
// Bill Jennings Coach — upgrader.
//
// Run from the extracted package:  node install/upgrade.mjs
// Prints exactly one line on stdout: upgraded | already current | failed: <reason>
//
// Order of operations:
//   1. validate the package (manifest structure + hashes) and environment gates
//   2. back up state/coach.sqlite into backups/ (latest successful + one predecessor kept)
//   3. stage new code + library beside the live plugin dir; hash and integrity checks
//   4. migrate a COPY of the state db when schema_version differs (migrations registry below)
//   5. model-free MCP lifecycle probe against the staged runtime and migrated state copy
//   6. swap code/library (and migrated state when applicable) into place; the prior
//      version is parked next to the live dir and restored on any swap failure
//   7. only after a fully verified swap: drop the parked prior version, prune backups

import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {
  CODE_ENTRIES,
  InstallError,
  chmodIfPosix,
  rmBestEffort,
  claudeGate,
  coachPaths,
  installLauncher,
  integrityCheck,
  isMain,
  nodeGate,
  packageRootFromInstaller,
  readMarker,
  readStateSchemaVersion,
  renderSealedConfigs,
  writeUserScopeMcp,
  runCli,
  validatePackage,
  verifyPluginTree,
  versionCompare,
  writeMarker,
} from './install.mjs';

/**
 * State schema migrations, keyed by TARGET schema version. Each entry upgrades a
 * database from (target - 1) to target; the harness wraps each step in a transaction
 * and sets state_meta.schema_version after it succeeds.
 *
 * Deliberately empty for 1.0.2 (schema v3): no earlier version was ever installed
 * for the principal, so upgrades from pre-1.0.2 states are unsupported by design
 * (fresh install instead). Future migrations start at 4.
 */
export const MIGRATIONS = {
  /**
   * 2: `people` becomes `principal_profile`.
   *
   * The table was never a directory of humans — it holds ONE row, read
   * unconditionally into every orientation, and it is the only channel by which
   * Bill's own corrections to the always-on model can persist. Under the old name
   * it read like a contacts list, which invites network contacts into always-on
   * context and leaves the real purpose undiscoverable. `contacts` is, and stays,
   * the network directory.
   *
   * Runs against a COPY of the database; the swap only happens after the probe.
   */
  2: (db) => {
    const has = (name) => db.prepare(`SELECT COUNT(*) AS n FROM sqlite_master WHERE type = 'table' AND name = ?`).get(name).n > 0;
    if (has('principal_profile')) return; // already migrated
    if (!has('people')) throw new Error('migration 2: neither people nor principal_profile is present');
    db.exec('ALTER TABLE people RENAME TO principal_profile');
    // Seed the model only when the rename left it empty, and leave it UNCONFIRMED:
    // it is a proposal Bill rules on, never a fact asserted about him.
    const empty = db.prepare('SELECT COUNT(*) AS n FROM principal_profile').get().n === 0;
    if (empty) {
      const now = new Date().toISOString();
      db.prepare(`INSERT INTO principal_profile (id, name, role, strengths_json, focus_areas_json, working_model, confirmed, source_ids_json, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, 0, ?, ?, ?)`)
        .run('principal-bill', 'Bill Jennings', 'the principal — the person Coach works for',
          JSON.stringify(['high-ticket closing', 'founder-led sales motions', 'building and coaching a first commercial team', 'funnels and events as pipeline generation']),
          JSON.stringify(['finding the right room, not just a job', 'a first-commercial-hire role at a funded seed-stage company', 'a story sharp enough that the move looks inevitable']),
          'Writes terse; fragments and single words are complete instructions. Glass-half-full extrovert — never remind him to think positive. Corrections outrank everything here.',
          JSON.stringify(['elliot-briefing']), now, now);
    }
  },
  /**
   * 3: `confirmed` is deleted from memories and principal_profile.
   *
   * It was a two-tier confidence model that gated nothing useful and coloured
   * everything: a record marked "proposed" invites the coach to hedge on what it
   * already knows and to re-ask Bill for things on file. Data is data. Provenance is
   * still recorded on every row via source_ids, and a correction from Bill supersedes
   * the record it corrects — that is the whole trust model, and it needs no tier.
   */
  3: (db) => {
    const cols = (t) => db.prepare(`SELECT name FROM pragma_table_info('${t}')`).all().map((r) => r.name);
    for (const table of ['memories', 'principal_profile']) {
      if (cols(table).includes('confirmed')) db.exec(`ALTER TABLE ${table} DROP COLUMN confirmed`);
    }
  },

  /**
   * 4: deliverables get somewhere to live.
   *
   * Until now the thing Coach actually produces — the CV, the tight five, the LinkedIn copy,
   * the one-pager — had no table. It was written, shown to Bill, and lost at the end of the
   * session, so the next session rebuilt it from the learnings ledger instead of refining what
   * already existed. MEASURED across all fourteen deliverables: a CV session persisted
   * fourteen learnings and zero CV; the tight five and the one-pager persisted nothing at all.
   *
   * Additive only. No existing row is touched, so this cannot lose anything.
   */
  4: (db) => {
    const has = db.prepare(`SELECT COUNT(*) n FROM sqlite_master WHERE type='table' AND name='deliverables'`).get().n;
    if (!has) db.exec(`-- Every artefact Coach produces, versioned.
--
-- MEASURED 2026-08-22 across all fourteen declared deliverables run end to end: Coach wrote
-- the CV, the tight five, the LinkedIn copy and the one-pager, streamed them to Bill, and
-- persisted none of them. There was no table to put them in, so the doctrine's routing lines
-- sent the LESSONS to learnings and dropped the ARTEFACT. A CV session stored fourteen
-- learnings and zero CV.
--
-- One row per VERSION, never an overwrite: a tight five refined over six sessions keeps all
-- six, so Bill and Coach can see the drift and go back.
CREATE TABLE deliverables (
  id TEXT PRIMARY KEY,
  kind TEXT NOT NULL CHECK (kind IN (
    'tight_five','cv','linkedin','content','positioning_one_pager','discovery_pipeline',
    'outreach','prep_brief','rehearsal','debrief','offer_review','negotiation_plan',
    'weekly_review','thread_pull','other')),
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  version INTEGER NOT NULL,
  supersedes TEXT,
  change_note TEXT,
  status TEXT NOT NULL DEFAULT 'live' CHECK (status IN ('live','retired')),
  role_id TEXT,
  session_id TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  CHECK (version >= 1),
  CHECK (length(body) > 0)
) STRICT;
CREATE INDEX deliverables_kind_idx ON deliverables(kind, version DESC);
CREATE INDEX deliverables_role_idx ON deliverables(role_id);`);
  },

  /**
   * 5: the green flag library, and the coverage ledger the tight-five gate reads.
   *
   * Additive only. Seeds thirteen flags from the adviser guide, the reading corpus and the
   * operator's own interview practice; ranks are recomputed per conversation at run time.
   */
  5: (db) => {
    const has = db.prepare(`SELECT COUNT(*) n FROM sqlite_master WHERE type='table' AND name='green_flags'`).get().n;
    if (!has) db.exec(`-- The green flag library, and what the tight-five interview has actually covered.
--
-- MEASURED 2026-08-22: asked for the tight five, Coach took Bill's opening anecdote about a
-- £240k deal, mined it, and drafted story one by turn two. It never asked where he grew up.
-- Four turns, 1,496 words. The operator's own two biographical interviews with a founder ran
-- 103 questions across 271 turns and 10,683 words from the subject, over two sittings, and
-- opened on family, money and childhood. The doctrine said "do not open at his career" and
-- lost to the first sentence Bill said.
--
-- The flags are what the interview is HUNTING, made explicit and rankable rather than left as
-- prose Coach may or may not act on. Ranking is per conversation: what a seed founder hiring a
-- first commercial hire weights is not what a growth-stage investor weights.
CREATE TABLE green_flags (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  dimension TEXT NOT NULL,
  polarity TEXT NOT NULL CHECK (polarity IN ('green','red')),
  behaviour TEXT NOT NULL,
  evidence TEXT NOT NULL,
  question TEXT NOT NULL,
  anti_pattern TEXT,
  source TEXT NOT NULL,
  base_rank INTEGER NOT NULL,
  current_rank INTEGER NOT NULL,
  lane TEXT,
  times_surfaced INTEGER NOT NULL DEFAULT 0,
  times_landed INTEGER NOT NULL DEFAULT 0,
  last_ranked_at TEXT,
  rank_reason TEXT,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','retired')),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  CHECK (base_rank >= 1),
  CHECK (current_rank >= 1)
) STRICT;
CREATE INDEX green_flags_rank_idx ON green_flags(status, current_rank);

-- What the biographical interview has on file, per slot, so the gate can refuse to draft on
-- thin material instead of discovering it in a real room.
CREATE TABLE narrative_coverage (
  id TEXT PRIMARY KEY,
  slot TEXT NOT NULL CHECK (slot IN (
    'childhood','family_and_money','schooling','first_work','professional_sequence',
    'cost_and_doubt','turning_point','present_want')),
  scene TEXT NOT NULL,
  age_or_date TEXT,
  named_detail TEXT,
  verbatim TEXT,
  flag_id TEXT,
  source_kind TEXT NOT NULL DEFAULT 'interview',
  created_at TEXT NOT NULL,
  CHECK (length(scene) > 0)
) STRICT;
CREATE INDEX narrative_coverage_slot_idx ON narrative_coverage(slot);`);
    const now = new Date().toISOString();
    const seed = [
      {
            "name": "adversity_navigated",
            "dimension": "resilience",
            "polarity": "green",
            "base_rank": 1,
            "source": "adviser guide, ch.1 positive signals",
            "behaviour": "Has been through something genuinely hard and came out with his judgment intact, rather than either unmarked by it or still governed by it.",
            "evidence": "A scene with a date where the outcome was in doubt, what it cost him, and a decision he made during it that he can still defend.",
            "question": "What is the worst it got? Take me to the week it looked like it would not come back.",
            "anti_pattern": "Adversity narrated as a triumph with the doubt edited out, or as a grievance still being carried."
      },
      {
            "name": "honest_about_limits",
            "dimension": "self_knowledge",
            "polarity": "green",
            "base_rank": 2,
            "source": "adviser guide, ch.1 positive signals",
            "behaviour": "Says plainly what he knows and what he does not, without either hedging everything or bluffing the gaps.",
            "evidence": "An unprompted admission of a real limit, ideally one that cost him something before he saw it.",
            "question": "What did you get wrong for longer than you should have? Who told you, and what did you do about it?",
            "anti_pattern": "Weaknesses offered as disguised strengths, or a limit named with no consequence attached to it."
      },
      {
            "name": "updates_rather_than_defends",
            "dimension": "adaptability",
            "polarity": "green",
            "base_rank": 3,
            "source": "adviser guide, ch.1 positive signals",
            "behaviour": "Changes position when the evidence moves, instead of defending the one he arrived with.",
            "evidence": "A named belief he held, what changed it, and what he did differently afterwards.",
            "question": "What did you believe about selling five years ago that you no longer believe?",
            "anti_pattern": "A change of mind described only as growth in the abstract, with no specific belief named."
      },
      {
            "name": "energising_presence",
            "dimension": "effect_on_others",
            "polarity": "green",
            "base_rank": 4,
            "source": "adviser guide, ch.1 positive signals",
            "behaviour": "Being around him leaves people with more energy than they had, not less.",
            "evidence": "Someone who chose to work with him twice, or followed him somewhere, and what they say about why.",
            "question": "Who has worked with you more than once? What would they say it is like on a bad week?",
            "anti_pattern": "Warmth asserted about himself rather than evidenced by somebody else's choice."
      },
      {
            "name": "agency_without_permission",
            "dimension": "agency",
            "polarity": "green",
            "base_rank": 5,
            "source": "reading corpus, on tracing structural causes rather than waiting on authority",
            "behaviour": "Starts things he was not given permission or resources to start, and finds the route himself.",
            "evidence": "A thing that exists because he made it exist, with the obstacle named and the workaround described step by step.",
            "question": "What did you build that nobody asked you to build? Who tried to stop it?",
            "anti_pattern": "Initiative claimed at the level of attitude, with no obstacle and therefore no cost."
      },
      {
            "name": "makes_others_good",
            "dimension": "effect_on_others",
            "polarity": "green",
            "base_rank": 6,
            "source": "reading corpus, on coaching as a trainable practice",
            "behaviour": "Raises the people around him, and can describe the mechanism rather than the sentiment.",
            "evidence": "A named person who got measurably better, what he actually did with them, over how long.",
            "question": "Who is better at their job because of you? What did you do with them, specifically, week to week?",
            "anti_pattern": "Team success narrated in the first person plural with no individual named."
      },
      {
            "name": "calibrated_under_uncertainty",
            "dimension": "judgment",
            "polarity": "green",
            "base_rank": 7,
            "source": "reading corpus, on separating what is known from what is assumed",
            "behaviour": "Separates what he knows from what he is assuming, and says which is which without being asked.",
            "evidence": "A decision made on incomplete information where he can state what he did not know at the time.",
            "question": "When you committed to that, what did you actually not know yet? What would have changed your mind?",
            "anti_pattern": "Hindsight narrated as foresight, every past decision made to look obvious."
      },
      {
            "name": "seeks_the_hard_feedback",
            "dimension": "self_knowledge",
            "polarity": "green",
            "base_rank": 8,
            "source": "reading corpus, on blunt feedback as a deliberate discipline",
            "behaviour": "Goes looking for the answer he does not want, from people who will actually give it.",
            "evidence": "A time he asked, got told something painful, and acted on it rather than explaining it away.",
            "question": "When did somebody tell you something about yourself you did not want to hear? What did you do next?",
            "anti_pattern": "Feedback received gracefully in the telling, with no behaviour changed as a result."
      },
      {
            "name": "traces_cause_not_blame",
            "dimension": "judgment",
            "polarity": "green",
            "base_rank": 9,
            "source": "reading corpus, on successive why questions reaching structural causes",
            "behaviour": "When something failed, looks for the structure that produced it rather than the person to hang it on.",
            "evidence": "A failure he analysed to a cause that was not a person, and the change he made on the back of it.",
            "question": "The one that went wrong \u2014 why did it go wrong? And why was that true?",
            "anti_pattern": "A post-mortem that terminates on somebody's character."
      },
      {
            "name": "motive_larger_than_the_job",
            "dimension": "motivation",
            "polarity": "green",
            "base_rank": 10,
            "source": "operator practice, biographical interview 2025-09-23",
            "behaviour": "Has a reason for this move that survives the question 'why on earth would you do that', and it predates the opportunity.",
            "evidence": "A thread visible in the life before the career: what he was moving toward, or away from, since childhood.",
            "question": "I am trying to understand why on earth you would leave a business your family runs. Where does that come from?",
            "anti_pattern": "A motive assembled for the interview, with no root earlier than the last two years."
      },
      {
            "name": "talks_past_usefulness",
            "dimension": "conversational",
            "polarity": "red",
            "base_rank": 11,
            "source": "adviser guide, ch.1 negative signals",
            "behaviour": "Keeps going after the point has landed, so the listener stops tracking.",
            "evidence": "Answers that continue past the question, or a story with no exit.",
            "question": "In rehearsal: where did you finish, and where should you have finished?",
            "anti_pattern": null
      },
      {
            "name": "defensive_under_challenge",
            "dimension": "conversational",
            "polarity": "red",
            "base_rank": 12,
            "source": "adviser guide, ch.1 negative signals",
            "behaviour": "Meets a hard question with justification rather than with the answer.",
            "evidence": "A pushback answered by restating the original claim more firmly.",
            "question": "In rehearsal: push hard on the weakest line and watch what he does with it.",
            "anti_pattern": null
      },
      {
            "name": "certainty_about_the_unknowable",
            "dimension": "conversational",
            "polarity": "red",
            "base_rank": 13,
            "source": "adviser guide, ch.1 negative signals",
            "behaviour": "Projects confidence about things nobody could know, which costs him credibility on the things he does know.",
            "evidence": "Forecasts stated flat, without the conditions that would make them wrong.",
            "question": "In rehearsal: ask what would have to be true, and see whether the confidence survives it.",
            "anti_pattern": null
      }
];
    const ins = db.prepare(`INSERT OR IGNORE INTO green_flags
      (id, name, dimension, polarity, behaviour, evidence, question, anti_pattern, source,
       base_rank, current_rank, times_surfaced, times_landed, status, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 0, 'active', ?, ?)`);
    for (const f of seed) {
      ins.run(`flag-${f.name}`, f.name, f.dimension, f.polarity, f.behaviour, f.evidence,
        f.question, f.anti_pattern ?? null, f.source, f.base_rank, f.base_rank, now, now);
    }
  },

  /**
   * 6: cv_lines, and an origin marker on deliverables.
   *
   * The CV Bill supplies is the starting point of that module, not something Coach composes,
   * so it has to be distinguishable from what Coach wrote and it must never be overwritten.
   * Additive only.
   */
  6: (db) => {
    const has = db.prepare(`SELECT COUNT(*) n FROM sqlite_master WHERE type='table' AND name='cv_lines'`).get().n;
    if (!has) db.exec(`-- Bill's CV, worked over line by line WITH him.
--
-- MEASURED 2026-08-22: asked to tune the CV, Coach ran ten questions and emitted a finished CV
-- of its own composition. Its own doctrine says the CV is "coached, not ghost-written — every
-- line must survive 'defend this in the room'". A document he did not write, containing claims
-- he has not defended, is ghost-writing with extra steps.
--
-- OPERATOR RULING 2026-08-23: Bill supplies the CV. Coach reasons over it with him against
-- everything already on file about his life, his career and what he wants next. One line at a
-- time. Nothing is final without his ruling.
CREATE TABLE cv_lines (
  id TEXT PRIMARY KEY,
  source_deliverable_id TEXT,
  surface TEXT NOT NULL DEFAULT 'cv' CHECK (surface IN ('cv','headline','about','experience')),
  section TEXT,
  line_no INTEGER NOT NULL,
  lane TEXT,
  current_text TEXT NOT NULL,
  proposed_text TEXT,
  rationale TEXT,
  evidence_refs_json TEXT NOT NULL DEFAULT '[]',
  challenge_asked TEXT,
  challenge_answer TEXT,
  bill_ruling TEXT CHECK (bill_ruling IN ('accepted','rejected','amended')),
  final_text TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  CHECK (json_valid(evidence_refs_json)),
  CHECK (length(current_text) > 0),
  -- A proposal with no evidence behind it is an opinion about writing, and the whole point of
  -- persisting his record was so that improvements could rest on it.
  CHECK (proposed_text IS NULL OR json_array_length(evidence_refs_json) > 0)
) STRICT;
CREATE INDEX cv_lines_order_idx ON cv_lines(surface, line_no);
CREATE INDEX cv_lines_ruling_idx ON cv_lines(bill_ruling);`);
    const cols = db.prepare(`SELECT name FROM pragma_table_info('deliverables')`).all().map((r) => r.name);
    if (!cols.includes('origin')) {
      db.exec(`ALTER TABLE deliverables ADD COLUMN origin TEXT NOT NULL DEFAULT 'coach'`);
    }
  },

  /**
   * 7: debrief_capture — what a meeting actually produced, per meeting.
   *
   * Additive only. The role and interaction it belongs to already exist.
   */
  7: (db) => {
    const has = db.prepare(`SELECT COUNT(*) n FROM sqlite_master WHERE type='table' AND name='debrief_capture'`).get().n;
    if (!has) db.exec(`-- What actually happened in a meeting, near-verbatim, per meeting.
--
-- MEASURED 2026-08-22: Bill's own debrief of a founder call was "went alright, he liked the
-- Checker story" — a vibe and a compliment and no evidence. Coach ran fifteen questions and
-- moved on. Everything downstream eats from here: learnings, voice deltas, funnel movement, and
-- what the next brief knows. A thin debrief starves the whole system, and this material decays
-- faster than anything else in the product: what was asked, in what order, in their words, is
-- recoverable for about a day.
--
-- OPERATOR RULING 2026-08-23: a company opportunity is a SEQUENCE of meetings. Every row here
-- belongs to one meeting of one company, so round two can know what round one taught.
CREATE TABLE debrief_capture (
  id TEXT PRIMARY KEY,
  role_id TEXT NOT NULL,
  interaction_id TEXT,
  slot TEXT NOT NULL CHECK (slot IN (
    'what_was_asked','what_he_said','where_it_stalled','their_language',
    'signals_read','commitments_made','what_he_would_do_differently')),
  detail TEXT NOT NULL,
  verbatim TEXT,
  who TEXT,
  asked_twice INTEGER NOT NULL DEFAULT 0,
  flag_id TEXT,
  created_at TEXT NOT NULL,
  CHECK (length(detail) > 0),
  CHECK (asked_twice IN (0, 1))
) STRICT;
CREATE INDEX debrief_capture_role_idx ON debrief_capture(role_id, interaction_id);
CREATE INDEX debrief_capture_slot_idx ON debrief_capture(slot);`);
  },

  /**
   * 8: facts — what is known about a company and how well.
   *
   * Closes the gap between the funnel's written contract and what it enforced. Additive only.
   */
  8: (db) => {
    const has = db.prepare(`SELECT COUNT(*) n FROM sqlite_master WHERE type='table' AND name='facts'`).get().n;
    if (!has) db.exec(`-- What is known about a company, and how well it is known.
--
-- The funnel doctrine has always said P0 promotion needs "company facts sourced + as-of, 2
-- sources on funding", and the code checked only that Bill said go. Nothing counted sources.
-- A fact with no source and a fact with two independent ones looked identical in the output,
-- so the discipline existed only when the model happened to apply it.
--
-- Three tiers, enforced: no source may not appear; one source appears MARKED as single-sourced
-- where Bill can see it; and nothing without a second independent source may drive a decision.
CREATE TABLE facts (
  id TEXT PRIMARY KEY,
  role_id TEXT NOT NULL,
  kind TEXT NOT NULL CHECK (kind IN (
    'funding','headcount','revenue','product','customer','person','market','hiring','other')),
  claim TEXT NOT NULL,
  value_text TEXT,
  as_of TEXT NOT NULL,
  source TEXT NOT NULL,
  source_url TEXT,
  independent_of TEXT,
  confidence TEXT NOT NULL DEFAULT 'single' CHECK (confidence IN ('single','corroborated','contested')),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  CHECK (length(claim) > 0),
  CHECK (length(source) > 0)
) STRICT;
CREATE INDEX facts_role_idx ON facts(role_id, kind);
CREATE INDEX facts_conf_idx ON facts(confidence);`);
    // BACKFILL. Every role already carries the source it was found through and the date that
    // was true, and the new P0 guard needs facts on file. Discarding what the roster already
    // knew would make 69 sourced companies un-promotable on upgrade, which is a migration
    // breaking working data rather than a rule being enforced. They land as SINGLE-sourced,
    // which is exactly what they are: enough to enter the funnel, not enough to carry a
    // funding claim into a decision.
    const now = new Date().toISOString();
    const ins = db.prepare(`INSERT INTO facts (id, role_id, kind, claim, value_text, as_of, source,
      source_url, independent_of, confidence, created_at, updated_at)
      VALUES (?, ?, 'other', ?, NULL, ?, ?, NULL, NULL, 'single', ?, ?)`);
    let n = 0;
    for (const r of db.prepare(`SELECT id, company, source, as_of FROM roles WHERE source IS NOT NULL AND source <> ''`).all()) {
      const already = db.prepare('SELECT COUNT(*) c FROM facts WHERE role_id = ?').get(r.id).c;
      if (already) continue;
      ins.run(`fact-seed-${r.id}`.slice(0, 60), r.id, `${r.company} entered the roster via ${r.source}`,
        r.as_of ?? now.slice(0, 10), r.source, now, now);
      n += 1;
    }
  },

  /**
   * 9: rehearsal_rounds — what was practised, and whether it held. Additive only.
   */
  9: (db) => {
    const has = db.prepare(`SELECT COUNT(*) n FROM sqlite_master WHERE type='table' AND name='rehearsal_rounds'`).get().n;
    if (!has) db.exec(`-- Rehearsal: what was put to him, what he said, and whether it held.
--
-- MEASURED 2026-08-22: the rehearsal module produced 5,458 characters, the least of any module
-- in the product, for the one thing whose entire purpose is repetition under pressure. It asked
-- its questions, got answers, and stopped. That is a conversation about rehearsal.
--
-- The tight five's own standard is "rote-learned, line by line, deliverable at three in the
-- morning", and nothing in the product moved anything toward it.
--
-- The gate on this table is INVERTED: every other gate blocks output, this one blocks STOPPING.
-- The module may not close while an answer is still weak.
CREATE TABLE rehearsal_rounds (
  id TEXT PRIMARY KEY,
  role_id TEXT,
  interaction_id TEXT,
  topic TEXT NOT NULL,
  question TEXT NOT NULL,
  escalation INTEGER NOT NULL DEFAULT 1,
  round INTEGER NOT NULL DEFAULT 1,
  his_answer TEXT,
  verdict TEXT CHECK (verdict IN ('weak','holding','strong')),
  what_was_weak TEXT,
  source TEXT NOT NULL DEFAULT 'coach' CHECK (source IN ('coach','prep_brief','debrief','negotiation')),
  source_ref TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  CHECK (length(question) > 0),
  CHECK (escalation BETWEEN 1 AND 3),
  CHECK (round >= 1)
) STRICT;
CREATE INDEX rehearsal_topic_idx ON rehearsal_rounds(topic, round);
CREATE INDEX rehearsal_verdict_idx ON rehearsal_rounds(verdict);`);
  },

  /**
   * 10: positions_held — what he thinks, and whether he will say it publicly. Additive only.
   */
  10: (db) => {
    const has = db.prepare(`SELECT COUNT(*) n FROM sqlite_master WHERE type='table' AND name='positions_held'`).get().n;
    if (!has) db.exec(`-- What Bill actually thinks, and whether he will say it under his own name.
--
-- MEASURED 2026-08-22: the content module asked SIX questions, the fewest of any module in the
-- product, for the one whose entire input is his opinions — and then produced three posts. He
-- had also said plainly that he hates the idea of posting, which is a real objection the module
-- answered by writing posts anyway.
--
-- Content written without extraction is content written from nothing, and it reads like it.
CREATE TABLE positions_held (
  id TEXT PRIMARY KEY,
  position TEXT NOT NULL,
  evidence TEXT NOT NULL,
  who_disagrees TEXT,
  public_ok INTEGER,
  verbatim TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  CHECK (length(position) > 0),
  CHECK (length(evidence) > 0),
  CHECK (public_ok IS NULL OR public_ok IN (0, 1))
) STRICT;
CREATE INDEX positions_public_idx ON positions_held(public_ok);`);
  },

  /**
   * 11: facts lose their confidence hierarchy.
   *
   * OPERATOR RULING 2026-08-23: "coach comes preshipped with data which Bill can correct at any
   * time, and coach writes data to its stores on an ongoing basis too, which Bill can correct
   * at any time. Default state is all information is the same. No hierarchy of
   * validity/confirmation needed/approved."
   *
   * This is the SECOND time this hierarchy has been built and removed. The first was
   * confirmed/proposed on memories, dropped in migration 3. It came back as
   * single/corroborated/contested on facts, which is the same idea wearing a different word.
   * A fact still carries WHERE it came from and WHEN it was true, because that is provenance
   * and Bill may want to check it — but nothing ranks one row above another, and nothing is
   * gated on a row's standing.
   */
  11: (db) => {
    const cols = db.prepare(`SELECT name FROM pragma_table_info('facts')`).all().map((r) => r.name);
    if (!cols.includes('confidence') && !cols.includes('independent_of')) return;
    db.exec(`
      CREATE TABLE facts_new (
        id TEXT PRIMARY KEY,
        role_id TEXT NOT NULL,
        kind TEXT NOT NULL CHECK (kind IN (
          'funding','headcount','revenue','product','customer','person','market','hiring','other')),
        claim TEXT NOT NULL,
        value_text TEXT,
        as_of TEXT NOT NULL,
        source TEXT,
        source_url TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        CHECK (length(claim) > 0)
      ) STRICT;
      INSERT INTO facts_new (id, role_id, kind, claim, value_text, as_of, source, source_url, created_at, updated_at)
        SELECT id, role_id, kind, claim, value_text, as_of, source, source_url, created_at, updated_at FROM facts;
      DROP TABLE facts;
      ALTER TABLE facts_new RENAME TO facts;
      CREATE INDEX facts_role_idx ON facts(role_id, kind);
    `);
  },
};

function setSchemaVersion(db, version) {
  db.prepare(`UPDATE state_meta SET value = ?, updated_at = ? WHERE key = 'schema_version'`)
    .run(String(version), new Date().toISOString());
}

export async function migrateStateCopy(workDb, fromVersion, toVersion) {
  if (fromVersion === toVersion) return;
  if (fromVersion > toVersion) {
    throw new InstallError(`installed state schema ${fromVersion} is newer than package schema ${toVersion}; downgrade is not supported`);
  }
  const { DatabaseSync } = await import('node:sqlite');
  const db = new DatabaseSync(workDb);
  try {
    for (let target = fromVersion + 1; target <= toVersion; target += 1) {
      const step = MIGRATIONS[target];
      if (!step) throw new InstallError(`no migration path from state schema ${target - 1} to ${target}`);
      db.exec('BEGIN');
      try {
        step(db, { setSchemaVersion });
        setSchemaVersion(db, target);
        db.exec('COMMIT');
      } catch (err) {
        try { db.exec('ROLLBACK'); } catch { /* already rolled back */ }
        throw err instanceof InstallError ? err : new InstallError(`migration to schema ${target} failed: ${err.message}`);
      }
    }
  } finally {
    db.close();
  }
  const after = await readStateSchemaVersion(workDb);
  if (after !== toVersion) throw new InstallError(`migration finished on schema ${after}, expected ${toVersion}`);
}

// Runtime-acquired sources (sync_source appends, source_group 'sync:*') must survive a
// library replacement: merge them forward into the staged new library before the swap.
async function mergeForwardSyncedSources(livePath, stagedPath) {
  if (!fs.existsSync(livePath)) return 0;
  const { DatabaseSync } = await import('node:sqlite');
  const db = new DatabaseSync(stagedPath);
  let merged = 0;
  try {
    db.exec('PRAGMA foreign_keys = ON');
    db.prepare('ATTACH DATABASE ? AS live').run(livePath);
    const docs = db.prepare(`SELECT * FROM live.documents WHERE source_group LIKE 'sync:%'`).all();
    db.exec('BEGIN');
    for (const d of docs) {
      if (db.prepare(`SELECT 1 FROM documents WHERE id = ? OR content_sha256 = ?`).get(d.id, d.content_sha256)) continue;
      db.prepare(`INSERT INTO documents (id, kind, title, author, occurred_at, captured_at, authority_rank,
          authority_scope, media_type, language, source_group, external_id, parent_id, raw_content,
          extracted_text, content_sha256, status, attributes_json)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, ?, ?, ?, ?, ?)`)
        .run(d.id, d.kind, d.title, d.author, d.occurred_at, d.captured_at, d.authority_rank,
          d.authority_scope, d.media_type, d.language, d.source_group, d.external_id, d.raw_content,
          d.extracted_text, d.content_sha256, d.status, d.attributes_json);
      for (const c of db.prepare(`SELECT * FROM live.chunks WHERE document_id = ? ORDER BY sequence`).all(d.id)) {
        db.prepare(`INSERT INTO chunks (document_id, sequence, heading, speaker, started_at, ended_at, text, token_count, content_sha256, attributes_json)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
          .run(c.document_id, c.sequence, c.heading, c.speaker, c.started_at, c.ended_at, c.text, c.token_count, c.content_sha256, c.attributes_json);
      }
      for (const e of db.prepare(`SELECT * FROM live.document_entities WHERE document_id = ?`).all(d.id)) {
        db.prepare(`INSERT OR IGNORE INTO document_entities (document_id, entity, role) VALUES (?, ?, ?)`).run(e.document_id, e.entity, e.role);
      }
      for (const t of db.prepare(`SELECT * FROM live.document_topics WHERE document_id = ?`).all(d.id)) {
        db.prepare(`INSERT OR IGNORE INTO document_topics (document_id, topic) VALUES (?, ?)`).run(t.document_id, t.topic);
      }
      merged += 1;
    }
    // Relations last, and only where both endpoints exist in the merged library.
    for (const r of db.prepare(`
      SELECT r.* FROM live.document_relations r
      JOIN live.documents d ON d.id = r.from_document_id
      WHERE d.source_group LIKE 'sync:%'`).all()) {
      const both = db.prepare(`SELECT (SELECT 1 FROM documents WHERE id = ?) a, (SELECT 1 FROM documents WHERE id = ?) b`).get(r.from_document_id, r.to_document_id);
      if (both.a && both.b) {
        db.prepare(`INSERT OR IGNORE INTO document_relations (from_document_id, relation, to_document_id) VALUES (?, ?, ?)`)
          .run(r.from_document_id, r.relation, r.to_document_id);
        if (r.relation === 'supersedes') {
          db.prepare(`UPDATE documents SET status = 'superseded' WHERE id = ? AND status = 'active'`).run(r.to_document_id);
        }
      }
    }
    db.exec('COMMIT');
    db.exec('DETACH DATABASE live');
  } catch (err) {
    try { db.exec('ROLLBACK'); } catch { /* not in a transaction */ }
    db.close();
    throw err;
  }
  db.close();
  return merged;
}

function backupStateDb(P, oldVersion) {
  fs.mkdirSync(P.backups, { recursive: true });
  const stamp = new Date().toISOString().replace(/[-:]/g, '').replace(/\..*/, '');
  const target = path.join(P.backups, `coach-v${oldVersion}-${stamp}.sqlite`);
  fs.copyFileSync(P.stateDb, target);
  return target;
}

export function pruneBackups(P, keep = 2) {
  if (!fs.existsSync(P.backups)) return;
  const entries = fs.readdirSync(P.backups)
    .filter((n) => /^coach-v.+\.sqlite$/.test(n))
    .map((n) => ({ n, mtime: fs.statSync(path.join(P.backups, n)).mtimeMs }))
    .sort((a, b) => b.mtime - a.mtime);
  for (const { n } of entries.slice(keep)) fs.rmSync(path.join(P.backups, n), { force: true });
}

export async function performUpgrade(pkgRoot, preflight = {}) {
  await nodeGate();
  const manifest = preflight.manifest ?? validatePackage(pkgRoot);
  const claude = preflight.claude ?? claudeGate();
  const P = coachPaths();
  const marker = readMarker(P);
  if (!marker) throw new InstallError(`no installed coach found at ${P.profile}; run install/install.mjs instead`);

  const cmp = versionCompare(manifest.version, marker.version);
  if (cmp === 0) return 'already current';
  if (cmp < 0) throw new InstallError(`installed version ${marker.version} is newer than package version ${manifest.version}`);

  const rand = crypto.randomBytes(5).toString('hex');
  const dataParent = path.dirname(P.pluginDir);
  const stage = path.join(dataParent, `.stage-${rand}`);
  const workDir = path.join(P.tmp, `migrate-${rand}`);
  fs.mkdirSync(P.tmp, { recursive: true });

  // 1. Back up durable state before anything else.
  backupStateDb(P, marker.version);

  let prev = null;
  let workDb = null;
  let schemaChanged = false;
  try {
    // 2. Stage new code + library.
    fs.mkdirSync(stage, { recursive: true });
    const srcPlugin = path.join(pkgRoot, 'plugin');
    for (const name of fs.readdirSync(srcPlugin)) {
      if (name === '.DS_Store') continue;
      fs.cpSync(path.join(srcPlugin, name), path.join(stage, name), { recursive: true });
    }
    for (const entry of manifest.files) {
      if (entry.executable === true && entry.path.startsWith('plugin/')) {
        chmodIfPosix(path.join(stage, entry.path.slice('plugin/'.length)), 0o755);
      }
    }
    fs.mkdirSync(path.join(stage, 'library'), { recursive: true });
    fs.copyFileSync(path.join(pkgRoot, 'library', 'library.sqlite'), path.join(stage, 'library', 'library.sqlite'));
    const mergedForward = await mergeForwardSyncedSources(
      path.join(P.pluginDir, 'library', 'library.sqlite'),
      path.join(stage, 'library', 'library.sqlite'),
    );
    if (mergedForward > 0) process.stderr.write(`merged forward ${mergedForward} runtime-synced source document(s)\n`);
    await integrityCheck(path.join(stage, 'library', 'library.sqlite'));

    // 3. Migrate a copy of the live state db.
    fs.mkdirSync(workDir, { recursive: true });
    workDb = path.join(workDir, 'coach.sqlite');
    fs.copyFileSync(P.stateDb, workDb);
    const currentSchema = await readStateSchemaVersion(workDb);
    schemaChanged = currentSchema !== manifest.schema_version;
    await migrateStateCopy(workDb, currentSchema, manifest.schema_version);
    await integrityCheck(workDb);

    // 4. Probe the staged runtime with the migrated state and new library (on copies).
    await verifyPluginTree(stage, {
      stateDb: workDb,
      libraryDb: path.join(stage, 'library', 'library.sqlite'),
      scratchParent: workDir,
    });
  } catch (err) {
    rmBestEffort(stage);
    rmBestEffort(workDir);
    throw err;
  }

  // 5. Swap. The prior version is parked beside the live dir until success.
  prev = path.join(dataParent, `.prev-${marker.version}-${rand}`);
  const swappable = [...CODE_ENTRIES, 'library'];
  const parked = [];
  const placed = [];
  const priorSettings = fs.existsSync(P.settings) ? fs.readFileSync(P.settings, 'utf8') : null;
  const priorMcp = fs.existsSync(P.mcpConfig) ? fs.readFileSync(P.mcpConfig, 'utf8') : null;
  let stateSwapped = false;
  try {
    fs.mkdirSync(prev, { recursive: true });
    for (const name of swappable) {
      const live = path.join(P.pluginDir, name);
      if (fs.existsSync(live)) {
        fs.renameSync(live, path.join(prev, name));
        parked.push(name);
      }
    }
    for (const name of fs.readdirSync(stage)) {
      fs.renameSync(path.join(stage, name), path.join(P.pluginDir, name));
      placed.push(name);
    }
    if (schemaChanged) {
      fs.renameSync(P.stateDb, path.join(prev, 'coach.sqlite.pre-migration'));
      fs.renameSync(workDb, P.stateDb);
      stateSwapped = true;
    }
    // Re-render sealed configs from the new package (templates may have changed).
    const rendered = renderSealedConfigs(pkgRoot, P);
    fs.writeFileSync(P.settings, rendered.settings);
    fs.writeFileSync(P.mcpConfig, rendered.mcp);
    writeUserScopeMcp(P, rendered.mcp);
    writeMarker(P, manifest);
  } catch (err) {
    // Roll back to the parked prior version and prior state.
    for (const name of placed) fs.rmSync(path.join(P.pluginDir, name), { recursive: true, force: true });
    for (const name of parked) {
      try { fs.renameSync(path.join(prev, name), path.join(P.pluginDir, name)); } catch { /* keep restoring */ }
    }
    if (stateSwapped) {
      try {
        fs.rmSync(P.stateDb, { force: true });
        fs.renameSync(path.join(prev, 'coach.sqlite.pre-migration'), P.stateDb);
      } catch { /* backup in backups/ still holds the state */ }
    }
    if (priorSettings !== null) fs.writeFileSync(P.settings, priorSettings);
    if (priorMcp !== null) fs.writeFileSync(P.mcpConfig, priorMcp);
    try { writeMarker(P, { version: marker.version, schema_version: marker.schema_version }); } catch { /* marker restore best effort */ }
    rmBestEffort(prev);
    rmBestEffort(stage);
    rmBestEffort(workDir);
    throw err instanceof InstallError ? err : new InstallError(`upgrade swap failed: ${err.message}`);
  }

  // 6. Verified: drop the parked prior version, refresh launcher, prune backups.
  rmBestEffort(prev);
  rmBestEffort(stage);
  rmBestEffort(workDir);
  installLauncher(pkgRoot, claude.dir, P.home);
  pruneBackups(P, 2);
  return 'upgraded';
}

if (isMain(import.meta.url)) {
  runCli(() => performUpgrade(packageRootFromInstaller(import.meta.url)));
}
