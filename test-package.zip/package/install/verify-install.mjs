#!/usr/bin/env node
// bill-coach — post-install sanity check. Runs on the machine Coach was just
// installed on and proves the parts that only a real install can prove: the
// launcher is reachable as a command, the sealed profile is intact, both
// databases open, and the skills entry resolves.
//
// Prints exactly one line: `ok` or `failed: <reason>`.
// Cross-platform; on Windows it must be run from a PowerShell window opened
// AFTER the install, because the PATH change does not reach open windows.

import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import {
  InstallError,
  IS_WINDOWS,
  LAUNCHER_NAME,
  MIN_CLAUDE,
  MIN_NODE,
  commandCandidates,
  coachPaths,
  defaultLauncherDir,
  integrityCheck,
  isMain,
  launcherFileName,
  readMarker,
  runCli,
  versionCompare,
} from './install.mjs';

function fail(reason) {
  // InstallError is what runCli renders as a clean `failed: <reason>` line.
  throw new InstallError(reason);
}

/** Resolve `coach` the way the user's shell would. */
function findLauncherOnPath() {
  for (const dir of (process.env.PATH || '').split(path.delimiter).filter(Boolean)) {
    for (const candidate of commandCandidates(dir, LAUNCHER_NAME)) {
      try {
        if (fs.statSync(candidate).isFile()) return candidate;
      } catch { /* not here */ }
    }
  }
  return null;
}

async function verify() {
  const P = coachPaths();

  // 1. Node itself.
  if (versionCompare(process.versions.node, MIN_NODE) < 0) {
    fail(`Node >= ${MIN_NODE} required (found ${process.versions.node})`);
  }
  let sqlite;
  try {
    sqlite = await import('node:sqlite');
  } catch {
    fail('this Node build lacks node:sqlite');
  }
  // Coach search depends on FTS5, which Node 22.13's bundled SQLite lacks.
  try {
    const probe = new sqlite.DatabaseSync(':memory:');
    try { probe.exec('CREATE VIRTUAL TABLE fts5_probe USING fts5(x)'); } finally { probe.close(); }
  } catch (err) {
    fail(`this Node build has no SQLite FTS5 module (${err.message}); Node >= ${MIN_NODE} is required`);
  }

  // 2. Launcher reachable as a bare command.
  const onPath = findLauncherOnPath();
  if (!onPath) {
    const expected = path.join(defaultLauncherDir(), launcherFileName());
    const hint = IS_WINDOWS
      ? 'open a NEW PowerShell window (the PATH change does not reach windows that were already open)'
      : 'open a new terminal window, or source your shell profile';
    fail(fs.existsSync(expected)
      ? `${LAUNCHER_NAME} is installed at ${expected} but is not on PATH — ${hint}`
      : `${LAUNCHER_NAME} was not found on PATH and is not at ${expected}`);
  }

  // 3. On Windows the launcher is a pair: the .cmd shim plus the .mjs it calls.
  if (IS_WINDOWS) {
    const script = path.join(path.dirname(onPath), `${LAUNCHER_NAME}.mjs`);
    if (!fs.existsSync(script)) fail(`launcher shim at ${onPath} has no ${LAUNCHER_NAME}.mjs beside it`);
    const shim = fs.readFileSync(onPath, 'utf8');
    if (!/^@echo off/m.test(shim)) fail(`launcher shim at ${onPath} is not the expected .cmd wrapper`);
  }

  // 4. Sealed profile.
  for (const [what, p] of [
    ['settings', P.settings],
    ['MCP configuration', P.mcpConfig],
    ['workspace', P.workspace],
    ['coach runtime', P.serverEntry],
    ['library database', P.libraryDb],
    ['state database', P.stateDb],
  ]) {
    if (!fs.existsSync(p)) fail(`${what} missing at ${p}`);
  }

  // 5. Skills entry must resolve to the plugin dir (symlink on POSIX, junction on Windows).
  // Both sides go through realpath: any symlink on the way to the profile (on
  // macOS /var -> /private/var, on Windows a redirected profile folder) would
  // otherwise make two identical locations compare unequal.
  const skillsEntry = path.join(P.profile, 'skills', 'bill-career-coach');
  let resolved;
  try {
    resolved = fs.realpathSync(skillsEntry);
  } catch {
    fail(`skills entry ${skillsEntry} does not resolve (the junction/symlink is broken)`);
  }
  let expected;
  try {
    expected = fs.realpathSync(P.pluginDir);
  } catch {
    fail(`plugin directory ${P.pluginDir} does not resolve`);
  }
  // Windows paths are case-insensitive; POSIX paths are not.
  const samePath = IS_WINDOWS
    ? path.resolve(resolved).toLowerCase() === path.resolve(expected).toLowerCase()
    : path.resolve(resolved) === path.resolve(expected);
  if (!samePath) fail(`skills entry points at ${resolved}, expected ${expected}`);

  // 6. Databases open and pass integrity check.
  await integrityCheck(P.libraryDb);
  await integrityCheck(P.stateDb);

  // 7. Version marker.
  const marker = readMarker(P);
  if (!marker || !marker.version) fail('version marker missing or unreadable');

  // 8. Claude Code reachable at the required version.
  const claudeProbe = spawnSync(
    IS_WINDOWS ? 'cmd.exe' : 'sh',
    IS_WINDOWS ? ['/c', 'claude --version'] : ['-c', 'claude --version'],
    { encoding: 'utf8', timeout: 20000 },
  );
  const version = claudeProbe.status === 0 ? (String(claudeProbe.stdout).match(/(\d+\.\d+\.\d+)/) || [])[1] : null;
  if (!version) fail('Claude Code not reachable on PATH');
  if (versionCompare(version, MIN_CLAUDE) < 0) fail(`Claude Code >= ${MIN_CLAUDE} required (found ${version})`);

  return `ok (coach ${marker.version} at ${onPath}, claude ${version}, node ${process.versions.node})`;
}

if (isMain(import.meta.url)) runCli(verify);

export { verify };
