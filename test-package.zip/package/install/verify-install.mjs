#!/usr/bin/env node
// bill-coach — post-install sanity check. Runs on the machine Coach was just
// installed on and proves the parts that only a real install can prove: the
// launcher is reachable as a command, the sealed profile is intact, the Bill
// seed domains and search indexes are populated, the skills entry resolves,
// the user-scope MCP registration matches, and the runtime answers a complete
// lifecycle probe against safe database snapshots.
//
// Prints exactly one line: `ok` or `failed: <reason>`.
// Cross-platform; on Windows it must be run from a PowerShell window opened
// AFTER the install, because the PATH change does not reach open windows.

import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { isDeepStrictEqual } from 'node:util';
import {
  InstallError,
  IS_WINDOWS,
  LAUNCHER_NAME,
  MIN_CLAUDE,
  MIN_NODE,
  commandCandidates,
  coachPaths,
  defaultLauncherDir,
  integrityCheck,
  isMain,
  launcherFileName,
  packageRootFromInstaller,
  probeServer,
  readMarker,
  runCli,
  validatePackage,
  versionCompare,
} from './install.mjs';

function fail(reason) {
  // InstallError is what runCli renders as a clean `failed: <reason>` line.
  throw new InstallError(reason);
}

function requireRows(db, tables, databaseLabel) {
  for (const table of tables) {
    let row;
    try {
      row = db.prepare(`SELECT 1 AS present FROM ${table} LIMIT 1`).get();
    } catch (err) {
      fail(`${databaseLabel} is missing required data domain ${table} (${err.message})`);
    }
    if (!row) fail(`${databaseLabel} has no required ${table} data`);
  }
}

function requireFtsSearch(db, table, column, databaseLabel) {
  const rows = db.prepare(`SELECT ${column} AS text FROM ${table} LIMIT 32`).all();
  const token = rows
    .map((row) => String(row.text || '').match(/[\p{L}\p{N}]{4,}/u)?.[0])
    .find(Boolean);
  if (!token) fail(`${databaseLabel} ${table} has no searchable content`);
  const match = db.prepare(`SELECT 1 AS present FROM ${table} WHERE ${table} MATCH ? LIMIT 1`).get(`"${token.replaceAll('"', '""')}"`);
  if (!match) fail(`${databaseLabel} ${table} search index did not return its own content`);
}

function verifyInstalledPopulation(sqlite, P, manifest) {
  let state;
  let library;
  try {
    state = new sqlite.DatabaseSync(P.stateDb, { readOnly: true });
    requireRows(state, [
      'principal_profile', 'roles', 'role_events', 'facts', 'memories',
      'investor_roster', 'green_flags', 'onboarding', 'settings', 'state_meta',
    ], 'state database');
    const stateMeta = new Map(state.prepare('SELECT key, value FROM state_meta').all().map((row) => [row.key, row.value]));
    if (stateMeta.get('schema_version') !== String(manifest.schema_version)) fail('state database schema version differs from the package');
    if (stateMeta.get('app_version') !== manifest.app_version) fail('state database app version differs from the package');
    if (stateMeta.get('library_version') !== manifest.library_version) fail('state database library version differs from the package');
    if (!state.prepare('SELECT 1 AS present FROM memories WHERE sensitive = 1 LIMIT 1').get()) {
      fail('state database has no protected principal memory');
    }
    requireFtsSearch(state, 'state_fts', 'text', 'state database');

    library = new sqlite.DatabaseSync(P.libraryDb, { readOnly: true });
    requireRows(library, ['documents', 'chunks', 'doctrine', 'market_deals', 'library_meta'], 'library database');
    const kind = library.prepare(`SELECT value FROM library_meta WHERE key = 'library_kind'`).get()?.value;
    if (kind !== 'bill-career-coach') fail('library database has the wrong product identity');
    const libraryVersion = library.prepare(`SELECT value FROM library_meta WHERE key = 'library_version'`).get()?.value;
    if (libraryVersion !== manifest.library_version) fail('library database version differs from the package');
    for (const [fts, base, column] of [
      ['chunks_fts', 'chunks', 'text'],
      ['doctrine_fts', 'doctrine', 'insight'],
      ['market_deals_fts', 'market_deals', 'company'],
    ]) {
      const indexed = Number(library.prepare(`SELECT COUNT(*) AS n FROM ${fts}`).get().n);
      const source = Number(library.prepare(`SELECT COUNT(*) AS n FROM ${base}`).get().n);
      if (indexed === 0 || indexed !== source) fail(`library database ${fts} is incomplete`);
      requireFtsSearch(library, fts, column, 'library database');
    }
  } catch (err) {
    if (err instanceof InstallError) throw err;
    fail(`cannot verify installed population (${err.message})`);
  } finally {
    try { state?.close(); } catch { /* already closed */ }
    try { library?.close(); } catch { /* already closed */ }
  }
}

function verifyMcpRegistration(P) {
  let sealed;
  let registered;
  try {
    sealed = JSON.parse(fs.readFileSync(P.mcpConfig, 'utf8'))?.mcpServers?.['bill-coach'];
    registered = JSON.parse(fs.readFileSync(P.userConfig, 'utf8'))?.mcpServers?.['bill-coach'];
  } catch (err) {
    fail(`cannot read MCP registration (${err.message})`);
  }
  if (!sealed || !registered) fail('bill-coach is absent from the sealed or user-scope MCP registration');
  if (!isDeepStrictEqual(registered, sealed)) {
    fail('user-scope bill-coach MCP registration differs from the sealed configuration');
  }
}

async function snapshotDatabase(sqlite, sourcePath, targetPath) {
  const source = new sqlite.DatabaseSync(sourcePath, { readOnly: true });
  try {
    await sqlite.backup(source, targetPath);
  } finally {
    source.close();
  }
}

async function verifyRuntimeOnSnapshots(sqlite, P) {
  fs.mkdirSync(P.tmp, { recursive: true });
  const scratch = fs.mkdtempSync(path.join(P.tmp, 'verify-install-'));
  try {
    fs.mkdirSync(path.join(scratch, 'state'), { recursive: true });
    fs.mkdirSync(path.join(scratch, 'library'), { recursive: true });
    await snapshotDatabase(sqlite, P.stateDb, path.join(scratch, 'state', 'coach.sqlite'));
    await snapshotDatabase(sqlite, P.libraryDb, path.join(scratch, 'library', 'library.sqlite'));
    await probeServer(P.serverEntry, scratch);
  } finally {
    try { fs.rmSync(scratch, { recursive: true, force: true }); } catch { /* verifier scratch only */ }
  }
}

/** Resolve `coach` the way the user's shell would. */
function findLauncherOnPath() {
  for (const dir of (process.env.PATH || '').split(path.delimiter).filter(Boolean)) {
    for (const candidate of commandCandidates(dir, LAUNCHER_NAME)) {
      try {
        if (fs.statSync(candidate).isFile()) return candidate;
      } catch { /* not here */ }
    }
  }
  return null;
}

async function verify() {
  const P = coachPaths();

  // 1. Node itself.
  if (versionCompare(process.versions.node, MIN_NODE) < 0) {
    fail(`Node >= ${MIN_NODE} required (found ${process.versions.node})`);
  }
  let sqlite;
  try {
    sqlite = await import('node:sqlite');
  } catch {
    fail('this Node build lacks node:sqlite');
  }
  const manifest = validatePackage(packageRootFromInstaller(import.meta.url));
  // Coach search depends on FTS5, which Node 22.13's bundled SQLite lacks.
  try {
    const probe = new sqlite.DatabaseSync(':memory:');
    try { probe.exec('CREATE VIRTUAL TABLE fts5_probe USING fts5(x)'); } finally { probe.close(); }
  } catch (err) {
    fail(`this Node build has no SQLite FTS5 module (${err.message}); Node >= ${MIN_NODE} is required`);
  }

  // 2. Launcher reachable as a bare command.
  const onPath = findLauncherOnPath();
  if (!onPath) {
    const expected = path.join(defaultLauncherDir(), launcherFileName());
    const hint = IS_WINDOWS
      ? 'open a NEW PowerShell window (the PATH change does not reach windows that were already open)'
      : 'open a new terminal window, or source your shell profile';
    fail(fs.existsSync(expected)
      ? `${LAUNCHER_NAME} is installed at ${expected} but is not on PATH — ${hint}`
      : `${LAUNCHER_NAME} was not found on PATH and is not at ${expected}`);
  }

  // 3. On Windows the launcher is a pair: the .cmd shim plus the .mjs it calls.
  if (IS_WINDOWS) {
    const script = path.join(path.dirname(onPath), `${LAUNCHER_NAME}.mjs`);
    if (!fs.existsSync(script)) fail(`launcher shim at ${onPath} has no ${LAUNCHER_NAME}.mjs beside it`);
    const shim = fs.readFileSync(onPath, 'utf8');
    if (!/^@echo off/m.test(shim)) fail(`launcher shim at ${onPath} is not the expected .cmd wrapper`);
  }

  // 4. Sealed profile.
  for (const [what, p] of [
    ['settings', P.settings],
    ['MCP configuration', P.mcpConfig],
    ['user-scope MCP registration', P.userConfig],
    ['workspace', P.workspace],
    ['coach runtime', P.serverEntry],
    ['library database', P.libraryDb],
    ['state database', P.stateDb],
  ]) {
    if (!fs.existsSync(p)) fail(`${what} missing at ${p}`);
  }

  // 5. Skills entry must resolve to the plugin dir (symlink on POSIX, junction on Windows).
  // Both sides go through realpath: any symlink on the way to the profile (on
  // macOS /var -> /private/var, on Windows a redirected profile folder) would
  // otherwise make two identical locations compare unequal.
  const skillsEntry = path.join(P.profile, 'skills', 'bill-career-coach');
  let resolved;
  try {
    resolved = fs.realpathSync(skillsEntry);
  } catch {
    fail(`skills entry ${skillsEntry} does not resolve (the junction/symlink is broken)`);
  }
  let expected;
  try {
    expected = fs.realpathSync(P.pluginDir);
  } catch {
    fail(`plugin directory ${P.pluginDir} does not resolve`);
  }
  // Windows paths are case-insensitive; POSIX paths are not.
  const samePath = IS_WINDOWS
    ? path.resolve(resolved).toLowerCase() === path.resolve(expected).toLowerCase()
    : path.resolve(resolved) === path.resolve(expected);
  if (!samePath) fail(`skills entry points at ${resolved}, expected ${expected}`);

  // 6. Databases open and pass integrity check.
  await integrityCheck(P.libraryDb);
  await integrityCheck(P.stateDb);
  verifyInstalledPopulation(sqlite, P, manifest);
  verifyMcpRegistration(P);
  await verifyRuntimeOnSnapshots(sqlite, P);

  // 7. Version marker.
  const marker = readMarker(P);
  if (!marker || !marker.version) fail('version marker missing or unreadable');
  if (marker.version !== manifest.version) fail('installed version marker differs from this package');
  if (marker.schema_version !== manifest.schema_version) fail('installed schema marker differs from this package');

  // 8. Claude Code reachable at the required version.
  const claudeProbe = spawnSync(
    IS_WINDOWS ? 'cmd.exe' : 'sh',
    IS_WINDOWS ? ['/c', 'claude --version'] : ['-c', 'claude --version'],
    { encoding: 'utf8', timeout: 20000 },
  );
  const version = claudeProbe.status === 0 ? (String(claudeProbe.stdout).match(/(\d+\.\d+\.\d+)/) || [])[1] : null;
  if (!version) fail('Claude Code not reachable on PATH');
  if (versionCompare(version, MIN_CLAUDE) < 0) fail(`Claude Code >= ${MIN_CLAUDE} required (found ${version})`);

  return `ok (coach ${marker.version}; populated data; MCP registered and responding; claude ${version}; node ${process.versions.node})`;
}

if (isMain(import.meta.url)) runCli(verify);

export { verify };
