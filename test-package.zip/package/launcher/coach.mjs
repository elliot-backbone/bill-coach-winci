#!/usr/bin/env node
// bill-coach — sealed launcher for the Bill Jennings Coach.
//
// Installed on PATH as `bill-coach` by install/install.mjs. Self-contained:
// resolves the official claude binary (never itself, never a shadow), verifies
// versions, sets the sealed profile environment and launches Claude Code against
// the dedicated CLAUDE_CONFIG_DIR with a strict MCP configuration.
//
// Requires Node >= 24.0.0 (node:sqlite with FTS5) and Claude Code >= 2.1.207.

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawn, spawnSync } from 'node:child_process';

const PROFILE_DIR_NAME = '.claude-bill-career-coach';
const MIN_NODE = '24.0.0';
const MIN_CLAUDE = '2.1.0';

function die(message) {
  process.stderr.write(`bill-coach: ${message}\n`);
  process.exit(1);
}

function versionCompare(a, b) {
  const pa = String(a).split('.').map((n) => parseInt(n, 10) || 0);
  const pb = String(b).split('.').map((n) => parseInt(n, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i += 1) {
    const d = (pa[i] ?? 0) - (pb[i] ?? 0);
    if (d !== 0) return d < 0 ? -1 : 1;
  }
  return 0;
}

function realpathOrNull(p) {
  try { return fs.realpathSync(p); } catch { return null; }
}

const IS_WINDOWS = process.platform === 'win32';

/** Executable extensions, lowercased, in PATHEXT order. Empty on POSIX. */
function pathExtensions() {
  if (!IS_WINDOWS) return [''];
  const raw = process.env.PATHEXT || '.COM;.EXE;.BAT;.CMD';
  return raw.split(';').map((e) => e.trim().toLowerCase()).filter(Boolean);
}

function isExecutableFile(p) {
  try {
    if (!fs.statSync(p).isFile()) return false;
    // Windows has no exec bit; the extension is the only real signal.
    if (IS_WINDOWS) return pathExtensions().includes(path.extname(p).toLowerCase());
    fs.accessSync(p, fs.constants.X_OK);
    return true;
  } catch {
    return false;
  }
}

/**
 * Node refuses to execute .cmd/.bat without a shell (CVE-2024-27980), and on
 * Windows `claude` is exactly that.
 */
function needsShell(bin) {
  return IS_WINDOWS && /\.(cmd|bat)$/i.test(bin);
}

function spawnOptionsFor(bin, base) {
  if (needsShell(bin)) return { ...base, shell: true };
  return base;
}

/**
 * With shell:true Node concatenates argv without quoting, so an argument holding
 * a space ("start coach", or a profile path under C:\Users\First Last) would be
 * split into several. Node 24 deprecates that combination outright (DEP0190),
 * so we quote here and hand cmd.exe a single command string instead.
 */
function cmdQuote(s) {
  return /[\s"&|<>^()]/.test(String(s)) ? `"${String(s).replace(/"/g, '""')}"` : String(s);
}

function shellCommandFor(bin, args) {
  return [cmdQuote(bin), ...args.map(cmdQuote)].join(' ');
}

/** Find the official claude binary on PATH, excluding this launcher's own directory. */
function resolveClaude(ownDir) {
  const ownReal = ownDir ? realpathOrNull(ownDir) : null;
  for (const entry of (process.env.PATH || '').split(path.delimiter)) {
    if (!entry) continue;
    const real = realpathOrNull(entry);
    if (ownReal && real === ownReal) continue;
    for (const ext of pathExtensions()) {
      const candidate = path.join(entry, `claude${ext}`);
      if (isExecutableFile(candidate)) return candidate;
    }
  }
  return null;
}

// --- runtime gates -----------------------------------------------------------

if (versionCompare(process.versions.node, MIN_NODE) < 0) {
  die(`Node >= ${MIN_NODE} required (found ${process.versions.node}); install current Node LTS from nodejs.org`);
}
let sqliteModule;
try {
  sqliteModule = await import('node:sqlite');
} catch {
  die(`this Node build lacks node:sqlite; install standard Node >= ${MIN_NODE} from nodejs.org`);
}
// Coach search needs FTS5. Node 22.13 shipped SQLite 3.47.2 without it on every
// platform; without this check the session dies later with an opaque error.
try {
  const probe = new sqliteModule.DatabaseSync(':memory:');
  try {
    probe.exec('CREATE VIRTUAL TABLE fts5_probe USING fts5(x)');
  } finally {
    probe.close();
  }
} catch (err) {
  die(`this Node build has no SQLite FTS5 module (${err.message}); install Node >= ${MIN_NODE} from nodejs.org`);
}

const home = process.env.BILL_COACH_HOME || os.homedir();
const profile = path.join(home, PROFILE_DIR_NAME);
const workspace = path.join(profile, 'workspace');
const mcpConfig = path.join(profile, 'mcp', 'coach-mcp.json');
const settings = path.join(profile, 'settings.json');
const serverEntry = path.join(profile, 'plugins', 'data', 'bill-career-coach-skills-dir', 'runtime', 'server.mjs');

for (const [what, p] of [['settings', settings], ['MCP configuration', mcpConfig], ['workspace', workspace], ['coach runtime', serverEntry]]) {
  if (!fs.existsSync(p)) die(`coach ${what} not found at ${p}; run the installer (node install/install.mjs from the coach package) first`);
}

const ownDir = process.argv[1] ? path.dirname(realpathOrNull(process.argv[1]) ?? path.resolve(process.argv[1])) : null;
const claudeBin = resolveClaude(ownDir);
if (!claudeBin) {
  die('Claude Code not found on PATH; install it first (see claude.com/claude-code, e.g. `npm install -g @anthropic-ai/claude-code`)');
}
const versionOut = needsShell(claudeBin)
  ? spawnSync(shellCommandFor(claudeBin, ['--version']), { shell: true, encoding: 'utf8', timeout: 15000 })
  : spawnSync(claudeBin, ['--version'], { encoding: 'utf8', timeout: 15000 });
const claudeVersion = versionOut.status === 0 ? (String(versionOut.stdout).match(/(\d+\.\d+\.\d+)/) || [])[1] : null;
if (!claudeVersion) die(`could not determine Claude Code version from ${claudeBin}`);
if (versionCompare(claudeVersion, MIN_CLAUDE) < 0) {
  die(`Claude Code >= ${MIN_CLAUDE} required (found ${claudeVersion}); run \`claude update\` first`);
}

// --- sealed environment (provider contract §8) -------------------------------

const env = {
  ...process.env,
  CLAUDE_CONFIG_DIR: profile,
  CLAUDE_CODE_DISABLE_AUTO_MEMORY: '1',
  CLAUDE_CODE_SKIP_PROMPT_HISTORY: '1',
  CLAUDE_CODE_DISABLE_BACKGROUND_TASKS: '1',
  CLAUDE_CODE_DISABLE_BUNDLED_SKILLS: '1',
  CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC: '1',
  DISABLE_TELEMETRY: '1',
  DISABLE_ERROR_REPORTING: '1',
  DISABLE_AUTOUPDATER: '1',
  CLAUDE_CODE_DISABLE_WORKFLOWS: '1',
  CLAUDE_CODE_DISABLE_CRON: '1',
  CLAUDE_CODE_DISABLE_OFFICIAL_MARKETPLACE_AUTOINSTALL: '1',
  DISABLE_GROWTHBOOK: '1',
  CLAUDE_CODE_SESSIONEND_HOOKS_TIMEOUT_MS: '10000',
  CLAUDE_DISABLE_ADOPT: '1',
  CLAUDE_CODE_DISABLE_ARTIFACT: '1',
};

// The sealed MCP config invokes `node`; guarantee it resolves to this runtime.
const nodeDir = path.dirname(process.execPath);
const pathEntries = (env.PATH || '').split(path.delimiter);
if (!pathEntries.includes(nodeDir)) env.PATH = [nodeDir, ...pathEntries].join(path.delimiter);

// --- launch ------------------------------------------------------------------

const claudeArgs = [
  '--setting-sources', 'user',
  '--strict-mcp-config',
  '--mcp-config', mcpConfig,
  '--tools', 'WebSearch,WebFetch',
  'start coach',
];
const child = needsShell(claudeBin)
  ? spawn(shellCommandFor(claudeBin, claudeArgs), { shell: true, cwd: workspace, env, stdio: 'inherit' })
  : spawn(claudeBin, claudeArgs, { cwd: workspace, env, stdio: 'inherit' });

child.on('error', (err) => die(`failed to launch Claude Code: ${err.message}`));
// Windows has no SIGTERM; Ctrl-C reaches the child directly through the console
// group, so only SIGINT is worth forwarding there.
for (const sig of IS_WINDOWS ? ['SIGINT'] : ['SIGINT', 'SIGTERM']) {
  process.on(sig, () => { try { child.kill(sig); } catch { /* child already gone */ } });
}
child.on('exit', (code, signal) => {
  if (signal) {
    const n = os.constants.signals[signal];
    process.exit(n ? 128 + n : 1);
  }
  process.exit(code ?? 1);
});
