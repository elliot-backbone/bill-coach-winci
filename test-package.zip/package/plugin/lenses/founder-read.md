# founder-read.md (scrubbed)

Placeholder content for CI. The real file is not distributed outside Elliot's
machine. Structure and filename are preserved so the runtime loads normally.
