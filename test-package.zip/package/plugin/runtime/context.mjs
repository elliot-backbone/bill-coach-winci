// get_context: assemble evidence and memory for one active coaching question.
// Hybrid retrieval: active memory and current metrics first; FTS source candidates;
// recency/authority/entity reranking; doctrine selection; conflict surfacing.
// The selector must never return only confirming evidence when contradictory
// evidence is available: relation-linked corrections and the newest same-entity
// document are always pulled in.

import { ftsQueryFromText, blendScore } from './library.mjs';
import { computeStaleness } from './memory.mjs';

const MEMORY_LIMIT = 14;

export function scoreTextMatch(text, terms) {
  const lower = text.toLowerCase();
  let hits = 0;
  for (const t of terms) if (lower.includes(t)) hits += 1;
  return hits;
}

function queryTerms(question, entities) {
  const words = String(question).toLowerCase().match(/[\p{L}\p{N}][\p{L}\p{N}'-]*/gu) ?? [];
  const terms = new Set(words.filter((w) => w.length >= 3));
  for (const e of entities ?? []) terms.add(String(e).toLowerCase());
  return [...terms];
}

export function getContext(state, library, input, nowIso = new Date().toISOString()) {
  const { session_id: sessionId, question, entities = [], lens, as_of: asOf, max_chunks: maxChunks = 18 } = input;
  const now = Date.parse(asOf ?? nowIso);

  const session = state.prepare(`SELECT * FROM sessions WHERE id = ?`).get(sessionId);
  if (!session) return { error: `unknown session: ${sessionId}` };

  const terms = queryTerms(question, entities);

  // 1. Active memory, scored against the question.
  const memories = state.prepare(
    `SELECT id, type, subject, content, effective_at, sensitive FROM memories WHERE status = 'active'`
  ).all()
    .map((m) => ({ ...m, _score: scoreTextMatch(`${m.subject} ${m.content}`, terms) }))
    .sort((a, b) => b._score - a._score)
    .slice(0, MEMORY_LIMIT)
    .map(({ _score, ...m }) => m);

  // 2. Current metrics with staleness computed at read time.
  const metrics = state.prepare(
    `SELECT id, name, value_text, unit, definition, scope, as_of, staleness_class FROM metrics WHERE status = 'active' ORDER BY as_of DESC`
  ).all().map((m) => ({ ...m, stale: computeStaleness(m, now) }));
  const staleMetrics = metrics.filter((m) => m.stale);

  const commitments = state.prepare(
    `SELECT id, owner, commitment, due_at, next_review_at FROM commitments WHERE status = 'open' ORDER BY due_at IS NULL, due_at`
  ).all();

  // Bill's live artefacts, so a session opens holding the actual CV and the actual tight five
  // rather than reconstructing them from the learnings ledger. Bodies are carried whole for the
  // short ones and headed for the long: an accurate first line beats a summary, and Coach can
  // pull the rest with search_state when the work is about that artefact.
  const deliverables = (() => {
    try {
      return state.prepare(
        `SELECT id, kind, title, version, role_id, updated_at, body FROM deliverables
          WHERE status = 'live' ORDER BY updated_at DESC`,
      ).all().map((d) => ({
        ...d,
        body: d.body.length > 2400 ? `${d.body.slice(0, 2400)} …` : d.body,
        truncated: d.body.length > 2400,
      }));
    } catch {
      return []; // a database from before schema 4
    }
  })();

  // The green flag library in current rank order, and what the tight five actually has on
  // file. Both are carried into every session: the flags say what the interview is hunting,
  // and the coverage says how far off drafting it is. Held out of the orientation, a coverage
  // count exists only in a table nobody reads.
  const greenFlags = (() => {
    try {
      return state.prepare(
        `SELECT name, dimension, polarity, behaviour, evidence, question, anti_pattern, source,
                current_rank, times_surfaced, times_landed, rank_reason
           FROM green_flags WHERE status = 'active' ORDER BY current_rank`,
      ).all();
    } catch { return []; }
  })();

  // The meeting sequence per company, and what each meeting left behind. This is what makes a
  // second brief worth more than the first: it opens knowing what the last conversation
  // established rather than establishing it again.
  const companyMeetings = (() => {
    try {
      const inter = state.prepare(
        `SELECT id, role_id, kind, occurred_at FROM interactions ORDER BY occurred_at DESC LIMIT 40`,
      ).all();
      if (!inter.length) return null;
      const caps = state.prepare(
        'SELECT interaction_id, slot, detail, verbatim, asked_twice FROM debrief_capture',
      ).all();
      const byInteraction = {};
      for (const c of caps) (byInteraction[c.interaction_id] ??= []).push(c);
      return inter.map((i) => ({
        ...i,
        captured: (byInteraction[i.id] ?? []).length,
        debriefed: (byInteraction[i.id] ?? []).length > 0,
        asked_twice: (byInteraction[i.id] ?? []).filter((c) => c.asked_twice).map((c) => c.verbatim ?? c.detail),
      }));
    } catch { return null; }
  })();

  // His CV, and how far the pass has got. Carried so a session opens knowing which lines are
  // still unruled rather than rediscovering it.
  const cvLines = (() => {
    try {
      const rows = state.prepare('SELECT * FROM cv_lines ORDER BY surface, line_no').all();
      if (!rows.length) return null;
      const ruled = rows.filter((r) => r.bill_ruling);
      return {
        lines: rows.length,
        ruled: ruled.length,
        outstanding: rows.length - ruled.length,
        ready_to_assemble: ruled.length === rows.length,
        by_surface: Object.fromEntries([...new Set(rows.map((r) => r.surface))]
          .map((s) => [s, rows.filter((r) => r.surface === s).length])),
        next_unruled: rows.filter((r) => !r.bill_ruling).slice(0, 5)
          .map((r) => ({ line_no: r.line_no, surface: r.surface, current_text: r.current_text, proposed_text: r.proposed_text })),
      };
    } catch { return null; }
  })();

  const NARRATIVE_SLOTS = ['childhood', 'family_and_money', 'schooling', 'first_work',
    'professional_sequence', 'cost_and_doubt', 'turning_point', 'present_want'];
  const narrativeCoverage = (() => {
    try {
      const rows = state.prepare('SELECT * FROM narrative_coverage ORDER BY created_at').all();
      const bySlot = {};
      for (const s of NARRATIVE_SLOTS) bySlot[s] = [];
      for (const r of rows) (bySlot[r.slot] ??= []).push(r);
      const dated = NARRATIVE_SLOTS.filter((s) => bySlot[s].some((r) => r.age_or_date));
      return {
        scenes: rows.length,
        slots_covered: dated.length,
        slots_total: NARRATIVE_SLOTS.length,
        missing: NARRATIVE_SLOTS.filter((s) => !dated.includes(s)),
        ready_to_draft: dated.length === NARRATIVE_SLOTS.length,
        by_slot: bySlot,
      };
    } catch { return null; }
  })();

  const decisions = state.prepare(
    `SELECT id, decision, reason, made_at, outcome FROM decisions WHERE status = 'active'`
  ).all()
    .map((d) => ({ ...d, _score: scoreTextMatch(`${d.decision} ${d.reason ?? ''}`, terms) }))
    .sort((a, b) => b._score - a._score || (a.made_at < b.made_at ? 1 : -1))
    .slice(0, 6)
    .map(({ _score, ...d }) => d);

  // 3. FTS evidence candidates.
  const match = ftsQueryFromText(`${question} ${entities.join(' ')}`);
  let evidence = [];
  const byDocument = new Map();
  if (match) {
    const params = { match, cap: Math.max(maxChunks * 6, 80) };
    let timeFilter = '';
    if (asOf) { timeFilter = `AND (d.occurred_at IS NULL OR d.occurred_at <= :asof)`; params.asof = asOf; }
    const rows = library.prepare(`
      SELECT c.id AS chunk_id, c.document_id, c.sequence, c.heading, c.speaker, c.text,
             bm25(chunks_fts) AS rank,
             d.title, d.kind, d.author, d.occurred_at, d.authority_rank, d.status
      FROM chunks_fts
      JOIN chunks c ON c.id = chunks_fts.rowid
      JOIN documents d ON d.id = c.document_id
      WHERE chunks_fts MATCH :match ${timeFilter}
      ORDER BY rank LIMIT :cap
    `).all(params);

    const entitySet = new Set(entities.map((e) => e.toLowerCase()));
    const entityDocIds = new Set();
    if (entitySet.size) {
      for (const r of library.prepare(`SELECT document_id, entity FROM document_entities`).all()) {
        if (entitySet.has(r.entity.toLowerCase())) entityDocIds.add(r.document_id);
      }
    }

    const scored = rows.map((r) => ({
      ...r,
      score: blendScore(r.rank, r.authority_rank, r.occurred_at, now, entityDocIds.has(r.document_id) ? 0.6 : 0),
    })).sort((a, b) => b.score - a.score);

    const perDoc = new Map();
    for (const r of scored) {
      const n = perDoc.get(r.document_id) ?? 0;
      if (n >= 3 || evidence.length >= maxChunks) { if (evidence.length >= maxChunks) break; continue; }
      perDoc.set(r.document_id, n + 1);
      evidence.push(r);
      byDocument.set(r.document_id, r);
    }

    // Freshness guarantee: for every entity in play, include the newest matching
    // entity-tagged document even if FTS ranked it low.
    if (entityDocIds.size) {
      const newest = library.prepare(`
        SELECT d.id FROM documents d
        WHERE d.id IN (${[...entityDocIds].map(() => '?').join(',')}) AND d.status = 'active'
        ORDER BY d.occurred_at DESC LIMIT 2
      `).all(...entityDocIds);
      for (const { id } of newest) {
        if (byDocument.has(id)) continue;
        const top = library.prepare(
          `SELECT c.id AS chunk_id, c.document_id, c.sequence, c.heading, c.speaker, c.text,
                  d.title, d.kind, d.author, d.occurred_at, d.authority_rank, d.status
           FROM chunks c JOIN documents d ON d.id = c.document_id
           WHERE c.document_id = ? ORDER BY c.sequence LIMIT 1`
        ).get(id);
        if (top) { evidence.push({ ...top, score: 0, freshest_for_entity: true }); byDocument.set(id, top); }
      }
    }
  }

  // 4. Contradictory / superseding evidence via document relations.
  const conflicts = [];
  if (byDocument.size) {
    const ids = [...byDocument.keys()];
    const relations = library.prepare(`
      SELECT r.from_document_id, r.relation, r.to_document_id,
             df.title AS from_title, df.occurred_at AS from_occurred_at,
             dt.title AS to_title, dt.occurred_at AS to_occurred_at
      FROM document_relations r
      JOIN documents df ON df.id = r.from_document_id
      JOIN documents dt ON dt.id = r.to_document_id
      WHERE r.relation IN ('supersedes', 'corrects')
        AND (r.from_document_id IN (${ids.map(() => '?').join(',')})
          OR r.to_document_id IN (${ids.map(() => '?').join(',')}))
    `).all(...ids, ...ids);
    for (const rel of relations) {
      conflicts.push({
        current_document_id: rel.from_document_id,
        current_title: rel.from_title,
        current_occurred_at: rel.from_occurred_at,
        relation: rel.relation,
        superseded_document_id: rel.to_document_id,
        superseded_title: rel.to_title,
        superseded_occurred_at: rel.to_occurred_at,
      });
      // Make sure the controlling side of a conflict is present in evidence.
      if (!byDocument.has(rel.from_document_id)) {
        const top = library.prepare(
          `SELECT c.id AS chunk_id, c.document_id, c.sequence, c.heading, c.speaker, c.text,
                  d.title, d.kind, d.author, d.occurred_at, d.authority_rank, d.status
           FROM chunks c JOIN documents d ON d.id = c.document_id
           WHERE c.document_id = ? ORDER BY c.sequence LIMIT 1`
        ).get(rel.from_document_id);
        if (top) { evidence.push({ ...top, score: 0, controls_conflict: true }); byDocument.set(top.document_id, top); }
      }
    }
  }

  // 5. Doctrine: FTS over doctrine, lens-boosted rather than lens-restricted.
  let doctrine = [];
  if (match) {
    const drows = library.prepare(`
      SELECT d.id, d.lens, d.insight, d.applicability, d.counterindications, d.example,
             d.tags_json, bm25(doctrine_fts) AS rank
      FROM doctrine_fts JOIN doctrine d ON d.rowid = doctrine_fts.rowid
      WHERE doctrine_fts MATCH :match ORDER BY rank LIMIT 24
    `).all({ match });
    doctrine = drows
      .map((r) => ({ ...r, score: 1 / (1 + Math.max(0, r.rank)) + (lens && r.lens === lens ? 0.5 : 0) }))
      .sort((a, b) => b.score - a.score)
      .slice(0, 6)
      .map(({ rank, score, tags_json, ...d }) => ({ ...d, tags: JSON.parse(tags_json ?? '[]') }));
  }

  // 6. Missing information: entities with no evidence at all.
  const missing = [];
  for (const e of entities) {
    const hit = evidence.some((r) =>
      `${r.title} ${r.text}`.toLowerCase().includes(String(e).toLowerCase()));
    if (!hit) missing.push(`no library evidence found for "${e}"`);
  }
  for (const m of staleMetrics) {
    missing.push(`metric "${m.name}" is stale (as of ${m.as_of}); treat as historical until refreshed`);
  }

  return {
    current_state: {
      session_id: session.id,
      situation: session.situation,
      judgment: session.judgment,
      next_move: session.next_move,
      open_questions: JSON.parse(session.open_questions_json ?? '[]'),
    },
    evidence: evidence.map((r) => ({
      document_id: r.document_id,
      chunk_id: r.chunk_id,
      sequence: r.sequence,
      title: r.title,
      kind: r.kind,
      author: r.author,
      occurred_at: r.occurred_at,
      heading: r.heading,
      speaker: r.speaker,
      text: r.text.length > 1600 ? r.text.slice(0, 1600) + ' …' : r.text,
      ...(r.freshest_for_entity ? { freshest_for_entity: true } : {}),
      ...(r.controls_conflict ? { controls_conflict: true } : {}),
    })),
    memories,
    metrics,
    commitments,
    deliverables,
    green_flags: greenFlags,
    cv_lines: cvLines,
    company_meetings: companyMeetings,
    narrative_coverage: narrativeCoverage,
    decisions,
    doctrine,
    conflicts,
    stale_metrics: staleMetrics.map((m) => ({ id: m.id, name: m.name, as_of: m.as_of, staleness_class: m.staleness_class })),
    missing_information: missing,
  };
}
