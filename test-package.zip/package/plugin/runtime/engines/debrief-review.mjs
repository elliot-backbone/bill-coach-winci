// ENGINE debrief_review (Design V2 §4). Capture-slot status, transcript stats
// read FROM STATE (the hook pre-pass writes them at capture time — there is no
// transcript route into this process, measured 2026-08-24), asked_twice, and
// the compound join. What the moments MEAN, did-well selection and the
// improvement verdicts are the model's.
import { scaffold, computed, candidate, absence } from './shared.mjs';

const STATIC = Object.freeze({
  legend: 'sources: st=state row (id given) · calc=arithmetic from named inputs · pre=hook pre-pass at capture time',
  gate_rule_text: 'Capture before you write: a debrief document is blocked while more than three of the seven slots are empty. Near-verbatim beats summary. A question asked twice is the decision criterion. No phase change on a thin debrief.',
});

const SLOTS = ['what_was_asked', 'what_he_said', 'where_it_stalled', 'their_language', 'signals_read', 'commitments_made', 'do_differently'];

export function prepareDebriefReview(state, library, { role_id, interaction_id }) {
  const absences = [];
  const judgment = [];

  const interaction = state.prepare(
    `SELECT id, role_id, kind, round_number, occurred_at, review_json FROM interactions WHERE id = ? AND role_id = ?`
  ).get(interaction_id, role_id);
  if (!interaction) {
    return scaffold('debrief_review', STATIC, {
      data: {}, computed: {},
      gates: { blocked: true, missing: [`interaction ${interaction_id} for role ${role_id} not found`], facts: [] },
      judgment_points: [], absences: [absence('the interaction row', 'no such row', 'search_state(tables:["interactions"])')],
    });
  }

  const captures = state.prepare(
    `SELECT id, slot, detail, verbatim, who, asked_twice FROM debrief_capture WHERE interaction_id = ? ORDER BY created_at`
  ).all(interaction_id).map((c) => ({ ...c, src: `st:${c.id}` }));
  const filledSlots = new Set(captures.map((c) => c.slot));
  const emptySlots = SLOTS.filter((s) => !filledSlots.has(s));
  const blocked = emptySlots.length > 3;

  // Transcript stats: written by the hook pre-pass at capture time, if a
  // parseable transcript was in the turn. Absent = honest absence.
  let stats = null;
  try { stats = JSON.parse(interaction.review_json ?? '{}')?.transcript_stats ?? null; } catch { /* absence */ }
  if (!stats) absences.push(absence('transcript stats', 'no pre-pass stats on this interaction (no transcript in the capture turn, or unparseable)', 'drop the meeting transcript in a capture turn'));

  const askedTwice = state.prepare(
    `SELECT id, detail, who FROM debrief_capture WHERE role_id = ? AND asked_twice = 1 ORDER BY created_at DESC LIMIT 6`
  ).all(role_id).map((c) => ({ ...c, src: `st:${c.id}` }));

  // Compound rule: last round's focus points joined with THIS round's evidence
  // candidates. The improvement verdict per point is a judgment candidate.
  const prior = state.prepare(
    `SELECT id, round_number, review_json FROM interactions
     WHERE role_id = ? AND occurred_at < ? AND review_json IS NOT NULL ORDER BY occurred_at DESC LIMIT 1`
  ).get(role_id, interaction.occurred_at);
  let priorFocus = [];
  if (prior) {
    try { priorFocus = JSON.parse(prior.review_json)?.focus_next ?? []; } catch { /* absence */ }
    if (typeof priorFocus === 'string') priorFocus = [priorFocus];
  } else {
    absences.push(absence('a prior debrief to compound against', 'first debrief for this role', 'nothing — this IS the baseline round'));
  }
  if (priorFocus.length) {
    judgment.push(candidate('improvement', 'Per prior focus point: improved, unchanged, or worse — the join is mechanical, the verdict is yours, and say it plainly. Three rounds without movement means the point itself gets rethought.',
      `prior round ${prior.round_number ?? '?'} focus points joined with this round's captures`, priorFocus));
  }

  const verbatims = captures.filter((c) => c.verbatim).map((c) => ({ src: c.src, who: c.who, verbatim: c.verbatim })).slice(0, 8);
  judgment.push(candidate('meaning', 'What the moments mean; did-well selected ONLY from the quoted evidence supplied; the <=3 focus-next.', null));
  if (askedTwice.length) judgment.push(candidate('asked-twice', 'Each asked-twice question is a candidate decision criterion — is it THE one this opportunity turns on?', 'doctrine: a question asked twice is the decision criterion', askedTwice.map((a) => a.src)));

  // Serendipity channel (read-heavy engine — panel V4).
  const wide = state.prepare(
    `SELECT id, subject, substr(content, 1, 140) AS excerpt FROM memories WHERE status = 'active' ORDER BY updated_at DESC LIMIT 4`
  ).all().map((m) => ({ ...m, src: `st:${m.id}` }));

  return scaffold('debrief_review', STATIC, {
    data: { interaction: { id: interaction.id, kind: interaction.kind, round: interaction.round_number, occurred_at: interaction.occurred_at, src: `st:${interaction.id}` }, captures, verbatims, asked_twice: askedTwice, prior_focus: priorFocus, transcript_stats: stats ? { ...stats, src: 'pre' } : null },
    computed: { slot_status: computed({ filled: SLOTS.length - emptySlots.length, of: SLOTS.length, empty: emptySlots }, captures.map((c) => c.src)) },
    gates: { blocked, missing: blocked ? [`captures: ${emptySlots.length} of 7 slots empty (document blocked while >3 empty)`] : [], facts: [{ fact: 'empty_slots', value: emptySlots }] },
    judgment_points: judgment,
    wide_scan: wide,
    absences,
  });
}
