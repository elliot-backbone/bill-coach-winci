// MODULE PROGRESS BOARD (2.1.0) — the single source of truth for where the engagement stands,
// printed at session open from the SECOND session on and on the `progress` command. It is a
// computed VIEW over the rows each module writes, so "the board says X" and "the state is X" are
// the same statement. Operator-specced 2026-08-25 (DESIGN-MODULE-PROGRESS-BOARD): standardized
// per-module row — state, progress, depends-on, blocked-by, and the command to start it — in
// plain in-terminal text. Deterministic: the engine renders the board; the model prints it, never
// re-derives it by hand.
import { checkGates } from './shared.mjs';

const N = (state, sql, ...a) => { try { return state.prepare(sql).get(...a)?.n ?? 0; } catch { return 0; } };

function bar(done, total) {
  const width = 9;
  const filled = total > 0 ? Math.round((Math.min(done, total) / total) * width) : 0;
  return '█'.repeat(filled) + '░'.repeat(width - filled);
}

export function prepareModuleBoard(state, nowIso = null) {
  const coverage = N(state, `SELECT COUNT(DISTINCT slot) n FROM narrative_coverage WHERE age_or_date IS NOT NULL AND age_or_date <> ''`);
  const onePagerLive = N(state, `SELECT COUNT(*) n FROM deliverables WHERE kind='positioning_one_pager' AND status='live'`) > 0;
  const cvTotal = N(state, `SELECT COUNT(*) n FROM cv_lines WHERE surface='cv'`);
  const cvRuled = N(state, `SELECT COUNT(*) n FROM cv_lines WHERE surface='cv' AND bill_ruling IS NOT NULL AND bill_ruling <> ''`);
  const liTotal = N(state, `SELECT COUNT(*) n FROM cv_lines WHERE surface IN ('headline','about','experience')`);
  const liRuled = N(state, `SELECT COUNT(*) n FROM cv_lines WHERE surface IN ('headline','about','experience') AND bill_ruling IS NOT NULL AND bill_ruling <> ''`);
  const positions = N(state, `SELECT COUNT(*) n FROM positions_held`);
  const posts = N(state, `SELECT COUNT(*) n FROM deliverables WHERE kind='content'`);
  const outreachSent = N(state, `SELECT COUNT(*) n FROM deliverables WHERE kind='outreach'`);
  const prepBriefs = N(state, `SELECT COUNT(*) n FROM deliverables WHERE kind='prep_brief'`);
  const rounds = N(state, `SELECT COUNT(*) n FROM rehearsal_rounds`);
  const negRounds = N(state, `SELECT COUNT(*) n FROM rehearsal_rounds WHERE source='negotiation'`);
  const strongRounds = N(state, `SELECT COUNT(*) n FROM rehearsal_rounds WHERE verdict='strong'`);
  const captures = N(state, `SELECT COUNT(*) n FROM debrief_capture`);
  const interactions = N(state, `SELECT COUNT(*) n FROM interactions`);
  const offersLive = N(state, `SELECT COUNT(*) n FROM offers WHERE status NOT IN ('declined','withdrawn')`);
  const onePagerAny = N(state, `SELECT COUNT(*) n FROM deliverables WHERE kind='positioning_one_pager'`);

  let phases = [];
  try { phases = state.prepare(`SELECT phase, COUNT(*) n FROM roles GROUP BY phase ORDER BY phase`).all(); } catch { phases = []; }
  const phaseStr = phases.length ? phases.map((p) => `${p.phase}·${p.n}`).join(' ') : 'none';
  const lastWeekly = (() => { try { return state.prepare(`SELECT closed_at FROM sessions WHERE status='closed' ORDER BY closed_at DESC LIMIT 1`).get()?.closed_at ?? null; } catch { return null; } })();

  const blockOf = (mod) => { const g = checkGates(state, mod); return g.blocked ? g.missing.join('; ') : ''; };
  const st = (done, total, blocked) => blocked ? 'blocked' : (done <= 0 ? 'not-started' : (done >= total ? 'live' : 'in-progress'));

  const rows = [
    { name: 'Tight five', cmd: 'story', done: coverage, total: 8, metric: `${coverage}/8 scenes`, depends: '', blocked: '' },
    { name: 'CV (coached)', cmd: 'cv', done: cvRuled, total: Math.max(cvTotal, 1), metric: cvTotal ? `${cvRuled}/${cvTotal} lines ruled` : 'awaiting your CV', depends: 'tight5,1pager', blocked: '' },
    { name: 'LinkedIn', cmd: 'linkedin', done: liRuled, total: Math.max(liTotal, 1), metric: liTotal ? `${liRuled}/${liTotal} lines ruled` : 'awaiting profile', depends: 'CV rulings', blocked: '' },
    { name: 'Content', cmd: 'content', done: posts, total: Math.max(posts, 1), metric: `${positions} positions · ${posts} posts`, depends: 'a position', blocked: blockOf('content') },
    { name: 'One-pager', cmd: 'positioning', done: onePagerLive ? 1 : 0, total: 1, metric: onePagerLive ? 'live' : (onePagerAny ? 'draft' : 'not started'), depends: 'tight5', blocked: blockOf('positioning_one_pager') },
    { name: 'Pipeline', cmd: 'pipeline', done: 1, total: 1, metric: phaseStr, depends: '', blocked: '' },
    { name: 'Outreach', cmd: 'outreach', done: outreachSent, total: Math.max(outreachSent, 1), metric: outreachSent ? `${outreachSent} drafted` : 'none', depends: 'tight5,1pager', blocked: blockOf('outreach') },
    { name: 'Prep briefs', cmd: 'prep <co>', done: prepBriefs, total: Math.max(prepBriefs, 1), metric: `${prepBriefs} briefs · ${interactions} meetings`, depends: 'pipeline', blocked: '' },
    { name: 'Rehearsal', cmd: 'rehearse', done: rounds, total: Math.max(rounds, 1), metric: rounds ? `${rounds} rounds · ${strongRounds} strong` : 'none', depends: 'prep brief', blocked: '' },
    { name: 'Debrief', cmd: 'debrief <co>', done: captures, total: Math.max(captures, 1), metric: captures ? `${captures} captures` : 'none', depends: 'interaction', blocked: '' },
    { name: 'Offers', cmd: 'offer', done: offersLive, total: Math.max(offersLive, 1), metric: offersLive ? `${offersLive} live` : 'none', depends: 'mutual case', blocked: '' },
    { name: 'Negotiation', cmd: 'negotiate', done: negRounds, total: Math.max(negRounds, 1), metric: negRounds ? `${negRounds} branches rehearsed` : '—', depends: 'live offer', blocked: '' },
    { name: 'Weekly review', cmd: 'weekly', done: lastWeekly ? 1 : 0, total: 1, metric: lastWeekly ? `last: ${String(lastWeekly).slice(0, 10)}` : 'none yet', depends: '', blocked: '' },
  ].map((r) => ({ ...r, state: st(r.done, r.total, r.blocked) }));

  // Pre-render the board so the model prints it verbatim rather than re-deriving it.
  const line = (r) => {
    const name = r.name.padEnd(14);
    const showBar = ['Tight five', 'CV (coached)', 'LinkedIn', 'One-pager', 'Weekly review'].includes(r.name) && !r.blocked;
    const left = r.blocked ? '▒ blocked'.padEnd(11) : (showBar ? bar(r.done, r.total) : '·'.padEnd(9));
    const bits = [`${name}${left}  ${r.metric}`];
    if (r.blocked) bits.push(`blocked-by: ${r.blocked}`);
    else if (r.depends) bits.push(`depends: ${r.depends}`);
    bits.push(`→ say \`${r.cmd}\``);
    return bits.join('  ·  ');
  };
  const rule = '─'.repeat(74);
  const rendered = [
    `MODULE PROGRESS  ·  ${nowIso ? String(nowIso).slice(0, 10) : ''}  (type \`progress\` any time)`.trim(),
    rule, ...rows.map(line), rule,
  ].join('\n');

  return {
    scaffold_note: 'Deterministic view over the module state rows. Print `rendered` at session open '
      + '(session 2+) and on the `progress` command, verbatim; then speak to what is live. Never '
      + 're-derive it by hand. A module showing not-started while work was done is a persistence bug, '
      + 'not a board error.',
    rows,
    rendered,
  };
}
