// ENGINE offer_review (Design V2 §4). Deterministic assembly for one role's
// offer picture. Everything here is computation or join; the recommendation,
// its confidence, career-capital weighing and movable-vs-wall classification
// are the model's and ship as judgment points.
import { scaffold, computed, candidate, absence, checkGates } from './shared.mjs';

const STATIC = Object.freeze({
  legend: 'sources: st=state row (id given) · doc=doctrine (document-derived, not measured) · calc=arithmetic from named inputs',
  gate_rule_text: 'The floor is a floor: it rules an offer out and is never a target, an anchor, or an opening number. Comp benchmarks below marked doc are doctrine-carried norms, not measured data. Register: collaborative, never combat.',
});

export function prepareOfferReview(state, library, { role_id }) {
  const absences = [];
  const judgment = [];

  const role = state.prepare(`SELECT id, company, lane, phase, as_of FROM roles WHERE id = ?`).get(role_id);
  if (!role) {
    return scaffold('offer_review', STATIC, {
      data: {}, computed: {}, gates: { blocked: true, missing: [`role ${role_id} not found`], facts: [] },
      judgment_points: [], absences: [absence(`role ${role_id}`, 'no such row', 'search_state(tables:["roles"]) for the right id')],
    });
  }

  // Offers, received_at order — counters are new rows (V2's declared convention).
  const offers = state.prepare(
    `SELECT id, received_at, terms_json, status FROM offers WHERE role_id = ? ORDER BY received_at`
  ).all(role_id).map((o) => {
    let terms = null; try { terms = JSON.parse(o.terms_json); } catch { /* reported below */ }
    return { id: o.id, received_at: o.received_at, status: o.status, terms, src: `st:${o.id}` };
  });
  if (!offers.length) absences.push(absence('offer rows for this role', 'none recorded', 'save the offer terms first (update_state offers)'));
  const latest = offers[offers.length - 1] ?? null;
  if (latest && !latest.terms) absences.push(absence(`terms for offer ${latest.id}`, 'terms_json unparseable', 're-save the offer terms'));

  // Comp floor: settings row, never assumed (fail closed).
  const floorRow = state.prepare(`SELECT value_json FROM settings WHERE key = 'comp_floor'`).get();
  let floor = null;
  if (floorRow) { try { floor = JSON.parse(floorRow.value_json); } catch { /* absence below */ } }
  if (!floor?.amount) {
    absences.push(absence('comp floor', 'no comp_floor settings row on file', "Bill's confirmation, saved to settings"));
    judgment.push(candidate('floor-unconfirmed', 'The comp floor is not on file as data. Confirm it with Bill before ruling anything out.', 'engine refuses to assume a number', null));
  }

  const cmp = {};
  const base = latest?.terms?.base ?? latest?.terms?.base_gbp ?? null;
  if (floor?.amount && base != null) {
    cmp.floor_check = computed(
      { base, floor: floor.amount, breach: base < floor.amount },
      [`st:settings.comp_floor`, latest ? `st:${latest.id}` : 'missing-offer'],
    );
  }
  const eq = latest?.terms?.equity_pct ?? null;
  if (eq != null) {
    cmp.equity_at_exit = computed(
      [25, 50, 100].map((mv) => ({ exit_value_gbp_m: mv, gross_before_dilution_gbp: Math.round(mv * 1e6 * (eq / 100)) })),
      [latest ? `st:${latest.id}` : 'missing-offer', 'calc'],
    );
  }

  // Honest BATNA: live P2-P4 rows, named.
  const batna = state.prepare(
    `SELECT id, company, phase, last_touch_at FROM roles WHERE phase IN ('P2','P3','P4') AND id != ? ORDER BY phase DESC`
  ).all(role_id).map((r) => ({ ...r, src: `st:${r.id}` }));
  cmp.batna = computed({ live_p2_p4_count: batna.length }, batna.map((r) => r.src));

  // Want-picture gap list.
  const wantRow = state.prepare(`SELECT value_json FROM settings WHERE key = 'want_picture'`).get();
  let want = null;
  if (wantRow) { try { want = JSON.parse(wantRow.value_json); } catch { /* absence */ } }
  if (!want) absences.push(absence('want_picture', 'not on file', 'the want-picture conversation, saved to settings'));

  // Company-context evidence only (measured: market_deals carries NO comp data and
  // 61% of rows have an empty series field — stated so the model never treats this
  // as a benchmark source).
  // Series resolved from STATE first — market_deals lives in the library database,
  // and a cross-database subquery is exactly the class of bug the smoke run caught.
  let roleSeries = '';
  try {
    const tf = state.prepare(`SELECT thesis_fit_json FROM roles WHERE id = ?`).get(role_id);
    roleSeries = JSON.parse(tf?.thesis_fit_json ?? '{}')?.series ?? '';
  } catch { /* series stays empty; context narrows to company match */ }
  const context = library.prepare(
    `SELECT deal_id, company, series, deal_size_musd, current_employees FROM market_deals
     WHERE company = ? OR (series != '' AND series = ?) LIMIT 6`
  ).all(role.company, roleSeries).map((d) => ({ ...d, src: `st:deal:${d.deal_id}`, note: 'company context only; no comp data in this table' }));

  judgment.push(candidate('recommendation', 'The recommendation and its confidence. Doctrine bans hedged mush; that sentence is yours.', null));
  judgment.push(candidate('career-capital', 'Value the cash axis and the capital axis separately; never collapse them.', null));
  if (latest?.terms) {
    judgment.push(candidate('movable-vs-wall', 'Which terms are movable and which are walls — the negotiation-lens read on their economics is judgment-adjacent.',
      'facts on file are inputs, the classification is a read of people', null));
  }

  return scaffold('offer_review', STATIC, {
    data: { role: { ...role, src: `st:${role.id}` }, offers, batna, want_picture: want, company_context: context },
    computed: cmp,
    gates: checkGates(state, 'offer_review'),
    judgment_points: judgment,
    absences,
  });
}
