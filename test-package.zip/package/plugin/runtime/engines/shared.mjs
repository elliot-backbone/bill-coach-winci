// Module-engine shared machinery (Design V2, 2026-08-24, panel-revised).
//
// THE CONTRACT, in code: engines feed the model and never speak to Bill; fail
// closed on absence (an absence is reported, never defaulted); every computed
// value names its inputs; rule outputs that doctrine frames in judgment terms
// ship as judgment-point CANDIDATES, never computed facts; scaffolds carry a
// byte-stable `static` half (cacheable) and a budget-capped dynamic half.

export const ENGINE_VERSION = '1';

// Per-engine dynamic-half token budgets (Design V2 §3.2, contract terms enforced
// by the schema test and by trimScaffold below — chars/4 estimator, the same one
// the audit used).
export const BUDGETS = { offer_review: 2500, weekly_catchup: 3000, debrief_review: 2000 };

export const estimateTokens = (obj) => Math.ceil(JSON.stringify(obj).length / 4);

export function scaffold(engine, staticHalf, dynamic) {
  const out = {
    engine, version: ENGINE_VERSION,
    static: staticHalf,
    ...dynamic, // data, computed, gates, judgment_points, wide_scan?, absences
  };
  const budget = BUDGETS[engine];
  const dynTokens = estimateTokens({ ...dynamic });
  out.budget = { limit: budget, used: dynTokens };
  if (dynTokens > budget) {
    // Trim, never truncate silently: drop wide_scan first, then halve data rows,
    // and RECORD the trim as an absence so the model knows what it cannot see.
    if (out.wide_scan?.length) {
      out.absences = [...(out.absences ?? []), {
        what: `wide_scan (${out.wide_scan.length} rows)`, why_missing: 'scaffold budget',
        what_would_supply_it: 'a narrower ask or a follow-up search_state',
      }];
      out.wide_scan = [];
    }
    for (const key of Object.keys(out.data ?? {})) {
      if (estimateTokens({ d: out.data, c: out.computed }) <= budget) break;
      const rows = out.data[key];
      if (Array.isArray(rows) && rows.length > 4) {
        out.absences = [...(out.absences ?? []), {
          what: `${key} rows beyond the first 4 (${rows.length - 4} dropped)`,
          why_missing: 'scaffold budget', what_would_supply_it: 'search_state on demand',
        }];
        out.data[key] = rows.slice(0, 4);
      }
    }
    out.budget.used_after_trim = estimateTokens({ d: out.data, c: out.computed, g: out.gates, j: out.judgment_points });
  }
  return out;
}

export const computed = (value, inputs) => ({ value, inputs });
export const candidate = (id, question, ruleReasoning, candidateValue) => ({
  id, question, rule_reasoning: ruleReasoning,
  ...(candidateValue !== undefined ? { candidate: candidateValue } : {}),
});
export const absence = (what, why, supply) => ({ what, why_missing: why, what_would_supply_it: supply });

// ---------------------------------------------------------------- gates
// One shared utility (panel C2/V5): named facts only — no phrasing, no agenda.
// The framing, and whether now is the moment to redirect Bill, are the model's.
export function checkGates(state, module) {
  const facts = [];
  const missing = [];
  const coverage = state.prepare(
    `SELECT COUNT(DISTINCT slot) n FROM narrative_coverage WHERE age_or_date IS NOT NULL AND age_or_date <> ''`
  ).get().n;
  facts.push({ fact: 'narrative_coverage_slots_dated', value: coverage, of: 8 });
  const onePager = state.prepare(
    `SELECT COUNT(*) n FROM deliverables WHERE kind = 'positioning_one_pager' AND status = 'live'`
  ).get().n;
  facts.push({ fact: 'positioning_one_pager_live', value: onePager > 0 });
  const positions = state.prepare(`SELECT COUNT(*) n FROM positions_held`).get()?.n ?? 0;
  facts.push({ fact: 'positions_held_on_file', value: positions });

  if (module === 'outreach') {
    if (coverage < 8) missing.push('tight five: 8 dated coverage slots');
    if (!onePager) missing.push('a live positioning one-pager');
  } else if (module === 'positioning_one_pager') {
    if (coverage < 8) missing.push('tight five: 8 dated coverage slots');
  } else if (module === 'content') {
    if (!positions) missing.push('at least one position Bill has agreed to put his name to');
  } else if (module === 'tight_five_draft') {
    if (coverage < 8) missing.push(`coverage: ${coverage} of 8 slots dated`);
  }
  return { blocked: missing.length > 0, missing, facts };
}
