// ENGINE weekly_catchup (Design V2 §4). The week's mechanical picture. Stall
// labels and nudge decisions are CANDIDATES (doctrine frames them in judgment
// terms); the verdict sentences and the three actions are the model's. Includes
// the wide_scan serendipity channel (panel V4).
import { funnelSnapshot } from '../funnel.mjs';
import { scaffold, computed, candidate, absence } from './shared.mjs';

const STATIC = Object.freeze({
  legend: 'sources: st=state row (id given) · calc=arithmetic from named inputs',
  gate_rule_text: 'Weekly review: 2-minute read hard ceiling, numbers over adjectives, stalls named without drama; "a week that eliminated a wrong lane is a good week" is said only when true, and only by you.',
});

const NUDGE_DAYS = 5;
const STALL_DAYS = 10;

export function prepareWeeklyCatchup(state, library, { since } = {}) {
  const absences = [];
  const judgment = [];
  const now = Date.now();

  const lastClosed = state.prepare(`SELECT id, closed_at FROM sessions WHERE status = 'closed' ORDER BY closed_at DESC LIMIT 1`).get();
  const sinceIso = since ?? lastClosed?.closed_at ?? null;
  if (!sinceIso) absences.push(absence('a prior review point to diff against', 'no closed session and no since param', 'this becomes the first review; the diff below is all-time'));

  const events = state.prepare(
    `SELECT id, role_id, event_type, field, new_value, provenance, occurred_at FROM role_events
     WHERE occurred_at >= COALESCE(?, '') ORDER BY occurred_at DESC LIMIT 24`
  ).all(sinceIso ?? '').map((e) => ({ ...e, src: `st:${e.id}` }));

  const commitments = state.prepare(
    `SELECT id, owner, commitment, due_at, status FROM commitments WHERE status = 'open' ORDER BY due_at IS NULL, due_at LIMIT 12`
  ).all().map((c) => ({
    ...c, src: `st:${c.id}`,
    overdue: Boolean(c.due_at && Date.parse(c.due_at) < now),
  }));

  const learnings = state.prepare(
    `SELECT id, category, learning, occurred_at FROM learnings WHERE occurred_at >= COALESCE(?, '') ORDER BY occurred_at DESC LIMIT 8`
  ).all(sinceIso ?? '').map((l) => ({ ...l, src: `st:${l.id}` }));

  // Nudge CANDIDATES. Measured limitation, named per the panel (R3): the store
  // records no reply status; "no subsequent recorded interaction" conflates
  // no-reply with reply-not-recorded, so this is a candidate, never a fact.
  const nudges = state.prepare(
    `SELECT i.id, i.role_id, r.company, i.occurred_at FROM interactions i JOIN roles r ON r.id = i.role_id
     WHERE i.kind = 'outreach' AND r.phase != 'exited'
       AND NOT EXISTS (SELECT 1 FROM interactions later WHERE later.role_id = i.role_id AND later.occurred_at > i.occurred_at)
     ORDER BY i.occurred_at LIMIT 8`
  ).all().filter((o) => (now - Date.parse(o.occurred_at)) / 86_400_000 >= NUDGE_DAYS)
    .map((o) => ({ ...o, days: Math.floor((now - Date.parse(o.occurred_at)) / 86_400_000), src: `st:${o.id}` }));
  if (nudges.length) {
    judgment.push(candidate('nudges', 'These outreaches have no RECORDED later interaction — the store cannot distinguish no-reply from reply-not-recorded. Which deserve a nudge, and did any get replies that never made it into the record?', `rule: outreach with no subsequent recorded interaction >= ${NUDGE_DAYS} days`, nudges.map((n) => n.src)));
  }

  // Stall CANDIDATES (the label is a coaching call — panel V2/covenant F2).
  const stalls = state.prepare(
    `SELECT id, company, phase, last_touch_at FROM roles
     WHERE phase IN ('P1','P2','P3','P4') AND last_touch_at IS NOT NULL ORDER BY last_touch_at LIMIT 8`
  ).all().filter((r) => (now - Date.parse(r.last_touch_at)) / 86_400_000 >= STALL_DAYS)
    .map((r) => ({ ...r, days: Math.floor((now - Date.parse(r.last_touch_at)) / 86_400_000), src: `st:${r.id}` }));
  if (stalls.length) {
    judgment.push(candidate('stalls', 'The rule proposes these as stalled; whether each IS stalled — versus breathing, versus dead — is your read.', `rule: no touch >= ${STALL_DAYS} days at phase >= P1`, stalls.map((s) => s.src)));
  }

  judgment.push(candidate('verdict', 'The week\'s verdict sentences and the 3 owned, dated actions.', null));

  // Serendipity channel: one unconstrained pass over entities the week touched —
  // memories mentioning any company that moved. Model may use or discard.
  const touchedCompanies = [...new Set(events.map((e) => e.role_id))].slice(0, 6);
  let wide = [];
  if (touchedCompanies.length) {
    const marks = touchedCompanies.map(() => '?').join(',');
    wide = state.prepare(
      `SELECT m.id, m.subject, substr(m.content, 1, 160) AS excerpt FROM memories m
       WHERE m.status = 'active' AND (${touchedCompanies.map(() => 'm.content LIKE ?').join(' OR ')}) LIMIT 6`
    ).all(...touchedCompanies.map((r) => `%${String(r).replace('role-', '').split('-')[0]}%`)).map((m) => ({ ...m, src: `st:${m.id}` }));
  }

  const snapshot = funnelSnapshot(state, lastClosed ? lastClosed.id : null);

  return scaffold('weekly_catchup', STATIC, {
    data: { since: sinceIso, funnel: snapshot, moved: events, commitments, learnings, nudge_candidates: nudges, stall_candidates: stalls },
    computed: { week_counts: computed({ moved: events.length, learnings: learnings.length, overdue: commitments.filter((c) => c.overdue).length }, ['calc']) },
    gates: { blocked: false, missing: [], facts: [] },
    judgment_points: judgment,
    wide_scan: wide,
    absences,
  });
}
