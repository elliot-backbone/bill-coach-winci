// Bill Jennings Coach — the funnel hub. Row lifecycle, phase-transition guards,
// aging, session change log and the start_coach orientation snapshot.
// Every write goes through writeWithEvent (statesearch.mjs) so history is total.

import { randomUUID } from 'node:crypto';
import { writeWithEvent, refreshFts } from './statesearch.mjs';

const PHASES = ['P0', 'P1', 'P2', 'P3', 'P4', 'P5'];
const STALL_DAYS = 10;

const nowIso = () => new Date().toISOString();

export function createRole(state, input, sessionId) {
  const required = ['company', 'lane', 'source'];
  for (const f of required) {
    if (!input[f]) throw new Error(`createRole: "${f}" is required`);
  }
  const id = input.id ?? `role-${input.company.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '')}-${randomUUID().slice(0, 6)}`;
  const now = nowIso();
  const row = {
    id,
    company: input.company,
    company_website: input.company_website ?? null,
    role_shape: input.role_shape ?? 'first-commercial',
    lane: input.lane,
    phase: 'P0',
    exit_reason: null,
    exit_by: null,
    mode: input.mode ?? 'live',
    thesis_fit_json: JSON.stringify(input.thesis_fit ?? {}),
    bill_fit_json: JSON.stringify(input.bill_fit ?? {}),
    their_side_json: JSON.stringify(input.their_side ?? {}),
    source: input.source,
    dossier_doc_id: input.dossier_doc_id ?? null,
    next_action: input.next_action ?? 'dossier + go/no-go',
    next_action_due: input.next_action_due ?? null,
    last_touch_at: now,
    investor_names_json: JSON.stringify(input.investor_names ?? []),
    as_of: input.as_of ?? now,
    created_at: now,
    updated_at: now,
  };
  const cols = Object.keys(row);
  state.prepare(`INSERT INTO roles (${cols.join(', ')}) VALUES (${cols.map(() => '?').join(', ')})`)
    .run(...cols.map((c) => row[c]));
  state.prepare(`
    INSERT INTO role_events (id, role_id, session_id, event_type, field, old_value, new_value, provenance, autonomous, occurred_at, created_at)
    VALUES (?, ?, ?, 'created', NULL, NULL, ?, ?, ?, ?, ?)
  `).run(randomUUID(), id, sessionId ?? null, input.company, input.provenance ?? input.source, input.autonomous ? 1 : 0, now, now);
  refreshFts(state, 'roles', id);
  return { role_id: id, phase: 'P0' };
}

/**
 * Phase transitions with evidence guards. Throws instructive errors the model can
 * act on — every rejection names exactly what is missing.
 */
export function transitionPhase(state, roleId, to, provenance, sessionId, extras = {}) {
  const role = state.prepare('SELECT * FROM roles WHERE id = ?').get(roleId);
  if (!role) throw new Error(`transitionPhase: unknown role "${roleId}"`);
  const from = role.phase;
  const now = nowIso();

  if (to === 'exited') {
    if (!extras.exit_reason || !extras.exit_by) {
      throw new Error('exit requires exit_reason and exit_by (bill | them | mutual | coach-retired)');
    }
    const learned = state.prepare(
      `SELECT COUNT(*) AS n FROM learnings WHERE source_id = ? AND created_at >= datetime('now', '-1 hour')`
    ).get(roleId).n;
    if (learned === 0 && !extras.learning_recorded) {
      throw new Error(
        `exit blocked: no learning captured for ${role.company}. Save the learning first ` +
        '(save_coaching_state.learnings with source_id = this role id), then exit — every exit carries its learning.'
      );
    }
    writeWithEvent(state, 'roles', roleId, {
      phase: 'exited', exit_reason: extras.exit_reason, exit_by: extras.exit_by,
    }, { provenance, sessionId, eventType: 'exit', internal: true });
    return { role_id: roleId, phase: 'exited', from };
  }

  if (!PHASES.includes(to)) throw new Error(`unknown phase "${to}"`);
  const fromIdx = PHASES.indexOf(from);
  const toIdx = PHASES.indexOf(to);
  if (fromIdx === -1) throw new Error(`role is exited; revive it first (event_type revived) before re-phasing`);
  if (toIdx !== fromIdx + 1) {
    throw new Error(
      `phase moves one step at a time (${from} -> ${PHASES[fromIdx + 1] ?? '—'}); ` +
      `requested ${from} -> ${to}. If reality jumped ahead, record the intermediate evidence and step through.`
    );
  }

  const billFit = JSON.parse(role.bill_fit_json || '{}');
  const guards = {
    P1: () => {
      if (billFit.verdict !== 'go') {
        throw new Error(
          `P0->P1 blocked for ${role.company}: Bill's go/no-go verdict is not recorded as "go". ` +
          'His verdict is his alone — ask him, then update bill_fit.verdict with provenance bill-said.'
        );
      }
    },
    P2: () => {
      const outreach = state.prepare(
        `SELECT COUNT(*) AS n FROM interactions WHERE role_id = ? AND kind IN ('outreach', 'application', 'coffee', 'call')`
      ).get(roleId).n;
      if (outreach === 0) {
        throw new Error(`P1->P2 blocked: no outreach/application/conversation recorded for ${role.company}. Record the interaction first.`);
      }
    },
    P3: () => {
      const advanced = state.prepare(
        `SELECT COUNT(*) AS n FROM interactions WHERE role_id = ? AND commitments_theirs_json != '[]'`
      ).get(roleId).n;
      if (advanced === 0) {
        throw new Error(
          `P2->P3 blocked for ${role.company}: no interaction carries real commitments from their side ` +
          '(commitments_theirs_json is empty everywhere). Politeness is not advancement — record what they actually committed to.'
        );
      }
    },
    P4: () => {
      const offer = state.prepare('SELECT COUNT(*) AS n FROM offers WHERE role_id = ?').get(roleId).n;
      if (offer === 0) throw new Error(`P3->P4 blocked: no offers row for ${role.company}. Record the offer first.`);
    },
    P5: () => {
      const accepted = state.prepare(
        `SELECT COUNT(*) AS n FROM offers WHERE role_id = ? AND status = 'accepted'`
      ).get(roleId).n;
      if (accepted === 0) throw new Error(`P4->P5 blocked: no accepted offer recorded for ${role.company}.`);
    },
  };
  if (guards[to]) guards[to]();

  writeWithEvent(state, 'roles', roleId, { phase: to, last_touch_at: now }, {
    provenance, sessionId, eventType: 'phase_change', internal: true,
  });
  return { role_id: roleId, phase: to, from };
}

export function touchRole(state, roleId, note, provenance, sessionId) {
  const role = state.prepare('SELECT id FROM roles WHERE id = ?').get(roleId);
  if (!role) throw new Error(`touchRole: unknown role "${roleId}"`);
  const now = nowIso();
  writeWithEvent(state, 'roles', roleId, { last_touch_at: now }, {
    provenance, sessionId, eventType: 'touch', note,
  });
  return { role_id: roleId, touched_at: now };
}

export function agingReport(state, now = new Date()) {
  const cutoff = new Date(now.getTime() - STALL_DAYS * 86400_000).toISOString();
  return state.prepare(`
    SELECT id AS role_id, company, phase, last_touch_at,
      CAST(julianday('now') - julianday(last_touch_at) AS INTEGER) AS days_quiet
    FROM roles
    WHERE phase IN ('P1', 'P2', 'P3', 'P4') AND (last_touch_at IS NULL OR last_touch_at < ?)
    ORDER BY days_quiet DESC LIMIT 8
  `).all(cutoff);
}

export function funnelSnapshot(state, sinceSessionId = null) {
  const counts = {};
  for (const row of state.prepare(`SELECT phase, COUNT(*) AS n FROM roles GROUP BY phase`).all()) {
    counts[row.phase] = row.n;
  }
  const due = state.prepare(`
    SELECT id AS role_id, company, phase, next_action, next_action_due
    FROM roles
    WHERE phase NOT IN ('exited') AND next_action_due IS NOT NULL
      AND next_action_due <= datetime('now', '+3 days')
    ORDER BY next_action_due LIMIT 10
  `).all();
  const pendingVerdicts = state.prepare(`
    SELECT id AS role_id, company, phase FROM roles
    WHERE phase = 'P0' AND json_extract(bill_fit_json, '$.verdict') IS NULL
    ORDER BY created_at LIMIT 10
  `).all();
  let moved = [];
  if (sinceSessionId) {
    moved = state.prepare(`
      SELECT re.role_id, r.company, re.event_type, re.field, re.new_value, re.occurred_at
      FROM role_events re JOIN roles r ON r.id = re.role_id
      WHERE re.session_id IS NOT NULL AND re.session_id != ?
        AND re.occurred_at >= datetime('now', '-14 days')
        AND re.event_type IN ('phase_change', 'created', 'exit')
      ORDER BY re.occurred_at DESC LIMIT 12
    `).all(sinceSessionId);
  } else {
    moved = state.prepare(`
      SELECT re.role_id, r.company, re.event_type, re.field, re.new_value, re.occurred_at
      FROM role_events re JOIN roles r ON r.id = re.role_id
      WHERE re.occurred_at >= datetime('now', '-14 days')
        AND re.event_type IN ('phase_change', 'created', 'exit')
      ORDER BY re.occurred_at DESC LIMIT 12
    `).all();
  }
  const sourcedRecent = state.prepare(`
    SELECT id AS role_id, company, lane, source, as_of FROM roles
    WHERE phase = 'P0' AND created_at >= datetime('now', '-14 days')
    ORDER BY created_at DESC LIMIT 10
  `).all();
  return {
    counts_by_phase: counts,
    due,
    moved,
    stalled: agingReport(state),
    pending_verdicts: pendingVerdicts,
    sourced_since_last: sourcedRecent,
  };
}

export function sessionChangeLog(state, sessionId) {
  return state.prepare(`
    SELECT role_id, event_type, field, old_value, new_value, provenance, autonomous, occurred_at
    FROM role_events WHERE session_id = ? ORDER BY occurred_at
  `).all(sessionId);
}
