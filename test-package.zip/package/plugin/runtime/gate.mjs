// The emission gate: a draft is an INPUT to a decision, not something already on its way
// to Bill.
//
// WHY THIS EXISTS. Claude Code owns emission — text the model produces streams straight to
// the terminal, and a Stop hook can only force a rewrite of something Bill has already read.
// That is structurally weaker than a pipeline that holds a draft before printing it, and it
// showed: across two live runs, reasoning-only enforcement left block-severity violations
// unchanged (0.50 -> 0.65 per 1,000 characters) and three of six replies still opened by
// narrating their own tool use.
//
// So emission is routed through a tool. The model composes the draft, passes it here, and
// prints back exactly what this returns. Nothing reaches Bill that has not been through the
// gate, and the Stop hook checks that rule was followed rather than trying to be the gate.
//
// The pass rule is Dan's, deliberately: pass iff zero hits carry severity 'block'. Flags are
// carried so they are visible and do not fail the draft.

import { checkReply } from './style.mjs';

/** Openings that describe the work instead of doing it. */
const NARRATION = /^\s*(?:(?:I(?:'|’)?ll|I will|Let me|I'm going to|I am going to|Give me a moment|One moment|First,? I)\b|(?:Checking|Pulling|Looking|Starting|Loading)\b)/i;

/**
 * Mannerisms have deterministic repairs. This is the second-attempt fallback: rather than
 * hold a draft forever and leave Bill with nothing, the gate can repair the wording itself.
 * It only ever removes mannerisms — it never rewrites a sentence's meaning, drops a clause
 * or changes a judgment, because a gate that edits substance is worse than one that blocks.
 */
export function repairMannerisms(text) {
  const repairs = [];
  let out = text;

  // An em dash doing a full stop's job becomes a full stop. Between clauses it becomes a
  // comma. Both are wording, neither touches meaning.
  const emdash = /\s*[—–]\s*/g;
  if (emdash.test(out)) {
    out = out.replace(/([a-z0-9,;)"'\]])\s*[—–]\s*([A-Z])/g, '$1. $2');
    out = out.replace(/\s*[—–]\s*/g, ', ');
    repairs.push('em dashes resolved to full stops or commas');
  }
  // Only the narrating SENTENCE goes, not the line it sits on. "I'll pull the record, he
  // asked twice and that's the call" is half narration and half the actual point; deleting
  // the line would take the point with it and leave Bill a blank turn.
  const lines = out.split('\n');
  if (NARRATION.test(lines[0] ?? '')) {
    const sentences = (lines[0].match(/[^.!?]+[.!?]+|\S[^.!?]*$/g) ?? [lines[0]]).map((s) => s.trim());
    while (sentences.length && NARRATION.test(sentences[0])) sentences.shift();
    const kept = sentences.join(' ').trim();
    if (kept) {
      lines[0] = kept.charAt(0).toUpperCase() + kept.slice(1);
      repairs.push('narrating opening sentence removed');
    } else {
      lines.shift();
      while (lines.length && !lines[0].trim()) lines.shift();
      repairs.push('narrating opening line removed');
    }
    out = lines.join('\n');
  }
  out = out.replace(/[ \t]{2,}/g, ' ').replace(/\n{3,}/g, '\n\n').trim();
  return { text: out, repairs };
}

/**
 * Decide whether a draft may be emitted.
 *
 * @param {string} draft         the reply the model proposes to send Bill
 * @param {object} opts
 * @param {number} opts.attempt  1 for the first submission of this reply, 2+ after a hold
 * @returns {{decision:'emit'|'hold', text?:string, violations:Array, repairs?:Array, attempt:number, note:string}}
 */
export function emissionGate(draft, { attempt = 1 } = {}) {
  const text = String(draft ?? '');
  if (!text.trim()) {
    return {
      decision: 'hold', attempt, violations: [],
      note: 'The draft is empty. Send the reply you intend Bill to read.',
    };
  }

  const violations = checkReply(text);
  const blocking = violations.filter((v) => v.severity === 'block');
  const narrates = NARRATION.test(text.trimStart());

  if (!blocking.length && !narrates) {
    return {
      decision: 'emit', text, attempt, violations,
      note: 'Approved. Print this text to Bill exactly as returned, and add nothing before or after it.',
    };
  }

  // Second attempt: repair rather than hold again. Holding twice spends Bill's turn on a
  // mannerism, and the repairs below cannot change what the reply says.
  if (attempt >= 2) {
    const repaired = repairMannerisms(text);
    // A repair that empties the draft means the draft was ALL mannerism — narration with no
    // reply behind it. Releasing that would send Bill a blank turn, which is worse than a hold.
    if (!repaired.text.trim()) {
      return {
        decision: 'hold', attempt, violations: blocking,
        held_for: ['nothing survived once the narration was removed'],
        note: 'Either the draft was only a description of the work, or the narration and the substance '
          + 'share a sentence ("I\'ll pull the record, he asked twice and that is the call"). The gate will '
          + 'not split a sentence for you, because that means rewriting what it says. Split it yourself: '
          + 'drop the half that describes what you are doing, keep the half that is the coaching, and '
          + 'submit that.',
      };
    }
    const left = checkReply(repaired.text).filter((v) => v.severity === 'block');
    return {
      decision: 'emit',
      text: repaired.text,
      attempt,
      violations: left,
      repairs: repaired.repairs,
      note: left.length
        ? 'Repaired what could be repaired mechanically and released it rather than spend another '
          + 'turn on wording. Print the returned text exactly. What remains is listed in violations — '
          + 'write the next reply without it.'
        : 'Repaired mechanically and approved. Print the returned text exactly as returned.',
    };
  }

  const detail = [];
  const seen = new Set();
  if (narrates) {
    detail.push('opening: the reply begins by narrating what you are about to do rather than doing it');
  }
  for (const v of blocking) {
    const key = `${v.rule_id}:${v.matched_text}`;
    if (seen.has(key)) continue;
    seen.add(key);
    detail.push(`${v.rule_id} (${v.class}): "${String(v.matched_text).trim().slice(0, 80)}"`);
    if (detail.length >= 8) break;
  }

  return {
    decision: 'hold',
    attempt,
    violations: blocking,
    held_for: detail,
    note: 'HELD — not sent. Rewrite the SAME substance without these and submit it again with '
      + 'attempt 2. Say the thing that is true and stop: no "X, not Y" flips, no "no A, no B" pairs, '
      + 'no three-item lists for rhythm, a full stop where an em dash is doing a full stop\'s job, and '
      + 'no opening line that describes the reply instead of being it. Do NOT drop a question, soften '
      + 'a judgment or shorten the substance to get through — only the mannerisms go. On attempt 2 the '
      + 'gate repairs what it can and releases, so nothing is lost by trying once more.',
  };
}
