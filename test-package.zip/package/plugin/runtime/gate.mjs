// The emission gate: a draft is an INPUT to a decision, not something already on its way
// to Bill.
//
// WHY THIS EXISTS. Claude Code owns emission — text the model produces streams straight to
// the terminal, and a Stop hook can only force a rewrite of something Bill has already read.
// That is structurally weaker than a pipeline that holds a draft before printing it, and it
// showed: across two live runs, reasoning-only enforcement left block-severity violations
// unchanged (0.50 -> 0.65 per 1,000 characters) and three of six replies still opened by
// narrating their own tool use.
//
// So emission is routed through a tool. The model composes the draft, passes it here, and
// prints back exactly what this returns. Nothing reaches Bill that has not been through the
// gate, and the Stop hook checks that rule was followed rather than trying to be the gate.
//
// Bill's pass rule is deliberate: pass iff zero hits carry severity 'block'. Flags are carried
// so they are visible and do not fail the draft.

import { createHash } from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { checkReply, checkSession, measureVoiceDiversity } from './style.mjs';

// This non-personal authority is the one canonical covenant. It survives the public-package
// privacy scrub that intentionally replaces coach/*.md. Its exact rendered form reaches Coach
// before the first token, in every start_coach payload and in every review_draft result.
const here = path.dirname(fileURLToPath(import.meta.url));
let covenant;
try {
  covenant = JSON.parse(fs.readFileSync(
    path.join(here, '..', 'authorities', 'bill-voice-covenant.v1.json'), 'utf8',
  ));
} catch (err) {
  throw new Error(`Bill voice covenant is missing or malformed; refusing to run the voice gate (${err.message})`);
}
if (covenant?.id !== 'bill-voice-covenant'
    || !/^[a-z0-9.-]+$/.test(covenant?.version ?? '')
    || !/^[0-9a-f]{64}$/.test(covenant?.sha256 ?? '')
    || typeof covenant?.text !== 'string' || !covenant.text.trim()) {
  throw new Error('Bill voice covenant fields are invalid; refusing to run the voice gate');
}
export const VOICE_CONTRACT_VERSION = covenant.version;
export const VOICE_CONTRACT_SHA256 = covenant.sha256;
export const VOICE_CONTRACT = covenant.text;
if (createHash('sha256').update(VOICE_CONTRACT).digest('hex') !== VOICE_CONTRACT_SHA256) {
  throw new Error(`${VOICE_CONTRACT_VERSION} content hash mismatch; refusing to run a drifted voice gate`);
}

export function assertVoiceContractSurface(source, label = 'voice surface') {
  const expected = `BILL VOICE COVENANT [${VOICE_CONTRACT_VERSION} sha256:${VOICE_CONTRACT_SHA256}]\n`
    + `${VOICE_CONTRACT}\nEND BILL VOICE COVENANT`;
  if (!String(source ?? '').replace(/\r\n?/g, '\n').includes(expected)) {
    throw new Error(`${label} is missing or mismatches ${VOICE_CONTRACT_VERSION}; refusing to start Coach`);
  }
  return true;
}

export const voiceContractPayload = () => Object.freeze({
  version: VOICE_CONTRACT_VERSION,
  sha256: VOICE_CONTRACT_SHA256,
  text: VOICE_CONTRACT,
});

/** Openings that describe the work instead of doing it. */
const NARRATION = /^\s*(?:(?:I(?:'|’)?ll|I will|Let me|I'm going to|I am going to|Give me a moment|One moment|First,? I)\b|(?:Checking|Pulling|Looking|Starting|Loading)\b)/i;

function diversityViolation(report) {
  const failures = [...report.signals, ...report.session_signals];
  if (!failures.length) return null;
  return {
    rule_id: 'VOICE-001',
    class: 'multi_scale_uniformity',
    stage: 1,
    severity: report.verdict === 'hold' ? 'block' : 'flag',
    start: 0,
    end: 0,
    matched_text: failures.map((signal) => signal.id).join(', '),
    message: failures.map((signal) => signal.detail).join('; '),
  };
}

/**
 * Mannerisms have deterministic repairs. This is the second-attempt fallback: rather than
 * hold a draft forever and leave Bill with nothing, the gate can repair the wording itself.
 * It only ever removes mannerisms — it never rewrites a sentence's meaning, drops a clause
 * or changes a judgment, because a gate that edits substance is worse than one that blocks.
 */
export function repairMannerisms(text) {
  const repairs = [];
  let out = text;

  // An em dash doing a full stop's job becomes a full stop. Between clauses it becomes a
  // comma. Both are wording, neither touches meaning.
  const emdash = /\s*[—–]\s*/g;
  if (emdash.test(out)) {
    out = out.replace(/([a-z0-9,;)"'\]])\s*[—–]\s*([A-Z])/g, '$1. $2');
    out = out.replace(/\s*[—–]\s*/g, ', ');
    repairs.push('em dashes resolved to full stops or commas');
  }
  // Only the narrating SENTENCE goes, not the line it sits on. "I'll pull the record, he
  // asked twice and that's the call" is half narration and half the actual point; deleting
  // the line would take the point with it and leave Bill a blank turn.
  const lines = out.split('\n');
  if (NARRATION.test(lines[0] ?? '')) {
    const sentences = (lines[0].match(/[^.!?]+[.!?]+|\S[^.!?]*$/g) ?? [lines[0]]).map((s) => s.trim());
    while (sentences.length && NARRATION.test(sentences[0])) sentences.shift();
    const kept = sentences.join(' ').trim();
    if (kept) {
      lines[0] = kept.charAt(0).toUpperCase() + kept.slice(1);
      repairs.push('narrating opening sentence removed');
    } else {
      lines.shift();
      while (lines.length && !lines[0].trim()) lines.shift();
      repairs.push('narrating opening line removed');
    }
    out = lines.join('\n');
  }
  out = out.replace(/[ \t]{2,}/g, ' ').replace(/\n{3,}/g, '\n\n').trim();
  return { text: out, repairs };
}

/**
 * Decide whether a draft may be emitted.
 *
 * @param {string} draft         the reply the model proposes to send Bill
 * @param {object} opts
 * @param {number} opts.attempt  1 for the first submission of this reply, 2+ after a hold
 * @returns {{decision:'emit'|'hold', text?:string, violations:Array, repairs?:Array, attempt:number, note:string}}
 */
export function emissionGate(draft, { attempt = 1, priors = [] } = {}) {
  const text = String(draft ?? '');
  if (!text.trim()) {
    return {
      decision: 'hold', attempt, violations: [],
      voice_contract: voiceContractPayload(),
      voice_diversity: measureVoiceDiversity(text, { priors }),
      note: 'The draft is empty. Send the reply you intend Bill to read.',
    };
  }

  const violations = checkReply(text);

  // Session scope: faults that only exist BETWEEN replies, which no per-reply rule can see.

  violations.push(...checkSession(draft, priors));
  const voiceDiversity = measureVoiceDiversity(text, { priors });
  const voiceViolation = diversityViolation(voiceDiversity);
  if (voiceViolation) violations.push(voiceViolation);
  const blocking = violations.filter((v) => v.severity === 'block');
  const narrates = NARRATION.test(text.trimStart());

  if (!blocking.length && !narrates) {
    // 1.13.2: a clean emit no longer echoes the draft or the covenant back. The echo
    // doubled every approved reply's token cost (draft out + full echo in + print out)
    // and the covenant is already guaranteed in the system prompt by
    // assertVoiceContractSurface before Claude ever spawns. The sha256 lets the Stop
    // hook or any auditor bind the printed reply to the approved bytes.
    return {
      decision: 'emit', attempt, violations,
      text_sha256: createHash('sha256').update(text).digest('hex'),
      voice_diversity: voiceDiversity,
      note: 'Approved unchanged. Print the exact draft you submitted, verbatim, and add nothing before or after it.',
    };
  }

  // 1.14.1: safe mechanical repairs run at ATTEMPT 1 TOO. MEASURED 2026-08-24: a
  // mannerism-only hold on a deliverable forced a complete re-generation of the
  // draft (the largest single latency cost of a gated turn), when repairMannerisms
  // could have fixed the same bytes without changing a word of substance. The
  // repair is attempted and the FULL gate re-runs on the result; if anything
  // beyond the safe mechanical class remains, the hold stands exactly as before.
  // Attempt count is still never a waiver for a block.
  {
    const early = repairMannerisms(text);
    if (early.text.trim() && early.text !== text) {
      const leftEarly = [...checkReply(early.text), ...checkSession(early.text, priors)];
      const earlyDiversity = measureVoiceDiversity(early.text, { priors });
      const earlyVoice = diversityViolation(earlyDiversity);
      if (earlyVoice) leftEarly.push(earlyVoice);
      if (!leftEarly.filter((v) => v.severity === 'block').length && !NARRATION.test(early.text.trimStart())) {
        return {
          decision: 'emit', text: early.text, attempt, violations,
          text_sha256: createHash('sha256').update(early.text).digest('hex'),
          voice_diversity: earlyDiversity,
          repairs: early.repairs ?? ['mechanical'],
          note: 'Repaired mechanically and approved on first submission. Print the returned text exactly as returned.',
        };
      }
    }
  }

  // On later attempts, repair only the narrow mannerisms that cannot change what the reply
  // says, then re-run the complete gate. Attempt count is never a waiver for a block.
  if (attempt >= 2) {
    const repaired = repairMannerisms(text);
    // A repair that empties the draft means the draft was ALL mannerism — narration with no
    // reply behind it. Releasing that would send Bill a blank turn, which is worse than a hold.
    if (!repaired.text.trim()) {
      return {
        decision: 'hold', attempt, violations: blocking,
        voice_contract: voiceContractPayload(),
        voice_diversity: voiceDiversity,
        held_for: ['nothing survived once the narration was removed'],
        note: 'Either the draft was only a description of the work, or the narration and the substance '
          + 'share a sentence ("I\'ll pull the record, he asked twice and that is the call"). The gate will '
          + 'not split a sentence for you, because that means rewriting what it says. Split it yourself: '
          + 'drop the half that describes what you are doing, keep the half that is the coaching, and '
          + 'submit that.',
      };
    }
    const leftAll = [...checkReply(repaired.text), ...checkSession(repaired.text, priors)];
    const repairedDiversity = measureVoiceDiversity(repaired.text, { priors });
    const repairedVoiceViolation = diversityViolation(repairedDiversity);
    if (repairedVoiceViolation) leftAll.push(repairedVoiceViolation);
    const left = leftAll.filter((v) => v.severity === 'block');
    // Rhythm has no safe mechanical rewrite, and other blocked constructions can carry
    // meaning too. Keep holding until Coach rewrites the same substance itself.
    if (left.length) {
      return {
        decision: 'hold', attempt,
        violations: left,
        voice_contract: voiceContractPayload(),
        voice_diversity: repairedDiversity,
        held_for: left.map((violation) => `${violation.rule_id} (${violation.class}): ${violation.message}`),
        note: repairedDiversity.verdict === 'hold'
          ? 'HELD — the reply is still uniformly built across several independent scales. Keep every '
            + 'claim, hard truth and needed question; change only the paragraph, sentence, clause and opening '
            + 'architecture. Do not manufacture a short/long alternation or add decorative prose. Submit the '
            + 'complete rewrite again. The gate will not "repair" rhythm by deleting Bill\'s substance.'
          : 'HELD — a blocking construction remains after the safe mechanical repairs. Keep the same judgment, '
            + 'claims and needed questions, rewrite the listed construction yourself, and submit the complete '
            + 'reply again. A later attempt never waives a blocking rule.',
      };
    }
    return {
      decision: 'emit',
      text: repaired.text,
      attempt,
      violations: left,
      repairs: repaired.repairs,
      voice_contract: voiceContractPayload(),
      voice_diversity: repairedDiversity,
      note: 'Repaired mechanically and approved. Print the returned text exactly as returned.',
    };
  }

  const detail = [];
  const seen = new Set();
  if (narrates) {
    detail.push('opening: the reply begins by narrating what you are about to do rather than doing it');
  }
  for (const v of blocking) {
    const key = `${v.rule_id}:${v.matched_text}`;
    if (seen.has(key)) continue;
    seen.add(key);
    detail.push(`${v.rule_id} (${v.class}): "${String(v.matched_text).trim().slice(0, 80)}"`);
    if (detail.length >= 8) break;
  }

  return {
    decision: 'hold',
    attempt,
    violations: blocking,
    voice_contract: voiceContractPayload(),
    voice_diversity: voiceDiversity,
    held_for: detail,
    note: 'HELD — not sent. Rewrite the SAME substance without these and submit it again with '
      + 'attempt 2. Say the thing that is true and stop: no "X, not Y" flips, no "no A, no B" pairs, '
      + 'no three-item lists for rhythm, a full stop where an em dash is doing a full stop\'s job, and '
      + 'no opening line that describes the reply instead of being it. Do NOT drop a question, soften '
      + 'a judgment or shorten the substance to get through — only the mannerisms go. On attempt 2 the '
      + 'gate repairs only safe punctuation/narration; any remaining block stays held, so nothing substantive '
      + 'is traded away to get through.',
  };
}
