// Read access to library.sqlite: FTS search, ranking, document continuation.
// The only write path into the library is sources.mjs (append-only via sync_source).

const STOPWORDS = new Set([
  'a', 'an', 'and', 'are', 'as', 'at', 'be', 'but', 'by', 'for', 'from', 'has', 'have',
  'how', 'i', 'in', 'is', 'it', 'its', 'of', 'on', 'or', 'our', 'should', 'that', 'the',
  'their', 'this', 'to', 'was', 'we', 'were', 'what', 'when', 'where', 'which', 'who',
  'why', 'will', 'with', 'you', 'your', 'do', 'does', 'did', 'can', 'could', 'would',
]);

export function ftsQueryFromText(text, { maxTerms = 12 } = {}) {
  const words = String(text).toLowerCase().match(/[\p{L}\p{N}][\p{L}\p{N}'-]*/gu) ?? [];
  const terms = [];
  const seen = new Set();
  for (const w of words) {
    const t = w.replace(/'/g, "''");
    if (t.length < 2 || STOPWORDS.has(t) || seen.has(t)) continue;
    seen.add(t);
    terms.push(`"${t}"`);
    if (terms.length >= maxTerms) break;
  }
  return terms.join(' OR ');
}

function recencyBoost(occurredAt, now) {
  if (!occurredAt) return 0;
  const days = (now - Date.parse(occurredAt)) / 86_400_000;
  if (!Number.isFinite(days)) return 0;
  if (days <= 30) return 1.0;
  if (days <= 90) return 0.7;
  if (days <= 180) return 0.45;
  if (days <= 365) return 0.25;
  return 0.1;
}

// score: FTS relevance (bm25 is lower-is-better) blended with authority and recency.
export function blendScore(bm25, authorityRank, occurredAt, now, entityBoost = 0) {
  const relevance = 1 / (1 + Math.max(0, bm25));
  return relevance * 2.0 + (authorityRank / 100) * 0.8 + recencyBoost(occurredAt, now) * 0.9 + entityBoost;
}

const DOC_FETCH_RE = /^doc:([^\s#]+)(?:#(\d+))?$/;
const CONTINUATION_CHUNKS = 24;

export function searchLibrary(library, input, now = Date.now()) {
  const {
    query, kinds, entities, topics,
    occurred_after: after, occurred_before: before,
    limit = 12, include_document_text: includeText = false,
  } = input;

  // Continuation protocol: query "doc:<document_id>" or "doc:<document_id>#<from_sequence>"
  // returns the document's chunks in order. `total` reports remaining chunks; repeat with
  // the returned next marker to continue. This is how full-document review avoids truncation.
  const docFetch = DOC_FETCH_RE.exec(query.trim());
  if (docFetch) return fetchDocumentChunks(library, docFetch[1], Number(docFetch[2] ?? 0), includeText);

  const match = ftsQueryFromText(query);
  if (!match) return { matches: [], total: 0 };

  const params = { match, cap: Math.max(limit * 6, 60) };
  const filters = [];
  if (kinds?.length) filters.push(`d.kind IN (${kinds.map((_, i) => `:kind${i}`).join(',')})`);
  kinds?.forEach((k, i) => { params[`kind${i}`] = k; });
  if (after) { filters.push(`d.occurred_at >= :after`); params.after = after; }
  if (before) { filters.push(`d.occurred_at <= :before`); params.before = before; }
  if (topics?.length) {
    filters.push(`EXISTS (SELECT 1 FROM document_topics t WHERE t.document_id = d.id AND t.topic IN (${topics.map((_, i) => `:topic${i}`).join(',')}))`);
    topics.forEach((t, i) => { params[`topic${i}`] = t; });
  }

  const rows = library.prepare(`
    SELECT c.id AS chunk_id, c.document_id, c.sequence, c.heading, c.speaker,
           snippet(chunks_fts, 0, '', '', ' … ', 40) AS snippet,
           c.text, bm25(chunks_fts) AS rank,
           d.title, d.kind, d.author, d.occurred_at, d.authority_rank, d.source_group, d.status
    FROM chunks_fts
    JOIN chunks c ON c.id = chunks_fts.rowid
    JOIN documents d ON d.id = c.document_id
    WHERE chunks_fts MATCH :match ${filters.length ? 'AND ' + filters.join(' AND ') : ''}
    ORDER BY rank LIMIT :cap
  `).all(params);

  const entitySet = new Set((entities ?? []).map((e) => e.toLowerCase()));
  const entityDocs = new Set();
  if (entitySet.size) {
    for (const r of library.prepare(`SELECT DISTINCT document_id, entity FROM document_entities`).all()) {
      if (entitySet.has(r.entity.toLowerCase())) entityDocs.add(r.document_id);
    }
  }

  const scored = rows.map((r) => ({
    ...r,
    score: blendScore(r.rank, r.authority_rank, r.occurred_at, now, entityDocs.has(r.document_id) ? 0.6 : 0),
  })).sort((a, b) => b.score - a.score);

  // At most 3 chunks per document in a normal search, so one long transcript
  // cannot crowd out the rest of the estate.
  const perDoc = new Map();
  const picked = [];
  for (const r of scored) {
    const n = perDoc.get(r.document_id) ?? 0;
    if (n >= 3) continue;
    perDoc.set(r.document_id, n + 1);
    picked.push(r);
    if (picked.length >= limit) break;
  }

  const matches = picked.map((r) => ({
    document_id: r.document_id,
    chunk_id: r.chunk_id,
    sequence: r.sequence,
    title: r.title,
    kind: r.kind,
    author: r.author,
    occurred_at: r.occurred_at,
    heading: r.heading,
    speaker: r.speaker,
    status: r.status,
    text: includeText ? r.text : (r.snippet || r.text.slice(0, 700)),
    ...(includeText ? {} : { note: r.text.length > 700 && !r.snippet ? 'truncated; search "doc:' + r.document_id + '#' + r.sequence + '" for the full passage in order' : undefined }),
  }));
  return { matches, total: scored.length };
}

function fetchDocumentChunks(library, documentId, fromSequence, includeText) {
  const doc = library.prepare(
    `SELECT id, title, kind, author, occurred_at, status, authority_rank FROM documents WHERE id = ?`
  ).get(documentId);
  if (!doc) return { matches: [], total: 0, error: `unknown document: ${documentId}` };
  const chunks = library.prepare(`
    SELECT id AS chunk_id, sequence, heading, speaker, started_at, ended_at, text
    FROM chunks WHERE document_id = ? AND sequence >= ? ORDER BY sequence LIMIT ?
  `).all(documentId, fromSequence, CONTINUATION_CHUNKS + 1);
  const remaining = library.prepare(
    `SELECT COUNT(*) AS n FROM chunks WHERE document_id = ? AND sequence >= ?`
  ).get(documentId, fromSequence).n;
  const page = chunks.slice(0, CONTINUATION_CHUNKS);
  const next = chunks.length > CONTINUATION_CHUNKS ? `doc:${documentId}#${chunks[CONTINUATION_CHUNKS].sequence}` : null;
  return {
    matches: page.map((c) => ({
      document_id: documentId, chunk_id: c.chunk_id, sequence: c.sequence,
      title: doc.title, kind: doc.kind, author: doc.author, occurred_at: doc.occurred_at,
      heading: c.heading, speaker: c.speaker, started_at: c.started_at, ended_at: c.ended_at,
      text: c.text,
    })),
    total: remaining,
    next,
  };
}

export function documentMeta(library, ids) {
  if (!ids.length) return [];
  const q = library.prepare(
    `SELECT id, title, kind, author, occurred_at, authority_rank, status FROM documents WHERE id IN (${ids.map(() => '?').join(',')})`
  );
  return q.all(...ids);
}
