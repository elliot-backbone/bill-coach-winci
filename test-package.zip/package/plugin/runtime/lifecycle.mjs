// start_coach / end_coach: session lifecycle, orientation context and recovery.
// Also the hook CLI: `node lifecycle.mjs hook-<event>` (SessionStart, PostCompact,
// Stop, SessionEnd) — hooks protect continuity only, they never coach.

import { randomUUID } from 'node:crypto';
// readFileSync is imported UNALIASED because readTurn, at module scope, calls it by that
// name. It was previously imported only as readExemplarFile, with a second local binding
// created inside hookMain — so readTurn threw ReferenceError on every call, and the two
// guards built on it (FIRST-OUTPUT and GATE-USE) silently never fired. Their catch blocks
// swallowed it by design: 'a guard that cannot read the turn never blocks it'.
import { readFileSync } from 'node:fs';
const readExemplarFile = readFileSync;
import { fileURLToPath } from 'node:url';
import { dirname, join as joinPath } from 'node:path';
import { getOnboarding } from './onboarding.mjs';
import { computeStaleness, applyCommitment } from './memory.mjs';
import { ftsQueryFromText } from './library.mjs';
import { funnelSnapshot, sessionChangeLog } from './funnel.mjs';
import { scoreTextMatch } from './context.mjs';

// The paned onboarding walkthrough (PANE_COUNT panes). Each pane: first half a confident, detailed
// product walkthrough (capability + foundations), second half a plain confirm-or-correct
// ask for the data that powers that capability. One pane per response.
const ONBOARDING_PANES = [
  {
    walkthrough: 'PANE 1 — scrubbed. The real walkthrough text is not distributed outside Elliot\'s machine.',
    confirm: 'Scrubbed confirm ask for pane 1.',
  },
  {
    walkthrough: 'PANE 2 — scrubbed. The real walkthrough text is not distributed outside Elliot\'s machine.',
    confirm: 'Scrubbed confirm ask for pane 2.',
  },
  {
    walkthrough: 'PANE 3 — scrubbed. The real walkthrough text is not distributed outside Elliot\'s machine.',
    confirm: 'Scrubbed confirm ask for pane 3.',
  },
  {
    walkthrough: 'PANE 4 — scrubbed. The real walkthrough text is not distributed outside Elliot\'s machine.',
    confirm: 'Scrubbed confirm ask for pane 4.',
  },
  {
    walkthrough: 'PANE 5 — scrubbed. The real walkthrough text is not distributed outside Elliot\'s machine.',
    confirm: 'Scrubbed confirm ask for pane 5.',
  },
  {
    walkthrough: 'PANE 6 — scrubbed. The real walkthrough text is not distributed outside Elliot\'s machine.',
    confirm: 'Scrubbed confirm ask for pane 6.',
  },
  {
    walkthrough: 'PANE 7 — scrubbed. The real walkthrough text is not distributed outside Elliot\'s machine.',
    confirm: 'Scrubbed confirm ask for pane 7.',
  },
];
const PANE_COUNT = ONBOARDING_PANES.length;

const COACH_DIR = joinPath(dirname(fileURLToPath(import.meta.url)), '..', 'coach');

// Approved register exemplar for a given pane, embedded verbatim into the pane
// contract (the sealed session has no file tools; referencing the file by path is dead weight).
function paneExemplar(n) {
  try {
    const text = readExemplarFile(joinPath(COACH_DIR, 'onboarding-exemplars.md'), 'utf8');
    const marker = '## EXEMPLAR: PANE ' + n;
    const i = text.indexOf(marker);
    if (i === -1) return null;
    const start = text.indexOf('\n', i) + 1;
    const j = text.indexOf('\n## EXEMPLAR:', start);
    return (j === -1 ? text.slice(start) : text.slice(start, j)).trim();
  } catch { return null; }
}

/**
 * Everything the assistant made visible in the CURRENT turn, in order.
 *
 * MEASURED 2026-08-22: five of six live replies opened by narrating their own tool use
 * ("I'll pull up what's on file") before calling anything. That text is the FIRST content
 * block of the turn; the guard that existed read only the LAST one, so the commonest
 * defect in the product was invisible to the one component positioned to catch it.
 */
function readTurn(transcriptPath) {
  const lines = readFileSync(transcriptPath, 'utf8').trim().split('\n');
  const blocks = [];
  let askedFor = '';
  for (let i = lines.length - 1; i >= 0; i -= 1) {
    let entry;
    try { entry = JSON.parse(lines[i]); } catch { continue; }
    // A TOOL RESULT IS RECORDED AS A `user` ENTRY. Breaking on the first one made the turn end
    // at the last tool call, so every tool the model used in this turn was invisible to every
    // guard built on this function. MEASURED 2026-08-23: a transcript containing four
    // review_draft calls reported the gate unused, the gate-use guard blocked 114 times across
    // one run, and Coach spent a turn telling Bill the plumbing was lying to him. It was.
    // Only a user entry carrying real typed input ends the turn.
    if (entry.type === 'user') {
      const c = entry.message?.content;
      const isToolResult = Array.isArray(c) && c.length > 0 && c.every((b) => b.type === 'tool_result');
      if (isToolResult) continue;
      askedFor = typeof c === 'string' ? c : (Array.isArray(c) ? c.filter((b) => b.type === 'text').map((b) => b.text).join('\n') : '');
      break;
    }
    if (entry.type !== 'assistant' || !entry.message || !Array.isArray(entry.message.content)) continue;
    for (let j = entry.message.content.length - 1; j >= 0; j -= 1) {
      const b = entry.message.content[j];
      if (b.type === 'text' && String(b.text).trim()) blocks.unshift({ kind: 'text', text: b.text });
      else if (b.type === 'tool_use') blocks.unshift({ kind: 'tool', name: b.name, input: b.input });
    }
  }
  const texts = blocks.filter((b) => b.kind === 'text');
  const firstToolAt = blocks.findIndex((b) => b.kind === 'tool');
  const firstTextAt = blocks.findIndex((b) => b.kind === 'text');
  return {
    usedGate: blocks.some((b) => b.kind === 'tool' && String(b.name ?? '').endsWith('review_draft')),
    savedDeliverable: blocks.some((b) => b.kind === 'tool'
      && String(b.name ?? '').endsWith('save_coaching_state')
      && Array.isArray(b.input?.deliverables) && b.input.deliverables.length > 0),
    askedFor,
    all: texts.map((b) => b.text).join('\n'),
    first: texts.length ? texts[0].text : '',
    last: texts.length ? texts[texts.length - 1].text : '',
    spokeBeforeTooling: firstTextAt !== -1 && (firstToolAt === -1 || firstTextAt < firstToolAt),
  };
}

function onboardingContract(onboarding) {
  const m = /^pane_(\d)$/.exec(onboarding.status ?? '');
  const presented = m ? parseInt(m[1], 10) : 0;
  const next = presented + 1;
  const parts = [];
  const paneEx = next >= 1 && next <= PANE_COUNT + 1 ? paneExemplar(next) : null;
  if (presented === 0) {
    parts.push(`Onboarding is a ${PANE_COUNT}-pane walkthrough that doubles as the product tour. THIS response is pane 1 of ${PANE_COUNT}, and pane 1 only.`);
    // Bill has been through this before — during the reinstall loop, more than once.
    // Making him sit through it again to reach his own memory is a tax, not a welcome.
    parts.push(
      'SKIP OFFER (pane 1 only, one line, at the very end after the Proceed invitation): tell him plainly that if he has done this before and nothing has changed, he can say "skip" and Coach will mark setup complete and go straight to work — his record is already loaded either way, and anything wrong can be corrected the moment it comes up. Offer it once, lightly, and never raise it again.'
    );
  } else if (presented < PANE_COUNT) {
    parts.push(`Bill has just replied to pane ${presented} of the ${PANE_COUNT}-pane onboarding walkthrough. First integrate his reply in one or two lines — corrections supersede any seeded hypothesis immediately; anything he did not correct stands confirmed. ${presented === PANE_COUNT - 2 ? 'The pane just ruled on was the goals pane: create tracked commitments ONLY for goals he accepted (his numbers and timing control) in this response\'s save. ' : ''}Then THIS response presents pane ${next} of ${PANE_COUNT}, and pane ${next} only.`);
  } else {
    parts.push(`Bill has just replied to pane ${PANE_COUNT} — this is the Finish step. If his reply carries corrections or questions, remediate those first, briefly. Then perform ALL closing writes in one save_coaching_state call: onboarding status "complete", the full confirmed picture (his corrections controlling), and the commitments from his accepted goals with owners and dates. After the save, tell him in one line that everything is written down, then present the pre-written READ-ONLY showcase pane embedded below verbatim (two simulated conversations demonstrating full capability); it requires no answer and it carries the ready-for-work close itself. If no showcase pane is embedded, close directly in this spirit: "OK Bill — setup is finished and it is all written down. Ready for work. What shall we talk about?" No new pane.`);
  }
  if (next >= 1 && next < PANE_COUNT) {
    const p = ONBOARDING_PANES[next - 1];
    if (!paneEx) parts.push(`Pane ${next} has two halves in one response. FIRST HALF — walkthrough (be detailed and confident; this is the product\'s one chance to show its depth): ${p.walkthrough} SECOND HALF — a visible turn ("To power this, here\'s what I\'m working from — check it:" or a natural variant) then the confirm ask: ${p.confirm}`);
    if (!paneEx) parts.push('DEPTH RETRIEVAL for this pane: orientation carries the funnel snapshot and compact seeds; pull depth yourself — inspect_memory over bj-* namespaces for the person, search_state for funnel rows and the market baseline, search_library for doctrine and his record');
    parts.push(`Light signposting is good ("${next === 1 ? 'First' : `${next}`} of ${PANE_COUNT}"). Never present two panes at once and never re-present a confirmed pane. TURN RULE: one reply from Bill yields exactly ONE complete response containing the FULL next pane — never an acknowledgment-only turn, never a partial pane, never asking him to say continue/proceed again; his corrections are integrated at the top of the same response, then the pane follows. If Bill brought urgent work, handle it fully first, then the pane follows in the SAME response. NON-NEGOTIABLE CLOSE: the final tool action of this response is save_coaching_state with onboarding status "pane_${next}" (plus Bill's corrections if any) — a pane response without its checkpoint is an incomplete response, whatever else it did. Budget research so the checkpoint always happens. If the recorded checkpoint lags the conversation (Bill is clearly replying to a pane newer than the status shows), trust the conversation: record the missed pane in the same save and continue forward — never re-present it.`);
  } else if (next === PANE_COUNT) {
    const p = ONBOARDING_PANES[next - 1];
    if (!paneEx) parts.push(`Pane ${next} is the closer. Walkthrough (be detailed and confident; this is the product\'s one chance to show its depth): ${p.walkthrough} ${p.confirm}`);
    parts.push(`Light signposting is good ("Last of ${PANE_COUNT}"). Never re-present a confirmed pane; if Bill brought urgent work, handle it fully first, then the pane in the SAME response. NON-NEGOTIABLE CLOSE: this response checkpoints with save_coaching_state at onboarding status "pane_9" and ends on the Finish ask exactly as the pane text carries it. Onboarding is NOT completed in this response; completion happens on his reply.`);
  }
  // The skip has to be a real, single, complete action wherever he says it — not a
  // negotiation, and not something that leaves setup half-finished.
  parts.push(
    'IF BILL ASKS TO SKIP (any phrasing — "skip", "I\'ve done this", "just get on with it", "I did this last time"): take it at face value, do not sell him the walkthrough, do not ask twice. In ONE response: acknowledge in a line, then call save_coaching_state with onboarding status "complete" and a confirmed_picture recording that he skipped the walkthrough and the seeded picture stands until he corrects it. Then go straight to whatever he wants to work on, in the same response if he named something. Onboarding is finished from that moment and is never raised again.'
  );

  if (paneEx) parts.push('This pane is PRE-WRITTEN and principal-approved; its text is the body of this response, printed verbatim. Permitted deviations, and only these: the one-or-two-line integration of his reply up top (from pane 2 on), with corrections carried into the text where they apply; any figure that live data has superseded; and if he brought urgent work or a side question, handle it fully and briefly first, then the pane follows in the SAME response. No retrieval for a pre-written pane; its facts are pre-verified. Nothing precedes the response opening and nothing follows the pane closing line - no sign-off, no addendum. PANE TEXT START >>> ' + paneEx + ' <<< PANE TEXT END');
  parts.push('CORRECTIONS AND SIDE CONVERSATIONS: when Bill corrects anything, remediate it first - acknowledge, save it, carry it into the pane - and when he opens a side thread, engage it briefly and helpfully; in BOTH cases the same response then returns to the walkthrough and presents the pane. Onboarding always advances toward completion; nothing parks it.');
  parts.push('RENDERING: the pane is streamed directly into the chat window as ordinary assistant prose - never into a file, never inside a tool result or embedded update, never an artifact. All retrieval happens before the first visible word so the prose streams uninterrupted; save_coaching_state follows the prose.');
  parts.push('DOCTRINE PRESENTATION: the works and research behind the coach are named exactly once, in onboarding pane 1, and never again. In all natural language with Bill the doctrine presents as one holistic embedded philosophy, carried in plain reasoning and his own metaphor families; never cite an author, book, framework name or research paper to him, and never attribute a line of reasoning to its source. He does not need pointing to the references for the thinking to be consistent. ');
  parts.push('Register throughout: warm, personal, evidence-rich. Never clinical, never a form, never flattery. NO wellness/wellbeing statements in ANY onboarding pane (no tiredness commentary, no take-a-breather counsel, no workload check-ins): the per-session recognition/wellbeing floor applies to ordinary sessions only and is suspended for the entire onboarding walkthrough. NO shoehorned recognition asides in ANY onboarding pane: no look-how-far-you-have-come lines, no one-thing-before-we-start inserts, no commentary about what he tends to do or skip. During onboarding, recognition lives only where the pane subject itself is his record, as in the pane about him, and stays evidence-stated, never summoned. PROHIBITIONS on pane prose (apply writing-voice.md AI_WRITING_BANLIST in full): no significance-inflation vocabulary (crucial/pivotal/testament/underscore/showcase/delve/robust/landscape-figurative etc.), no \'serves as\'/\'stands as\' copula avoidance — say \'is\'; no \'not just X, but Y\'; no rhetorical rule-of-three triads; no trailing participial padding (…, ensuring/reflecting…); no vague attribution; HARD em-dash budget: at most 4 in the entire pane, never two in one sentence — prefer periods, commas and colons; minimal boldface; specificity replaces significance language — a dated fact beats an importance claim. RHYTHM: no staccato chains of short clauses or fragments (max 1-2 fragments per pane, for genuine emphasis only); sentence length and structure must vary — long flowing sentences with subordinate clauses carry the prose, short ones are seasoning; never three consecutive sentences of the same shape. CITATION STYLE: when citing his podcasts, name the show only — never the date (\'(The Longest View)\', not \'(The Longest View, 15 Dec 2025)\'); dates stay internal. REGISTER EXEMPLARS: coach/onboarding-exemplars.md contains approved pane exemplars — match their cadence, dash discipline and warmth exactly.');
  return parts.join(' ');
}

// The always-on founder contract (T0): how to be with Bill, every session. Canonical
// human-readable version in coach/founder.md; his live corrections supersede all of it.
const BILL_CONTRACT =
  'SCRUBBED. The real BILL_CONTRACT is written from the principal\'s record and is not distributed outside Elliot\'s machine.';

/**
 * How Coach conducts itself with Bill, in every exchange, in every module.
 *
 * Distilled from the AI-coaching research in the library — the papers on sycophancy,
 * confidence elicitation, clarification questions, proactive question planning,
 * perspective-taking and self-critique. That corpus was ingested and then reached
 * nothing: doctrine surfaced only through lexical retrieval against Bill's own
 * question, so a rule like "do not flatter" could only appear if he happened to ask
 * about flattery. It is carried here instead, unconditionally, because conduct is not
 * a topic that comes up — it is how every reply is made.
 *
 * The works behind these rules are never named to Bill. The citation guard enforces that.
 */
const CONDUCT = [
  'ORDER OF OPERATIONS — settle WHAT to say before HOW to say it, and never let the second change the first:',
  'WHAT: the module doctrine for the work in hand (deliverables.md and the module it names) says what this response is for; the data store says what is actually known — his record, the funnel, the learnings ledger, the session history; and the conduct rules below, drawn from the research on how coaching agents behave, say how that substance is arrived at honestly. Substance is settled here.',
  'HOW: voice.md, writing-voice.md and the style registers govern the wording, and only the wording. A register rule may change a sentence; it may never change a judgment, drop a question that needed asking, or soften a hard read into a comfortable one. If the only way to satisfy the register is to say something less true, the register is wrong and the substance stands.',
  'CONDUCT — these are requirements to REASON WITH while forming the answer, not tests to pass afterwards and not patterns to match. They come from the research on how coaching agents fail, and they are strong: a response that breaches one is wrong even when it reads well. Weigh them while deciding what to say, in the open, before anything is drafted. Where two pull against each other, say which one won and why in a line — that reasoning is part of the coaching, not overhead:',
  'ASK BEFORE ASSERTING. Where a claim depends on something only Bill can know — what he was thinking, what was said in a room, why he made a call — the honest move is a question, not a confident reconstruction. Coaching goals start undefined and sharpen over turns; a goal fixed on turn one is usually the wrong one.',
  'NEVER FLATTER, NEVER FOLD. Agreement is not a service. Do not open by praising his question or his material, and do not revise a judgment because he pushed back — only because he produced new evidence. If his evidence changes the read, say what changed and why.',
  'CALIBRATED CONFIDENCE, IN WORDS. Give the confidence with the claim and name what would change it. Never project certainty about things that are genuinely unknowable — what a founder is thinking, what the market will do, how a conversation will go. Stating an inference as a fact is the single fastest way to lose a room, and it reads the same way here.',
  'ONE PERSON AT A TIME. Answer from what BILL knows and believes, not from what is true in general. Before a strong reply, take his side of it: what does he already know, what will this land as, what is he actually asking underneath the question.',
  'PROPOSE IN PARTS, NOT VERDICTS. Give the read broken into pieces he can take or reject one by one, with the reasoning attached. A single take-it-or-leave-it recommendation removes the only thing he can usefully do with it.',
  'THE TURN BELONGS TO HIM. Coach talks least when the material is his life, his round, his call. Analysis of how something will land is Coach talking about itself; keep it short and put it after the questions, never before.',
  'HIS CORRECTIONS CHANGE THE DEFAULT. A correction is not a one-off fix — it is a rule for next time, recorded as a voice delta or a learning, and applied without being asked twice.',
].join(' ');

/**
 * Two passes over every response before Bill sees it. The AI-writing register is
 * machine-enforced at the Stop hook, but a filter that only rejects is a poor teacher:
 * the review is what produces a better sentence instead of a differently-broken one.
 */
const PANEL_REVIEW = [
  'PANEL REVIEW — before any response reaches Bill, convene a three-level review of the draft. It is reasoning, not a checklist: at each level, read the draft as three different readers would and let them disagree. None of it is ever shown to him, and no level is skipped because the reply is short.',

  'LEVEL ONE — SUBSTANCE, is this the right thing to say. Three readers. THE EVIDENCE READER asks whether every claim here is earned by something in the record or something Bill actually said, and marks anything that is inference wearing the clothes of fact. THE COACH asks what question should have been asked before any of this advice — especially about his own experience, which only he can report — and whether the honest response is a question rather than a paragraph. THE SCEPTIC hunts confidence about the unknowable: what a founder is thinking, how a conversation will go, what the market will do, and flags each one to be either cut or stated as the guess it is. If any reader objects, the substance is rewritten before level two runs. Level two never edits a draft whose substance is unsettled.',

  'LEVEL TWO — REGISTER, is this how it should be said. Three readers, and this level may change wording only; a change here that removes a judgment or a question has overstepped and level one stands. THE EAR reads it aloud and asks whether it sounds like a sharp mate who knows the startup world cold, or like an assistant being helpful. THE SLOP HUNTER goes looking, by name, for: the "X, not Y" flip and every other negation used for rhythm; "no A, no B" pairs; three-item lists for cadence; em dashes doing a full stop\'s job; openers that restate the question; significance words (crucial, pivotal, key, vital); "here is the thing", "the reality is", "let us be clear"; promotional register (showcasing, renowned, groundbreaking); self-narration ("let me check", "I\'ll look at"); and any claim about what a third party thinks stated as fact. The full catalogue it works from is authorities/style-prohibition-register.v1.json and authorities/ai-writing-signs-register.v1.json — read them when a call is close. THE EXEMPLAR asks, of any line in doubt, whether it would sit unremarked inside coach/onboarding-exemplars.md, the principal-approved walkthrough voice. That is the floor to clear, not the ceiling to reach.',

  'LEVEL THREE — THE ROOM, who this is for and what happens to it. Three readers, and this level holds a veto. BILL reads it aloud: is this a thing he would say, and could he defend every line of it in front of a founder? THE FOUNDER ACROSS THE TABLE asks whether this actually helps him in a real room next week, or whether it is well-made advice about nothing. THE RETELLING asks what survives when Bill repeats this to someone who was not here — if the answer is nothing, the reply is decoration. A veto at level three sends the draft back to level one, not to level two: if it fails here the problem is what was said, not how.',

  'The panel is silent and costs nothing visible. If it produces a shorter, plainer reply with a question in it where there was a paragraph of certainty, it has worked.',
].join(' ');

export function startCoach(state, library, input) {
  const now = input.now ?? new Date().toISOString();
  const onboarding = getOnboarding(state);
  const onboardingActive = onboarding.status !== 'complete';

  // Recover exactly one active session; anything older is abandoned housekeeping.
  const actives = state.prepare(
    `SELECT * FROM sessions WHERE status = 'active' ORDER BY updated_at DESC`
  ).all();
  let session = actives[0] ?? null;
  state.exec('BEGIN IMMEDIATE');
  try {
    for (const stale of actives.slice(1)) {
      state.prepare(`UPDATE sessions SET status = 'abandoned', updated_at = ? WHERE id = ?`).run(now, stale.id);
    }
    if (session) {
      state.prepare(`UPDATE sessions SET updated_at = ? WHERE id = ?`).run(now, session.id);
      session.version = state.prepare(`SELECT version FROM sessions WHERE id = ?`).get(session.id).version;
    } else {
      session = {
        id: randomUUID(), started_at: now, updated_at: now, status: 'active',
        situation: null, judgment: null, evidence_ids_json: '[]',
        open_questions_json: '[]', next_move: null, version: 1,
      };
      state.prepare(
        `INSERT INTO sessions (id, started_at, updated_at, status, version) VALUES (?, ?, ?, 'active', 1)`
      ).run(session.id, now, now);
    }
    state.exec('COMMIT');
  } catch (err) {
    state.exec('ROLLBACK');
    throw err;
  }

  const resumed = actives.length > 0;
  const mode = onboardingActive ? 'onboarding' : resumed ? 'resume' : 'new_episode';

  const commitments = state.prepare(
    `SELECT id, owner, commitment, due_at, next_review_at FROM commitments WHERE status = 'open' ORDER BY due_at IS NULL, due_at LIMIT 12`
  ).all().map((c) => ({
    ...c,
    at_risk: !!c.due_at && Date.parse(c.due_at) < Date.parse(now) + 7 * 86_400_000,
    overdue: !!c.due_at && c.due_at < now,
  }));

  const metrics = state.prepare(
    `SELECT id, name, value_text, unit, scope, as_of, staleness_class FROM metrics WHERE status = 'active' ORDER BY as_of DESC LIMIT 20`
  ).all().map((m) => ({ ...m, stale: computeStaleness(m, Date.parse(now)) }));

  const allMemories = state.prepare(
    `SELECT id, type, subject, content, effective_at, sensitive, updated_at FROM memories WHERE status = 'active'`
  ).all();
  // Orientation memory payloads are size-budgeted: full bodies live behind inspect_memory.
  const compact = ({ updated_at, ...m }) => ({
    ...m,
    content: m.content.length > 420 ? `${m.content.slice(0, 420)} … [full text: inspect_memory "${m.id}"]` : m.content,
  });
  let memories;
  if (onboardingActive) {
    // Panes retrieve their own depth (inspect_memory over mj-* namespaces; search_library
    // over the interview corpus). Orientation carries only the compact company baseline —
    // dumping the full profile here overflows the tool-result budget and breaks onboarding.
    memories = allMemories.filter((m) => m.id.startsWith('seed-')).map(compact);
  } else {
    const terms = (input.user_message.toLowerCase().match(/[\p{L}\p{N}][\p{L}\p{N}'-]*/gu) ?? [])
      .filter((w) => w.length >= 3);
    // Anything written during THIS session comes back unconditionally. When Bill's
    // window closes mid-thought and he reopens with "back again", lexical recall has
    // nothing to match on and the work they just did would be invisible — the crash
    // would read as amnesia even though every row is safely on disk.
    const resumedFrom = session?.started_at ?? null;
    const thisSession = resumedFrom
      ? allMemories.filter((m) => (m.updated_at ?? '') >= resumedFrom).slice(0, 8)
      : [];
    const carried = new Set(thisSession.map((m) => m.id));
    const ranked = allMemories
      .filter((m) => !carried.has(m.id))
      .map((m) => ({ ...m, _s: scoreTextMatch(`${m.subject} ${m.content}`, terms) + (m.type === 'company' || m.type === 'person' ? 0.5 : 0) }))
      .sort((a, b) => b._s - a._s)
      .slice(0, Math.max(0, 12 - thisSession.length))
      .map(({ _s, ...m }) => m);
    memories = [...thisSession, ...ranked].map(compact);
  }

  // The founder model is always in context — empathy and calibration must never depend
  // on lexical recall (one row; trivial cost).
  const principalProfile = state.prepare(`SELECT id, name, role, strengths_json, focus_areas_json, working_model FROM principal_profile ORDER BY name`).all()
    .map((p) => ({ ...p, strengths: JSON.parse(p.strengths_json), focus_areas: JSON.parse(p.focus_areas_json), strengths_json: undefined, focus_areas_json: undefined }));

  const recentSessions = state.prepare(
    `SELECT id, closed_at, situation, judgment, next_move FROM sessions WHERE status = 'closed' ORDER BY closed_at DESC LIMIT 3`
  ).all();

  const recentDecisions = state.prepare(
    `SELECT id, decision, reason, made_at, outcome FROM decisions WHERE status = 'active' ORDER BY made_at DESC LIMIT 8`
  ).all();

  const reviewRow = state.prepare(`SELECT value_json FROM settings WHERE key = 'next_review_at'`).get();
  const nextReviewAt = reviewRow ? JSON.parse(reviewRow.value_json) : null;

  let sourceCandidates = [];
  const match = ftsQueryFromText(input.user_message, { maxTerms: 10 });
  if (match) {
    sourceCandidates = library.prepare(`
      SELECT c.document_id, c.id AS chunk_id, d.title, d.kind, d.occurred_at,
             snippet(chunks_fts, 0, '', '', ' … ', 24) AS snippet, bm25(chunks_fts) AS rank
      FROM chunks_fts
      JOIN chunks c ON c.id = chunks_fts.rowid
      JOIN documents d ON d.id = c.document_id AND d.status = 'active'
      WHERE chunks_fts MATCH ? ORDER BY rank LIMIT 8
    `).all(match).map(({ rank, ...r }) => r);
  }

  // Onboarding pane 2 needs his record; panes retrieve depth themselves.
  if (onboardingActive) {
    const freshest = [];
    for (const row of library.prepare(`SELECT id AS document_id, title, kind, occurred_at FROM documents
          WHERE kind = 'doctrine-text' AND title LIKE '%Field Notes%' AND status = 'active' LIMIT 4`).all()) {
      freshest.push(row);
    }
    const seen = new Set(sourceCandidates.map((c) => c.document_id));
    for (const f of freshest) {
      if (seen.has(f.document_id)) continue;
      seen.add(f.document_id);
      sourceCandidates.push({ ...f, freshest_primary: true });
    }
  }

  // The funnel orientation block — the hub's live picture, every session.
  const lastClosed = state.prepare(
    `SELECT id FROM sessions WHERE status = 'closed' ORDER BY closed_at DESC LIMIT 1`
  ).get();
  const funnel = funnelSnapshot(state, lastClosed ? lastClosed.id : null);
  const learningTail = state.prepare(
    `SELECT category, learning, occurred_at FROM learnings ORDER BY occurred_at DESC LIMIT 5`
  ).all();
  const wantRow = state.prepare(`SELECT value_json FROM settings WHERE key = 'want_picture'`).get();
  const wantPicture = wantRow ? JSON.parse(wantRow.value_json) : null;

  const interrupted = resumed && (session.situation || session.judgment)
    ? { situation: session.situation, judgment: session.judgment, next_move: session.next_move, open_questions: JSON.parse(session.open_questions_json ?? '[]') }
    : null;

  // ---- COMMAND TAXONOMY (hardcoded, one-word, Bill-facing) ----
  // Session: coach / end
  // Inspect: memory / pipeline / sources / changes / recall
  // Control: correct / forget
  const COMMAND_ROUTING = `COMMAND ROUTING (hardcoded — recognise these exact words as commands; Bill may use them standalone or in a sentence):
SESSION COMMANDS:
  "coach" → already handled (this session is open). If Bill says it mid-session, acknowledge you're here.
  "end" → call end_coach with session judgment and next_move. Closing the window also ends the session.
INSPECT COMMANDS:
  "memory" → full dump of every data store: call inspect_memory across ALL bj-* namespaces, then search_state across ALL tables (roles, interactions, offers, contacts, learnings, voice_deltas, investor_roster, sourcing_runs, commitments), the always-on principal model (people), then summarise the library doc inventory. Present everything, no edits, no omissions. This is the total-transparency command.
  "pipeline" → call search_state(tables:["roles","interactions","offers","contacts"]) and present the full funnel: every company, its stage, lane, latest event, next action, and the history underneath. Format as a table with detail expandable per row.
  "sources" → when Bill says "sources" (or "source" or "why do you believe that"), show the provenance chain for the claim in question: the fact, where it came from (web URL, baseline row, his own words with date, Elliot briefing), and when it was last verified.
  "changes" → call search_state for all role_events, learnings, voice_deltas, and memory writes from the current session_id. Present as a chronological list: what changed, old value, new value, provenance. Nothing hidden.
  "recall [topic]" → call inspect_memory for matching bj-* namespaces + search_state with the topic as query across all tables + search_library. Present everything held on that subject.
CONTROL COMMANDS:
  "correct [statement]" → Bill is overriding a fact or judgment. Identify the record (memory atom, role field, profile entry), update it via save_coaching_state or update_state with provenance "bill-said", preserve the old value in history (role_events for funnel, memory versioning for atoms). Acknowledge the correction and confirm what changed.
  "forget [topic]" → Bill wants something removed. Identify the record, delete or nullify it, confirm what was removed. Irreversible — confirm before executing if the target is ambiguous.
These commands are ALWAYS available, during onboarding and after. They take priority over any other interpretation of Bill's message. If Bill's message matches a command, execute the command; coaching continues in the same response after the command output.`;

  return {
    session_id: session.id,
    session_version: session.version,
    mode,
    voice: 'FIRST OUTPUT: the first visible characters of this reply are the coaching itself; any startup narration before or between tool calls is a defect. Tool work is invisible. Emit no user-visible text until every tool call for this reply is finished — never "I\'ll open the session", "pulling up", "saving", "recorded", no narration of checking or storing, in any text segment. The first words the user sees are already the coaching.',
    commands: COMMAND_ROUTING,
    doctrine_binding: 'ABSOLUTE: the coaching doctrine surfaces (method.md, narrative.md, sourcing.md, funnel-doctrine.md, deliverables.md, voice.md, principal.md, identity.md) govern all coaching reasoning. They are binding input references, not optional context. Every non-deterministic decision must be consistent with applicable doctrine. When doctrine covers a topic, follow it. When doctrine is silent, reason in its spirit and flag the gap. Bill\'s live corrections are the only force that supersedes doctrine.',
    principal: BILL_CONTRACT,
    conduct: CONDUCT,
    panel_review: PANEL_REVIEW,
    onboarding: onboardingActive
      ? {
          status: onboarding.status,
          draft_picture: onboarding.draft_picture,
          corrections: onboarding.corrections,
          exchange_contract: onboardingContract(onboarding),
        }
      : null,
    interrupted_work: interrupted,
    funnel,
    learning_ledger_tail: learningTail,
    want_picture: wantPicture,
    active_commitments: commitments,
    current_metrics: metrics,
    relevant_memories: memories,
    ...(principalProfile.length ? { principal_profile: principalProfile } : {}),
    recent_sessions: recentSessions,
    recent_decisions: recentDecisions,
    ...(nextReviewAt ? { next_review_at: nextReviewAt, review_due: nextReviewAt <= now } : {}),
    source_candidates: sourceCandidates,
  };
}

export function endCoach(state, input, nowIso = new Date().toISOString()) {
  const session = state.prepare(`SELECT id, version FROM sessions WHERE id = ?`).get(input.session_id);
  if (!session) return { error: `unknown session: ${input.session_id}` };
  if (session.version !== input.expected_session_version) {
    return {
      error: 'session_version_conflict',
      session_id: session.id,
      session_version: session.version,
    };
  }

  state.exec('BEGIN IMMEDIATE');
  try {
    state.prepare(`
      UPDATE sessions SET status = 'closed', judgment = ?, next_move = ?, closed_at = ?, updated_at = ?, version = version + 1
      WHERE id = ?
    `).run(input.judgment, input.next_move, nowIso, nowIso, session.id);

    const conflicts = [];
    const changedIds = [];
    for (const c of input.commitments ?? []) {
      applyCommitment(state, { ...c, action: 'upsert' }, nowIso, conflicts, changedIds);
    }
    if (input.next_review_at) {
      state.prepare(`
        INSERT INTO settings (key, value_json, updated_at) VALUES ('next_review_at', ?, ?)
        ON CONFLICT(key) DO UPDATE SET value_json = excluded.value_json, updated_at = excluded.updated_at
      `).run(JSON.stringify(input.next_review_at), nowIso);
    }
    state.exec('COMMIT');
  } catch (err) {
    state.exec('ROLLBACK');
    throw err;
  }

  const open = state.prepare(
    `SELECT id, owner, commitment, due_at, next_review_at FROM commitments WHERE status = 'open' ORDER BY due_at IS NULL, due_at`
  ).all();
  return {
    session_id: session.id,
    closed_at: nowIso,
    open_commitments: open,
    next_review_at: input.next_review_at ?? null,
  };
}

// ---------------------------------------------------------------------------
// Hook CLI. Continuity protection only; no coaching, no visible status output.


function active_session_id_for_guard(active) { return active.id; }
async function hookMain(event) {
  let payload = {};
  try { payload = JSON.parse(readFileSync(0, 'utf8') || '{}'); } catch { /* observation only */ }

  if (event === 'hook-session-start' || event === 'hook-post-compact') {
    const silence = ' Tool work is invisible: write no user-visible text until all tool calls for the reply are done — never "I\'ll open the session", "pulling up", "saving", "recorded" or any narration of checking/retrieving/storing. The first words the user sees are already the coaching.';
    const intent = (event === 'hook-post-compact'
      ? 'Context was compacted. Call start_coach now with recovery intent: it returns the active session, its judgment and open questions — resume that work, do not restart discovery.'
      : 'Begin by calling start_coach with the user\'s opening message before responding. If it reports interrupted work, resume it naturally.') + silence;
    process.stdout.write(JSON.stringify({
      hookSpecificOutput: { hookEventName: event === 'hook-post-compact' ? 'PostCompact' : 'SessionStart', additionalContext: intent },
    }));
    return;
  }

  if (event === 'hook-stop') {
    if (payload.stop_hook_active) return; // never loop
    try {
      const { DatabaseSync } = await import('node:sqlite');
      // Hooks do not inherit the MCP server's env; the plugin root IS the data dir
      // (installer renders __DATA_DIR__ = pluginDir), passed as argv by hooks.json.
      const dataDir = process.env.BILL_COACH_DATA_DIR || process.env.CLAUDE_PLUGIN_ROOT || process.argv[3];
      if (!dataDir) return;
      const db = new DatabaseSync(`${dataDir}/state/coach.sqlite`, { readOnly: true });
      const active = db.prepare(
        `SELECT id, version, updated_at, started_at FROM sessions WHERE status = 'active' ORDER BY updated_at DESC LIMIT 1`
      ).get();
      const ob = db.prepare(`SELECT status, updated_at FROM onboarding WHERE singleton = 1`).get();
      db.close();
      // During the onboarding walkthrough every pane MUST be checkpointed before the
      // response ends; instruction alone proved unreliable, so enforce it here. A recent
      // onboarding save (within the last 2 minutes) means this exchange checkpointed.
      if (ob && ob.status !== 'complete' && Date.now() - Date.parse(ob.updated_at) > 2 * 60_000) {
        process.stdout.write(JSON.stringify({
          decision: 'block',
          reason: 'The pane you just presented is not checkpointed. Call save_coaching_state now with the onboarding status for that pane (pane_N you just presented, plus any corrections Bill gave), then stop. Do not add any further user-visible text.',
        }));
        return;
      }
      // FIRST-OUTPUT GUARD (hard requirement). The rule has existed since the first build,
      // in SKILL.md and in the start_coach result, and MEASURED 2026-08-22 it was breached in
      // five of six live replies — then three of six after the rule was moved into the system
      // prompt where it arrives before the first token. Instruction is not enough for this
      // one, and it is the cheapest possible thing to check: did visible text precede the
      // first tool call, and was that text narration rather than coaching.
      try {
        if (payload.transcript_path) {
          const turn = readTurn(payload.transcript_path);
          const NARRATION = /^\s*(?:(?:I(?:'|\u2019)?ll|I will|Let me|I'm going to|I am going to|Give me a moment|One moment|First,? I)\b|(?:Checking|Pulling|Looking|Starting|Loading)\b)/i;
          if (turn.spokeBeforeTooling && NARRATION.test(turn.first)) {
            const offending = turn.first.trim().split('\n')[0].slice(0, 120);
            process.stdout.write(JSON.stringify({
              decision: 'block',
              reason: 'Your reply opened by narrating what you were about to do, before any tool ran:\n'
                + `  "${offending}"\n\n`
                + 'The first user-visible characters of a reply are Coach already speaking to Bill. Tool work is '
                + 'invisible: run the tools first, in silence, and say nothing at all until they return. Then open '
                + 'with the coaching itself — the substance, not a description of the substance you are about to '
                + 'produce. Send the reply again without that opening line.',
            }));
            return;
          }
        }
      } catch { /* a guard that cannot read the turn never blocks it */ }

      // DOCTRINE CITATION GUARD (hard requirement): the works behind the coach are named
      // once, in onboarding pane 1, and never again. A reply that cites them to Bill
      // is a failed reply — block and force a rewrite as embedded philosophy.
      try {
        const tPath = payload.transcript_path;
        const paneOneWindow = !ob || !ob.status || ob.status === 'pane_1';
        if (tPath && !paneOneWindow) {
          const tLines = readFileSync(tPath, 'utf8').trim().split('\n');
          let lastText = '';
          for (let i = tLines.length - 1; i >= 0; i -= 1) {
            try {
              const entry = JSON.parse(tLines[i]);
              if (entry.type === 'assistant' && entry.message && Array.isArray(entry.message.content)) {
                lastText = entry.message.content.filter((b) => b.type === 'text').map((b) => b.text).join('\n');
                if (lastText) break;
              }
            } catch { /* skip unparseable transcript lines */ }
          }
          // Two lists, because one was blocking legitimate replies. "Founding Sales" is
          // the job title Bill is actually applying for; "Decisive", "Influence" and
          // "Innovator" are ordinary words a coach uses constantly. Naming a work is a
          // citation only when it reads as one, so the ambiguous half needs a citation
          // marker nearby before it counts.
          const unmistakable = ['Kazanjy', 'Fitzpatrick', 'Cialdini', 'Keenan', 'Voss', 'Goldratt',
            'Christensen', 'Munger', 'Cal Newport', 'Phyl Terry', 'Senge',
            'Never Split the Difference', 'The Mom Test', 'So Good They', 'Designing Your Life',
            'Never Search Alone', 'High Output Management', 'Crossing the Chasm',
            'Thinking in Systems', 'Fifth Discipline', 'Poor Charlie', 'Sciences of the Artificial',
            'Design of Everyday Things', 'Constitutional AI', 'LongMemEval', 'CoALA', 'ICLR'];
          // These also occur as plain domain language, so they only count as a citation
          // when something nearby frames them as a source.
          const ambiguous = ['Founding Sales', 'Gap Selling', 'Gap Prospecting', 'Decisive',
            'Innovator', 'Influence', 'Heath', 'Burnett', 'Meadows', 'Mom Test'];
          const CITATION_MARKER = /\b(book|chapter|author|wrote|writes|reads?|framework|methodology|per\s|according to|as .{0,12}put it|in (his|her|their) )\b/i;
          const citesAmbiguously = (term) => {
            let from = 0;
            for (;;) {
              const i = lastText.indexOf(term, from);
              if (i === -1) return false;
              if (CITATION_MARKER.test(lastText.slice(Math.max(0, i - 80), i + term.length + 80))) return true;
              from = i + term.length;
            }
          };
          const bannedNames = [...unmistakable, ...ambiguous.filter(citesAmbiguously)];
          const hits = bannedNames.filter((t) => lastText.includes(t));
          if (hits.length > 0) {
            process.stdout.write(JSON.stringify({
              decision: 'block',
              reason: 'Your reply cites doctrine sources by name (' + hits.join(', ') + '). The works behind the coach were named once, in onboarding pane 1, and never again: rewrite the same substance as one holistic embedded philosophy in plain language with no author, book, framework or research names, and send that instead.',
            }));
            return;
          }

        }
      } catch { /* never block a stop on guard failure */ }

      // GUARDS ACCUMULATE, THEY DO NOT RACE. MEASURED 2026-08-23: each guard wrote its block and
      // returned, so the FIRST one to fire hid every guard below it. Coach never calls
      // review_draft in a fresh session, so the gate-use guard fired on every single turn and
      // the coverage and persistence guards — the two that had just been built — were never
      // reached once. One block, carrying everything wrong with the turn.
      const held = [];

      // GATE-USE GUARD. The emission gate is a tool, so the model can simply not call it —
      // and a rule that can be skipped is a preference. This checks the one thing the hook is
      // well positioned to check: did visible text reach Bill this turn without passing
      // through review_draft. It does not re-judge the text; the gate already did that.
      try {
        if (payload.transcript_path) {
          const turn = readTurn(payload.transcript_path);
          if (turn.all.trim() && !turn.usedGate) {
            held.push('You replied to Bill without passing the draft through review_draft. Every reply goes '
                + 'through the gate before he reads it: submit the reply you just wrote to review_draft, and '
                + 'print back exactly the text it returns. If it holds, rewrite the same substance without the '
                + 'violations it lists and submit again with attempt 2.');
          }
        }
      } catch { /* a guard that cannot read the turn never blocks it */ }

      // TIGHT-FIVE COVERAGE GUARD. A drafted narrative line must not reach Bill before the
      // biographical interview has actually happened.
      //
      // MEASURED 2026-08-22: asked for the tight five, Coach took his opening anecdote about a
      // deal, mined it, and had story one written by turn two. Four turns, 1,496 words, and it
      // never asked where he grew up. The same interview run by hand took 103 questions across
      // 271 turns and 10,683 words from the subject, over two sittings, and opened on family
      // and money. narrative.md already said "do NOT open at his career". It lost to Bill's
      // first sentence, which is what instruction does when it meets momentum.
      //
      // Eight slots, each needing a scene with an age or a date. Below the bar, a drafted line
      // is held and Coach is told which slots are empty. Asking questions is never blocked.
      try {
        if (payload.transcript_path) {
          const turn = readTurn(payload.transcript_path);
          const ask = String(turn.askedFor ?? '').toLowerCase();
          const aboutNarrative = /\b(tight five|narrative|my story|five stories)\b/.test(ask);
          // A draft is prose Coach is putting in Bill's mouth: first person, at length.
          const firstPerson = (turn.all.match(/(^|["\n\s])I\s/g) || []).length;
          const drafting = turn.all.trim().length >= 900 && firstPerson >= 6;
          if (aboutNarrative && drafting) {
            const dataDir2 = process.env.BILL_COACH_DATA_DIR || process.env.CLAUDE_PLUGIN_ROOT || process.argv[3];
            const { DatabaseSync: DB2 } = await import('node:sqlite');
            const cdb = new DB2(`${dataDir2}/state/coach.sqlite`, { readOnly: true });
            const SLOTS = ['childhood', 'family_and_money', 'schooling', 'first_work',
              'professional_sequence', 'cost_and_doubt', 'turning_point', 'present_want'];
            let covered = [];
            try {
              covered = cdb.prepare(
                `SELECT DISTINCT slot FROM narrative_coverage WHERE age_or_date IS NOT NULL AND age_or_date <> ''`,
              ).all().map((r) => r.slot);
            } catch { covered = SLOTS; } // a database from before schema 5 never blocks
            cdb.close();
            const missing = SLOTS.filter((s) => !covered.includes(s));
            if (missing.length) {
              held.push('You are drafting his narrative before the interview has happened. Coverage on file: '
                  + `${covered.length} of 8 slots. Missing, each of which needs a scene with an age or a date `
                  + `attached: ${missing.join(', ')}.\n\n`
                  + 'Go back to the beginning of his life and ask. Where he grew up, what his parents did, '
                  + 'whether there was money or there was not, what he wanted to be at eleven, what he did '
                  + 'besides study, what it cost him, what his family made of it. One question at a time, in '
                  + 'ordinary words, and let him talk. If he opened on a deal, park it out loud and say you '
                  + 'want to go a long way further back first.\n\n'
                  + 'Record what he gives you with save_coaching_state(narrative_coverage), one row per scene, '
                  + 'with the age or date and his own words. Draft nothing until all eight slots are on file. '
                  + 'The comparable interview took two sittings and a hundred questions; four turns is not it.');
            }
          }
        }
      } catch { /* a guard that cannot read the turn never blocks it */ }

      // KEEP INTERVIEWING GUARD. Blocking the draft is not the same as running the interview.
      //
      // MEASURED 2026-08-23: with the coverage gate live, Coach recorded three scenes, was
      // stopped from drafting, and moved on. The bad output was prevented and the good one was
      // never produced. The method it is supposed to run took 103 questions across two
      // sittings; two of eight slots is not a slow start, it is a different activity.
      //
      // So while the tight-five interview is open and coverage is incomplete, a reply that asks
      // Bill nothing is held. The interview advances by questions or it does not advance.
      try {
        if (payload.transcript_path) {
          const turn = readTurn(payload.transcript_path);
          const ask = String(turn.askedFor ?? '').toLowerCase();
          const aboutNarrative = /\b(tight five|narrative|my story|five stories|grew up|childhood)\b/.test(ask);
          if (aboutNarrative && turn.all.trim().length > 200 && !turn.all.includes('?')) {
            const dataDir3 = process.env.BILL_COACH_DATA_DIR || process.env.CLAUDE_PLUGIN_ROOT || process.argv[3];
            const { DatabaseSync: DB3 } = await import('node:sqlite');
            let done = 8;
            try {
              const c3 = new DB3(`${dataDir3}/state/coach.sqlite`, { readOnly: true });
              done = c3.prepare(
                `SELECT COUNT(DISTINCT slot) n FROM narrative_coverage WHERE age_or_date IS NOT NULL AND age_or_date <> ''`,
              ).get().n;
              c3.close();
            } catch { done = 8; }
            if (done < 8) {
              held.push('That reply asked Bill nothing, and his interview is only '
                + `${done} of 8 slots covered. The tight five is EXTRACTED, not composed: the method is one `
                + 'question at a time, in ordinary words, starting at the beginning of his life and walking '
                + 'forward, and it runs to roughly a hundred questions over two sittings before anything is '
                + 'drafted. Ask the next question. One question, short, and then stop talking so he can '
                + 'answer it. If you have just been stopped from drafting, the answer is not a better draft, '
                + 'it is the question you have not asked yet.');
            }
          }
        }
      } catch { /* a guard that cannot read the turn never blocks it */ }

      // INTERVIEW SHAPE GUARD. Two failures the style register cannot see, both measured on a
      // live 9-turn interview, 2026-08-23.
      //
      // ONE: it asked THREE questions per turn, five turns running, when narrative.md says one
      // question at a time and the interview this method comes from averaged one per turn
      // across 271 turns. Three questions let Bill pick the easy one and skip the other two.
      //
      // TWO: five consecutive replies opened with the identical scaffold, "Three questions".
      // The style checker scored those nine turns at zero blocks, because every detector in it
      // scopes to a single response. Repetition ACROSS turns is invisible to it by
      // construction: each reply is fine alone, and together they are a tic. The hook can see
      // the whole transcript, so this is the only place the check can live.
      try {
        if (payload.transcript_path) {
          const turn = readTurn(payload.transcript_path);
          const ask = String(turn.askedFor ?? '').toLowerCase();
          const inInterview = /\b(tight five|narrative|my story|grew up|childhood)\b/.test(ask)
            || /\bpark the\b|\bfurther back\b/.test(turn.all.slice(0, 400));
          if (inInterview && turn.all.trim()) {
            const questions = (turn.all.match(/\?/g) || []).length;
            if (questions > 2) {
              held.push(`That reply asked Bill ${questions} questions. Ask ONE. He answers the easiest and `
                + 'the rest are lost, and a stack of numbered questions is an interrogation rather than a '
                + 'conversation. The interview this method comes from averaged one question a turn across '
                + '271 turns. Pick the single thing you most need to know, ask it in one sentence, and stop.');
            }
            // Cross-turn scaffolding: the opening of this reply against the previous ones.
            const opener = turn.all.trim().split('\n')[0].toLowerCase().replace(/[^a-z ]/g, '').trim().slice(0, 28);
            if (opener.length >= 10) {
              const prior = [];
              const lines = readFileSync(payload.transcript_path, 'utf8').trim().split('\n');
              for (const line of lines) {
                try {
                  const e = JSON.parse(line);
                  if (e.type !== 'assistant' || !Array.isArray(e.message?.content)) continue;
                  const txt = e.message.content.filter((b) => b.type === 'text').map((b) => b.text).join('\n').trim();
                  if (txt) prior.push(txt.split('\n')[0].toLowerCase().replace(/[^a-z ]/g, '').trim().slice(0, 28));
                } catch { /* skip */ }
              }
              const repeats = prior.filter((o) => o === opener).length;
              if (repeats > 1) {
                held.push(`You have opened ${repeats} replies in this session with the same words: `
                  + `"${turn.all.trim().split('\n')[0].slice(0, 60)}". Bill is hearing a template, not a person. `
                  + 'Open somewhere else entirely: react to the thing he just said, or ask the question cold '
                  + 'with no preamble at all. The check that scores your prose only ever sees one reply, so '
                  + 'this kind of sameness is yours to notice.');
              }
            }
          }
        }
      } catch { /* a guard that cannot read the turn never blocks it */ }

      // CONTENT GUARD, and the UPSTREAM guards for the derivative modules.
      //
      // CONTENT: six questions produced three posts on 2026-08-22. Posts drafted from nothing
      // read like they were drafted from nothing, and Bill had already said he hates the idea
      // of posting — a real objection the module answered by producing posts anyway.
      //
      // DERIVATIVES: the one-pager and outreach have no material of their own. On a profile
      // where the tight five had two of eight slots covered, they produced finished artefacts,
      // inherited the thinness, and presented it as finished work. That fails quietly, which is
      // the expensive kind.
      try {
        if (payload.transcript_path) {
          const turn = readTurn(payload.transcript_path);
          const ask = String(turn.askedFor ?? '').toLowerCase();
          const body = turn.all.trim();
          const producing = body.length >= 900;
          const aboutContent = /\b(post|posting|content|write.*linkedin post|thought leader)/.test(ask);
          const aboutOnePager = /\b(one.?pager|positioning|what i (?:actually )?do|send to an intro)/.test(ask);
          const aboutOutreach = /\b(outreach|cold|approach them|reach out|first contact|intro message)/.test(ask);
          if (producing && (aboutContent || aboutOnePager || aboutOutreach)) {
            const dd = process.env.BILL_COACH_DATA_DIR || process.env.CLAUDE_PLUGIN_ROOT || process.argv[3];
            const { DatabaseSync: DB8 } = await import('node:sqlite');
            let positions = 0; let publicOk = 0; let slots = 8; let onePager = 0;
            try {
              const c8 = new DB8(`${dd}/state/coach.sqlite`, { readOnly: true });
              positions = c8.prepare('SELECT COUNT(*) n FROM positions_held').get().n;
              publicOk = c8.prepare('SELECT COUNT(*) n FROM positions_held WHERE public_ok = 1').get().n;
              slots = c8.prepare(
                `SELECT COUNT(DISTINCT slot) n FROM narrative_coverage
                  WHERE age_or_date IS NOT NULL AND age_or_date <> ''`,
              ).get().n;
              onePager = c8.prepare(
                `SELECT COUNT(*) n FROM deliverables WHERE kind = 'positioning_one_pager' AND status = 'live'`,
              ).get().n;
              c8.close();
            } catch { positions = -1; }
            if (positions >= 0) {
              if (aboutContent && publicOk === 0) {
                held.push(`You are writing posts and he has ${positions} position`
                  + `${positions === 1 ? '' : 's'} on file that he has agreed to say publicly: none. Content is `
                  + 'the only module whose entire input is what HE thinks. Get a position out of him first — '
                  + 'what he believes about selling or founders or his market, what he has SEEN that makes him '
                  + 'believe it, and who would disagree with it. A position nobody could disagree with is a '
                  + 'status update. Then ask whether he will put his name to it. If he will not, say so and '
                  + 'stop: three posts he never publishes is worse than none.');
              }
              if ((aboutOnePager || aboutOutreach) && slots < 8) {
                held.push(`You are producing a ${aboutOnePager ? 'positioning one-pager' : 'piece of outreach'} `
                  + `while the tight five has ${slots} of 8 slots covered. These modules have no material of `
                  + 'their own: they are built out of the narrative and the want-picture. Written on thin '
                  + 'material they inherit the thinness and hand it to him looking finished, which is worse '
                  + 'than refusing, because he cannot see where it came from. Tell him plainly that the '
                  + 'interview needs finishing first, and offer to carry on with it now.');
              }
              if (aboutOutreach && slots >= 8 && onePager === 0) {
                held.push('You are writing outreach with no positioning one-pager on file. The one-pager is '
                  + 'where what he is for gets settled; outreach written before it settles it accidentally, '
                  + 'differently, in every message. Do the one-pager with him first.');
              }
            }
          }
        }
      } catch { /* a guard that cannot read the turn never blocks it */ }

      // NEGOTIATION GUARD. The plan was the strongest artefact the product produced — 15,110
      // characters, 22 questions, exact words to say at each branch — and it was never once
      // practised. Words he has read are not words he can deliver while a founder is looking
      // at him and the number is on the table.
      //
      // So a negotiation cannot be left as a document. Once a plan is live, the module may not
      // wind up until the branches have been through rehearsal.
      try {
        if (payload.transcript_path) {
          const turn = readTurn(payload.transcript_path);
          const ask = String(turn.askedFor ?? '').toLowerCase();
          // Stems, not phrases. "go back on the offer" failed to match "go back on the Northwind
          // offer", which is how he would actually say it.
          const aboutNegotiation = /\b(negotiat|counter|go back on|come back on|push back|ask for more)/.test(ask);
          const closing = turn.all.trim().length > 200 && !turn.all.includes('?');
          if (aboutNegotiation && closing) {
            const dd = process.env.BILL_COACH_DATA_DIR || process.env.CLAUDE_PLUGIN_ROOT || process.argv[3];
            const { DatabaseSync: DB7 } = await import('node:sqlite');
            let plan = null; let practised = 0;
            try {
              const c7 = new DB7(`${dd}/state/coach.sqlite`, { readOnly: true });
              plan = c7.prepare(
                `SELECT id, title FROM deliverables WHERE kind = 'negotiation_plan' AND status = 'live' LIMIT 1`,
              ).get() ?? null;
              practised = c7.prepare(
                `SELECT COUNT(*) n FROM rehearsal_rounds WHERE source = 'negotiation'`,
              ).get().n;
              c7.close();
            } catch { plan = null; }
            if (plan && practised === 0) {
              held.push('The negotiation plan is written and none of it has been rehearsed. He has read the '
                + 'words; he has not said them with a number on the table and somebody looking at him, which '
                + 'is the only condition that matters. Take the plan branch by branch — what he opens with, '
                + 'what he says if they hold, what he says if they move a little, what he says if they say no '
                + '— and put each one to him as a rehearsal round with source "negotiation". Record his '
                + 'answer and your verdict. A plan nobody has practised is a document, not a preparation.');
            }
          }
        }
      } catch { /* a guard that cannot read the turn never blocks it */ }

      // REHEARSAL GUARD, INVERTED. Every other gate in this product blocks output. This one
      // blocks STOPPING.
      //
      // MEASURED 2026-08-22: the rehearsal module produced 5,458 characters, the least of any
      // module, for the one thing whose whole purpose is repetition under pressure. It asked,
      // he answered, it stopped. The standard it serves is "rote-learned, deliverable at three
      // in the morning" and nothing moved anything toward it.
      //
      // So while an answer stands rated weak, the session may not wrap up. Wrapping up is
      // detected as a reply that closes the topic without putting anything back to him.
      try {
        if (payload.transcript_path) {
          const turn = readTurn(payload.transcript_path);
          const ask = String(turn.askedFor ?? '').toLowerCase();
          // No trailing \b: "rehears" is a stem, and \brehears\b never matches "rehearse".
          const inRehearsal = /\b(rehears|practi[cs]|run it again|role.?play|mock)/.test(ask)
            || /\bround (?:two|three|2|3)\b/.test(turn.all.slice(0, 300).toLowerCase());
          const closing = turn.all.trim().length > 200 && !turn.all.includes('?');
          if (inRehearsal && closing) {
            const dd = process.env.BILL_COACH_DATA_DIR || process.env.CLAUDE_PLUGIN_ROOT || process.argv[3];
            const { DatabaseSync: DB6 } = await import('node:sqlite');
            let weak = [];
            try {
              const c6 = new DB6(`${dd}/state/coach.sqlite`, { readOnly: true });
              // The latest round per question; only the latest verdict counts.
              weak = c6.prepare(`
                SELECT r.topic, r.question, r.what_was_weak, r.escalation FROM rehearsal_rounds r
                 JOIN (SELECT question, MAX(round) AS mr FROM rehearsal_rounds GROUP BY question) m
                   ON m.question = r.question AND m.mr = r.round
                 WHERE r.verdict = 'weak' LIMIT 5
              `).all();
              c6.close();
            } catch { weak = []; }
            if (weak.length) {
              held.push(`You are winding up with ${weak.length} answer`
                + `${weak.length === 1 ? '' : 's'} still rated weak: `
                + `${weak.map((w) => `"${w.question.slice(0, 70)}"`).join(' · ')}. `
                + 'Rehearsal does not stop at the first decent answer — that IS the failure. Put it to him '
                + `again, harder: escalation ${Math.min(3, (weak[0].escalation ?? 1) + 1)} is `
                + (weak[0].escalation >= 2 ? 'the hostile version, the way it will actually come at him in a bad room.'
                  : 'the same question with the follow-up he did not expect.')
                + ' Record the new round and your verdict. The standard is deliverable at three in the '
                + 'morning, and he is not there yet.');
            }
          }
        }
      } catch { /* a guard that cannot read the turn never blocks it */ }

      // DEBRIEF GUARDS. A company opportunity is a sequence of meetings, and each one has to
      // leave a record the next can use.
      //
      // MEASURED 2026-08-22: Bill's own debrief of a founder call was "went alright, he liked
      // the Checker story". Coach asked fifteen questions and produced a debrief document.
      // Everything downstream eats from here, and this material is recoverable for about a day.
      //
      // TWO conditions. A debrief DOCUMENT may not be produced while capture is thin, and a
      // prep brief for a company may not be written while an earlier meeting with that company
      // has no debrief on file — the compounding rule, which is what makes round two worth more
      // than round one. The walkthrough has promised that since the first build and nothing has
      // ever delivered it.
      try {
        if (payload.transcript_path) {
          const turn = readTurn(payload.transcript_path);
          const ask = String(turn.askedFor ?? '').toLowerCase();
          const body = turn.all.trim();
          const isDebriefAsk = /\b(debrief|call went|meeting went|call done|spoke to|interview went)\b/.test(ask);
          const isBriefAsk = /\b(prep|brief|research|prepare me|got a call|first call|meeting with)\b/.test(ask);
          const producing = body.length >= 900;
          if ((isDebriefAsk || isBriefAsk) && producing) {
            const dd = process.env.BILL_COACH_DATA_DIR || process.env.CLAUDE_PLUGIN_ROOT || process.argv[3];
            const { DatabaseSync: DB5 } = await import('node:sqlite');
            let rows = []; let stale = [];
            try {
              const c5 = new DB5(`${dd}/state/coach.sqlite`, { readOnly: true });
              rows = c5.prepare('SELECT slot, COUNT(*) n FROM debrief_capture GROUP BY slot').all();
              // Meetings that happened and were never debriefed.
              stale = c5.prepare(`
                SELECT i.id, i.role_id FROM interactions i
                 WHERE NOT EXISTS (SELECT 1 FROM debrief_capture d WHERE d.interaction_id = i.id)
                 ORDER BY i.occurred_at DESC LIMIT 3
              `).all();
              c5.close();
            } catch { rows = null; }
            const SLOTS = ['what_was_asked', 'what_he_said', 'where_it_stalled', 'their_language',
              'signals_read', 'commitments_made', 'what_he_would_do_differently'];
            if (rows) {
              const covered = new Set(rows.map((r) => r.slot));
              const missing = SLOTS.filter((s) => !covered.has(s));
              if (isDebriefAsk && missing.length > 3) {
                held.push(`You are writing up the debrief with ${SLOTS.length - missing.length} of 7 slots `
                  + `captured. Missing: ${missing.join(', ')}. Get the detail out of him first, and get it `
                  + 'near-verbatim: what they actually asked and in what order, what he actually said, where '
                  + 'it stalled, the words THEY used, what he promised to send. A question they asked twice '
                  + 'is the decision criterion — mark it. He will want to give you "went alright, he liked '
                  + 'the Checker story". That is a vibe and a compliment and no evidence, and by tomorrow '
                  + 'the rest is gone.');
              }
              if (isBriefAsk && stale.length) {
                held.push(`You are writing a prep brief while ${stale.length} earlier meeting`
                  + `${stale.length === 1 ? ' has' : 's have'} no debrief on file. A brief that does not know `
                  + 'what the last conversation established is a brief written as though this were the first '
                  + 'one, and it throws away the only advantage he has going into the next round. Capture the '
                  + 'outstanding debrief now, while he can still remember it, then write the brief on top of it.');
              }
            }
          }
        }
      } catch { /* a guard that cannot read the turn never blocks it */ }

      // CV GUARDS. His document, worked over with him.
      //
      // MEASURED 2026-08-22: asked to tune the CV, Coach ran ten questions and emitted a
      // finished CV of its own composition, including the one line Bill had just told it was
      // shaky. Its own doctrine says the CV is coached and not ghost-written. A document he did
      // not write, carrying claims he has not defended, is ghost-writing with extra steps.
      //
      // Two conditions, both narrow: a WHOLE CV may not be presented while any line is unruled,
      // and a whole-document rewrite is refused outright. Working on a section, proposing a
      // line, and asking him about one are all untouched.
      try {
        if (payload.transcript_path) {
          const turn = readTurn(payload.transcript_path);
          const ask = String(turn.askedFor ?? '').toLowerCase();
          // Which surface is being worked on, because the two share one ledger and a LinkedIn
          // profile is not blocked by unruled CV lines or the other way round.
          const aboutLinkedIn = /\b(linkedin|headline|about section|profile)\b/.test(ask);
          const aboutCvDoc = /\b(cv|r[ée]sum[ée])\b/.test(ask);
          const aboutCv = aboutLinkedIn || aboutCvDoc;
          const surfaces = aboutLinkedIn ? ['headline', 'about', 'experience'] : ['cv'];
          const label = aboutLinkedIn ? 'LinkedIn profile' : 'CV';
          const body = turn.all.trim();
          // A whole document, not a line: long, and carrying the furniture of a CV.
          const looksWhole = body.length >= 1500
            && (body.match(/^\s*(#+\s|\*\*[A-Z])/gm) || []).length >= 3;
          if (aboutCv && looksWhole) {
            const dd = process.env.BILL_COACH_DATA_DIR || process.env.CLAUDE_PLUGIN_ROOT || process.argv[3];
            const { DatabaseSync: DB4 } = await import('node:sqlite');
            let lines = 0; let unruled = 0;
            try {
              const c4 = new DB4(`${dd}/state/coach.sqlite`, { readOnly: true });
              const marks = surfaces.map(() => '?').join(',');
              lines = c4.prepare(`SELECT COUNT(*) n FROM cv_lines WHERE surface IN (${marks})`).get(...surfaces).n;
              unruled = c4.prepare(
                `SELECT COUNT(*) n FROM cv_lines WHERE bill_ruling IS NULL AND surface IN (${marks})`,
              ).get(...surfaces).n;
              c4.close();
            } catch { lines = -1; }
            if (lines === 0) {
              held.push(`You are presenting a whole ${label} and his own is not on file. Ask Bill for the `
                + `${label} he actually uses, ingest it line by line with save_coaching_state(cv_lines), and `
                + 'work through it WITH him. You are not writing it for him: he supplies it, you reason over '
                + 'it against what you already know about his life and what he wants next, one line at a '
                + 'time, and he rules on every change.');
            } else if (lines > 0 && unruled > 0) {
              held.push(`You are presenting a whole ${label} while ${unruled} of ${lines} lines have no ruling `
                + 'from Bill. A line he has not accepted, rejected or amended is not his. Go back to the ones '
                + 'outstanding: put the line, one recommended change, why it rests on something already on '
                + 'file, and the challenge a sceptical reader would put to it. Then take his ruling.'
                + (label === 'LinkedIn profile'
                  ? ' And check the CV lines first: any ruling he has already given on the same claim carries '
                    + 'over. Asking him twice about the same thing is how he stops turning up.'
                  : ''));
            }
          }
        }
      } catch { /* a guard that cannot read the turn never blocks it */ }

      // DELIVERABLE-PERSISTENCE GUARD. Coach may produce Bill's CV, show it to him, and never
      // save it — MEASURED across all fourteen declared deliverables: four modules produced a
      // finished artefact and persisted none of it, and a CV session stored fourteen learnings
      // and zero CV. Doctrine and the system prompt now both require the save, but instruction
      // is what already failed here: three runs of reasoning-only voice enforcement moved
      // violations the WRONG way, and only the gate held. So this is mechanical.
      //
      // Narrow on purpose. It fires only when Bill ASKED for an artefact by name AND a
      // substantial reply came back AND no deliverables save happened. A clarifying question,
      // a short answer, or a save already made all pass untouched, so the guard cannot turn
      // into noise that teaches the model to work around it.
      try {
        if (payload.transcript_path) {
          const turn = readTurn(payload.transcript_path);
          const ask = String(turn.askedFor ?? '').toLowerCase();
          const wantsArtefact = /\b(write|draft|rewrite|redo|do|give me|make|produce|tune|update|prep(are)?)\b/.test(ask)
            && /\b(cv|r[ée]sum[ée]|linkedin|tight five|one[- ]pager|positioning|post|posts|outreach|message|brief|debrief|offer|negotiat\w*|weekly review|pipeline|headline|about section)\b/.test(ask);
          const produced = turn.all.trim().length >= 1200;
          if (wantsArtefact && produced && !turn.savedDeliverable) {
            held.push('You produced an artefact for Bill and did not save it, so it would be lost the moment '
                + 'this session ends and the next one would rebuild it from scratch instead of refining it. '
                + 'Call save_coaching_state with deliverables: [{kind, title, body}] where body is the FULL '
                + 'text exactly as you gave it to him, then print your reply again unchanged. Do not ask him '
                + 'whether to save it and do not wait for his approval — saving is a record of what you '
                + 'produced, not an agreement that it is finished.');
          }
        }
      } catch { /* a guard that cannot read the turn never blocks it */ }

      if (held.length) {
        process.stdout.write(JSON.stringify({
          decision: 'block',
          reason: held.length === 1 ? held[0]
            : `${held.length} things are wrong with that turn, and all of them have to be fixed before it `
              + `reaches Bill:\n\n${held.map((h, i) => `${i + 1}. ${h}`).join('\n\n')}`,
        }));
        return;
      }

      // VERBATIM PANE GUARD: pre-written panes are principal-approved and ship verbatim.
      // Instruction alone proved unreliable (a prior build drifted from its locked
      // panes), so enforce mechanically: the response that presented pane N must contain
      // the locked exemplar text. The permitted deviations (integration lines above the
      // pane, Bill's corrections woven in, figures superseded by live data) make an exact
      // hash wrong; require paragraph containment with a small tolerance instead.
      try {
        const tPath = payload.transcript_path;
        const paneM = /^pane_(\d)$/.exec(ob?.status ?? '');
        const recentPane = ob && ob.updated_at && Date.now() - Date.parse(ob.updated_at) <= 2 * 60_000;
        if (tPath && paneM && recentPane) {
          const exemplar = paneExemplar(Number(paneM[1]));
          if (exemplar) {
            const tLines = readFileSync(tPath, 'utf8').trim().split('\n');
            let lastText = '';
            for (let i = tLines.length - 1; i >= 0; i -= 1) {
              try {
                const entry = JSON.parse(tLines[i]);
                if (entry.type === 'assistant' && entry.message && Array.isArray(entry.message.content)) {
                  lastText = entry.message.content.filter((b) => b.type === 'text').map((b) => b.text).join('\n');
                  if (lastText) break;
                }
              } catch { /* skip unparseable transcript lines */ }
            }
            const norm = (s) => s
              .replace(/[\u2018\u2019]/g, "'")
              .replace(/[\u201C\u201D]/g, '"')
              .replace(/\s+/g, ' ')
              .trim();
            const reply = norm(lastText);
            const paras = exemplar.split(/\n\s*\n/).map(norm).filter((p) => p.length >= 60);
            if (reply && paras.length >= 3) {
              const missing = paras.filter((p) => !reply.includes(p));
              const tolerance = Math.max(1, Math.floor(paras.length * 0.2));
              if (missing.length > tolerance) {
                process.stdout.write(JSON.stringify({
                  decision: 'block',
                  reason: 'This pane is pre-written and principal-approved; your response rewrote it instead of printing it. Send the pane again as the locked text, verbatim and in full. The only allowed changes: the one-or-two-line integration of Bill\'s reply above it, his corrections where they apply, and figures superseded by live data. Missing locked passages begin: ' + missing.slice(0, 2).map((p) => '"' + p.slice(0, 70) + '..."').join(' | '),
                }));
                return;
              }
            }
          }
        }
      } catch { /* never block a stop on guard failure */ }
      // UNCLOSED-WORK GUARD: rate of learning is a hard rule — a session that moved the
      // funnel (phase changes, exits, new interactions) but captured zero learnings is
      // incomplete. Block once with an instructive reason.
      try {
        if (active) {
          const movedN = db.prepare(
            `SELECT COUNT(*) AS n FROM role_events WHERE session_id = ? AND event_type IN ('phase_change', 'exit', 'created')`
          ).get(active_session_id_for_guard(active)).n;
          const learnedN = db.prepare(
            `SELECT COUNT(*) AS n FROM learnings WHERE created_at >= ?`
          ).get(active.started_at).n;
          if (movedN > 0 && learnedN === 0) {
            const flagged = db.prepare(`SELECT value FROM state_meta WHERE key = 'unclosed_guard_fired'`).get();
            if (!flagged || flagged.value !== active_session_id_for_guard(active)) {
              // fire once per session; record via side write is not possible on a readOnly
              // handle, so tolerate double-fire on rare double-stop instead of writing here.
              process.stdout.write(JSON.stringify({
                decision: 'block',
                reason: 'Close the work: this session moved the funnel but captured no learning. Save what we learned (save_coaching_state.learnings — one line each, category + source) then stop.',
              }));
              return;
            }
          }
        }
      } catch { /* never block a stop on guard failure */ }

      // Ask once only when an episode has run long past its last checkpoint (any version:
      // material changes after a first save deserve the same protection).
      const staleMs = active ? Date.now() - Date.parse(active.updated_at) : 0;
      if (active && staleMs > 20 * 60_000) {
        process.stdout.write(JSON.stringify({
          decision: 'block',
          reason: 'If this exchange produced material decisions, commitments, corrections or lessons not yet saved, call save_coaching_state once now with all of them; if nothing material changed, simply stop.',
        }));
      }
    } catch { /* never block a stop on hook failure */ }
    return;
  }

  // No SessionEnd hook: an active session row is already the interruption marker, and
  // nothing else is worth doing during termination.
}

const invokedDirectly = process.argv[1] && import.meta.url === (await import('node:url')).pathToFileURL(process.argv[1]).href;
if (invokedDirectly && process.argv[2]?.startsWith('hook-')) {
  await hookMain(process.argv[2]);
}
