// start_coach / end_coach: session lifecycle, orientation context and recovery.
// Also the hook CLI: `node lifecycle.mjs hook-<event>` (SessionStart, PostCompact,
// Stop, SessionEnd) — hooks protect continuity only, they never coach.

import { randomUUID } from 'node:crypto';
import { readFileSync as readExemplarFile } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join as joinPath } from 'node:path';
import { getOnboarding } from './onboarding.mjs';
import { computeStaleness, applyCommitment } from './memory.mjs';
import { ftsQueryFromText } from './library.mjs';
import { funnelSnapshot, sessionChangeLog } from './funnel.mjs';
import { scoreTextMatch } from './context.mjs';

// The paned onboarding walkthrough (PANE_COUNT panes). Each pane: first half a confident, detailed
// product walkthrough (capability + foundations), second half a plain confirm-or-correct
// ask for the data that powers that capability. One pane per response.
const ONBOARDING_PANES = [
  {
    walkthrough: 'PANE 1 — scrubbed. The real walkthrough text is not distributed outside Elliot\'s machine.',
    confirm: 'Scrubbed confirm ask for pane 1.',
  },
  {
    walkthrough: 'PANE 2 — scrubbed. The real walkthrough text is not distributed outside Elliot\'s machine.',
    confirm: 'Scrubbed confirm ask for pane 2.',
  },
  {
    walkthrough: 'PANE 3 — scrubbed. The real walkthrough text is not distributed outside Elliot\'s machine.',
    confirm: 'Scrubbed confirm ask for pane 3.',
  },
  {
    walkthrough: 'PANE 4 — scrubbed. The real walkthrough text is not distributed outside Elliot\'s machine.',
    confirm: 'Scrubbed confirm ask for pane 4.',
  },
  {
    walkthrough: 'PANE 5 — scrubbed. The real walkthrough text is not distributed outside Elliot\'s machine.',
    confirm: 'Scrubbed confirm ask for pane 5.',
  },
  {
    walkthrough: 'PANE 6 — scrubbed. The real walkthrough text is not distributed outside Elliot\'s machine.',
    confirm: 'Scrubbed confirm ask for pane 6.',
  },
  {
    walkthrough: 'PANE 7 — scrubbed. The real walkthrough text is not distributed outside Elliot\'s machine.',
    confirm: 'Scrubbed confirm ask for pane 7.',
  },
];
const PANE_COUNT = ONBOARDING_PANES.length;

const COACH_DIR = joinPath(dirname(fileURLToPath(import.meta.url)), '..', 'coach');

// Approved register exemplar for a given pane, embedded verbatim into the pane
// contract (the sealed session has no file tools; referencing the file by path is dead weight).
function paneExemplar(n) {
  try {
    const text = readExemplarFile(joinPath(COACH_DIR, 'onboarding-exemplars.md'), 'utf8');
    const marker = '## EXEMPLAR: PANE ' + n;
    const i = text.indexOf(marker);
    if (i === -1) return null;
    const start = text.indexOf('\n', i) + 1;
    const j = text.indexOf('\n## EXEMPLAR:', start);
    return (j === -1 ? text.slice(start) : text.slice(start, j)).trim();
  } catch { return null; }
}

function onboardingContract(onboarding) {
  const m = /^pane_(\d)$/.exec(onboarding.status ?? '');
  const presented = m ? parseInt(m[1], 10) : 0;
  const next = presented + 1;
  const parts = [];
  const paneEx = next >= 1 && next <= PANE_COUNT + 1 ? paneExemplar(next) : null;
  if (presented === 0) {
    parts.push(`Onboarding is a ${PANE_COUNT}-pane walkthrough that doubles as the product tour. THIS response is pane 1 of ${PANE_COUNT}, and pane 1 only.`);
    // Bill has been through this before — during the reinstall loop, more than once.
    // Making him sit through it again to reach his own memory is a tax, not a welcome.
    parts.push(
      'SKIP OFFER (pane 1 only, one line, at the very end after the Proceed invitation): tell him plainly that if he has done this before and nothing has changed, he can say "skip" and Coach will mark setup complete and go straight to work — his record is already loaded either way, and anything wrong can be corrected the moment it comes up. Offer it once, lightly, and never raise it again.'
    );
  } else if (presented < PANE_COUNT) {
    parts.push(`Bill has just replied to pane ${presented} of the ${PANE_COUNT}-pane onboarding walkthrough. First integrate his reply in one or two lines — corrections supersede any seeded hypothesis immediately; anything he did not correct stands confirmed. ${presented === PANE_COUNT - 2 ? 'The pane just ruled on was the goals pane: create tracked commitments ONLY for goals he accepted (his numbers and timing control) in this response\'s save. ' : ''}Then THIS response presents pane ${next} of ${PANE_COUNT}, and pane ${next} only.`);
  } else {
    parts.push(`Bill has just replied to pane ${PANE_COUNT} — this is the Finish step. If his reply carries corrections or questions, remediate those first, briefly. Then perform ALL closing writes in one save_coaching_state call: onboarding status "complete", the full confirmed picture (his corrections controlling), and the commitments from his accepted goals with owners and dates. After the save, tell him in one line that everything is written down, then present the pre-written READ-ONLY showcase pane embedded below verbatim (two simulated conversations demonstrating full capability); it requires no answer and it carries the ready-for-work close itself. If no showcase pane is embedded, close directly in this spirit: "OK Bill — setup is finished and it is all written down. Ready for work. What shall we talk about?" No new pane.`);
  }
  if (next >= 1 && next < PANE_COUNT) {
    const p = ONBOARDING_PANES[next - 1];
    if (!paneEx) parts.push(`Pane ${next} has two halves in one response. FIRST HALF — walkthrough (be detailed and confident; this is the product\'s one chance to show its depth): ${p.walkthrough} SECOND HALF — a visible turn ("To power this, here\'s what I\'m working from — check it:" or a natural variant) then the confirm ask: ${p.confirm}`);
    if (!paneEx) parts.push('DEPTH RETRIEVAL for this pane: orientation carries the funnel snapshot and compact seeds; pull depth yourself — inspect_memory over bj-* namespaces for the person, search_state for funnel rows and the market baseline, search_library for doctrine and his record');
    parts.push(`Light signposting is good ("${next === 1 ? 'First' : `${next}`} of ${PANE_COUNT}"). Never present two panes at once and never re-present a confirmed pane. TURN RULE: one reply from Bill yields exactly ONE complete response containing the FULL next pane — never an acknowledgment-only turn, never a partial pane, never asking him to say continue/proceed again; his corrections are integrated at the top of the same response, then the pane follows. If Bill brought urgent work, handle it fully first, then the pane follows in the SAME response. NON-NEGOTIABLE CLOSE: the final tool action of this response is save_coaching_state with onboarding status "pane_${next}" (plus Bill's corrections if any) — a pane response without its checkpoint is an incomplete response, whatever else it did. Budget research so the checkpoint always happens. If the recorded checkpoint lags the conversation (Bill is clearly replying to a pane newer than the status shows), trust the conversation: record the missed pane in the same save and continue forward — never re-present it.`);
  } else if (next === PANE_COUNT) {
    const p = ONBOARDING_PANES[next - 1];
    if (!paneEx) parts.push(`Pane ${next} is the closer. Walkthrough (be detailed and confident; this is the product\'s one chance to show its depth): ${p.walkthrough} ${p.confirm}`);
    parts.push(`Light signposting is good ("Last of ${PANE_COUNT}"). Never re-present a confirmed pane; if Bill brought urgent work, handle it fully first, then the pane in the SAME response. NON-NEGOTIABLE CLOSE: this response checkpoints with save_coaching_state at onboarding status "pane_9" and ends on the Finish ask exactly as the pane text carries it. Onboarding is NOT completed in this response; completion happens on his reply.`);
  }
  // The skip has to be a real, single, complete action wherever he says it — not a
  // negotiation, and not something that leaves setup half-finished.
  parts.push(
    'IF BILL ASKS TO SKIP (any phrasing — "skip", "I\'ve done this", "just get on with it", "I did this last time"): take it at face value, do not sell him the walkthrough, do not ask twice. In ONE response: acknowledge in a line, then call save_coaching_state with onboarding status "complete" and a confirmed_picture recording that he skipped the walkthrough and the seeded picture stands until he corrects it. Then go straight to whatever he wants to work on, in the same response if he named something. Onboarding is finished from that moment and is never raised again.'
  );

  if (paneEx) parts.push('This pane is PRE-WRITTEN and principal-approved; its text is the body of this response, printed verbatim. Permitted deviations, and only these: the one-or-two-line integration of his reply up top (from pane 2 on), with corrections carried into the text where they apply; any figure that live data has superseded; and if he brought urgent work or a side question, handle it fully and briefly first, then the pane follows in the SAME response. No retrieval for a pre-written pane; its facts are pre-verified. Nothing precedes the response opening and nothing follows the pane closing line - no sign-off, no addendum. PANE TEXT START >>> ' + paneEx + ' <<< PANE TEXT END');
  parts.push('CORRECTIONS AND SIDE CONVERSATIONS: when Bill corrects anything, remediate it first - acknowledge, save it, carry it into the pane - and when he opens a side thread, engage it briefly and helpfully; in BOTH cases the same response then returns to the walkthrough and presents the pane. Onboarding always advances toward completion; nothing parks it.');
  parts.push('RENDERING: the pane is streamed directly into the chat window as ordinary assistant prose - never into a file, never inside a tool result or embedded update, never an artifact. All retrieval happens before the first visible word so the prose streams uninterrupted; save_coaching_state follows the prose.');
  parts.push('DOCTRINE PRESENTATION: the works and research behind the coach are named exactly once, in onboarding pane 1, and never again. In all natural language with Bill the doctrine presents as one holistic embedded philosophy, carried in plain reasoning and his own metaphor families; never cite an author, book, framework name or research paper to him, and never attribute a line of reasoning to its source. He does not need pointing to the references for the thinking to be consistent. ');
  parts.push('Register throughout: warm, personal, evidence-rich. Never clinical, never a form, never flattery. NO wellness/wellbeing statements in ANY onboarding pane (no tiredness commentary, no take-a-breather counsel, no workload check-ins): the per-session recognition/wellbeing floor applies to ordinary sessions only and is suspended for the entire onboarding walkthrough. NO shoehorned recognition asides in ANY onboarding pane: no look-how-far-you-have-come lines, no one-thing-before-we-start inserts, no commentary about what he tends to do or skip. During onboarding, recognition lives only where the pane subject itself is his record, as in the pane about him, and stays evidence-stated, never summoned. PROHIBITIONS on pane prose (apply writing-voice.md AI_WRITING_BANLIST in full): no significance-inflation vocabulary (crucial/pivotal/testament/underscore/showcase/delve/robust/landscape-figurative etc.), no \'serves as\'/\'stands as\' copula avoidance — say \'is\'; no \'not just X, but Y\'; no rhetorical rule-of-three triads; no trailing participial padding (…, ensuring/reflecting…); no vague attribution; HARD em-dash budget: at most 4 in the entire pane, never two in one sentence — prefer periods, commas and colons; minimal boldface; specificity replaces significance language — a dated fact beats an importance claim. RHYTHM: no staccato chains of short clauses or fragments (max 1-2 fragments per pane, for genuine emphasis only); sentence length and structure must vary — long flowing sentences with subordinate clauses carry the prose, short ones are seasoning; never three consecutive sentences of the same shape. CITATION STYLE: when citing his podcasts, name the show only — never the date (\'(The Longest View)\', not \'(The Longest View, 15 Dec 2025)\'); dates stay internal. REGISTER EXEMPLARS: coach/onboarding-exemplars.md contains approved pane exemplars — match their cadence, dash discipline and warmth exactly.');
  return parts.join(' ');
}

// The always-on founder contract (T0): how to be with Bill, every session. Canonical
// human-readable version in coach/founder.md; his live corrections supersede all of it.
const BILL_CONTRACT =
  'SCRUBBED. The real BILL_CONTRACT is written from the principal\'s record and is not distributed outside Elliot\'s machine.';

export function startCoach(state, library, input) {
  const now = input.now ?? new Date().toISOString();
  const onboarding = getOnboarding(state);
  const onboardingActive = onboarding.status !== 'complete';

  // Recover exactly one active session; anything older is abandoned housekeeping.
  const actives = state.prepare(
    `SELECT * FROM sessions WHERE status = 'active' ORDER BY updated_at DESC`
  ).all();
  let session = actives[0] ?? null;
  state.exec('BEGIN IMMEDIATE');
  try {
    for (const stale of actives.slice(1)) {
      state.prepare(`UPDATE sessions SET status = 'abandoned', updated_at = ? WHERE id = ?`).run(now, stale.id);
    }
    if (session) {
      state.prepare(`UPDATE sessions SET updated_at = ? WHERE id = ?`).run(now, session.id);
      session.version = state.prepare(`SELECT version FROM sessions WHERE id = ?`).get(session.id).version;
    } else {
      session = {
        id: randomUUID(), started_at: now, updated_at: now, status: 'active',
        situation: null, judgment: null, evidence_ids_json: '[]',
        open_questions_json: '[]', next_move: null, version: 1,
      };
      state.prepare(
        `INSERT INTO sessions (id, started_at, updated_at, status, version) VALUES (?, ?, ?, 'active', 1)`
      ).run(session.id, now, now);
    }
    state.exec('COMMIT');
  } catch (err) {
    state.exec('ROLLBACK');
    throw err;
  }

  const resumed = actives.length > 0;
  const mode = onboardingActive ? 'onboarding' : resumed ? 'resume' : 'new_episode';

  const commitments = state.prepare(
    `SELECT id, owner, commitment, due_at, next_review_at FROM commitments WHERE status = 'open' ORDER BY due_at IS NULL, due_at LIMIT 12`
  ).all().map((c) => ({
    ...c,
    at_risk: !!c.due_at && Date.parse(c.due_at) < Date.parse(now) + 7 * 86_400_000,
    overdue: !!c.due_at && c.due_at < now,
  }));

  const metrics = state.prepare(
    `SELECT id, name, value_text, unit, scope, as_of, staleness_class FROM metrics WHERE status = 'active' ORDER BY as_of DESC LIMIT 20`
  ).all().map((m) => ({ ...m, stale: computeStaleness(m, Date.parse(now)) }));

  const allMemories = state.prepare(
    `SELECT id, type, subject, content, effective_at, sensitive, updated_at FROM memories WHERE status = 'active'`
  ).all();
  // Orientation memory payloads are size-budgeted: full bodies live behind inspect_memory.
  const compact = ({ updated_at, ...m }) => ({
    ...m,
    content: m.content.length > 420 ? `${m.content.slice(0, 420)} … [full text: inspect_memory "${m.id}"]` : m.content,
  });
  let memories;
  if (onboardingActive) {
    // Panes retrieve their own depth (inspect_memory over mj-* namespaces; search_library
    // over the interview corpus). Orientation carries only the compact company baseline —
    // dumping the full profile here overflows the tool-result budget and breaks onboarding.
    memories = allMemories.filter((m) => m.id.startsWith('seed-')).map(compact);
  } else {
    const terms = (input.user_message.toLowerCase().match(/[\p{L}\p{N}][\p{L}\p{N}'-]*/gu) ?? [])
      .filter((w) => w.length >= 3);
    // Anything written during THIS session comes back unconditionally. When Bill's
    // window closes mid-thought and he reopens with "back again", lexical recall has
    // nothing to match on and the work they just did would be invisible — the crash
    // would read as amnesia even though every row is safely on disk.
    const resumedFrom = session?.started_at ?? null;
    const thisSession = resumedFrom
      ? allMemories.filter((m) => (m.updated_at ?? '') >= resumedFrom).slice(0, 8)
      : [];
    const carried = new Set(thisSession.map((m) => m.id));
    const ranked = allMemories
      .filter((m) => !carried.has(m.id))
      .map((m) => ({ ...m, _s: scoreTextMatch(`${m.subject} ${m.content}`, terms) + (m.type === 'company' || m.type === 'person' ? 0.5 : 0) }))
      .sort((a, b) => b._s - a._s)
      .slice(0, Math.max(0, 12 - thisSession.length))
      .map(({ _s, ...m }) => m);
    memories = [...thisSession, ...ranked].map(compact);
  }

  // The founder model is always in context — empathy and calibration must never depend
  // on lexical recall (one row; trivial cost).
  const principalProfile = state.prepare(`SELECT id, name, role, strengths_json, focus_areas_json, working_model FROM principal_profile ORDER BY name`).all()
    .map((p) => ({ ...p, strengths: JSON.parse(p.strengths_json), focus_areas: JSON.parse(p.focus_areas_json), strengths_json: undefined, focus_areas_json: undefined }));

  const recentSessions = state.prepare(
    `SELECT id, closed_at, situation, judgment, next_move FROM sessions WHERE status = 'closed' ORDER BY closed_at DESC LIMIT 3`
  ).all();

  const recentDecisions = state.prepare(
    `SELECT id, decision, reason, made_at, outcome FROM decisions WHERE status = 'active' ORDER BY made_at DESC LIMIT 8`
  ).all();

  const reviewRow = state.prepare(`SELECT value_json FROM settings WHERE key = 'next_review_at'`).get();
  const nextReviewAt = reviewRow ? JSON.parse(reviewRow.value_json) : null;

  let sourceCandidates = [];
  const match = ftsQueryFromText(input.user_message, { maxTerms: 10 });
  if (match) {
    sourceCandidates = library.prepare(`
      SELECT c.document_id, c.id AS chunk_id, d.title, d.kind, d.occurred_at,
             snippet(chunks_fts, 0, '', '', ' … ', 24) AS snippet, bm25(chunks_fts) AS rank
      FROM chunks_fts
      JOIN chunks c ON c.id = chunks_fts.rowid
      JOIN documents d ON d.id = c.document_id AND d.status = 'active'
      WHERE chunks_fts MATCH ? ORDER BY rank LIMIT 8
    `).all(match).map(({ rank, ...r }) => r);
  }

  // Onboarding pane 2 needs his record; panes retrieve depth themselves.
  if (onboardingActive) {
    const freshest = [];
    for (const row of library.prepare(`SELECT id AS document_id, title, kind, occurred_at FROM documents
          WHERE kind = 'doctrine-text' AND title LIKE '%Field Notes%' AND status = 'active' LIMIT 4`).all()) {
      freshest.push(row);
    }
    const seen = new Set(sourceCandidates.map((c) => c.document_id));
    for (const f of freshest) {
      if (seen.has(f.document_id)) continue;
      seen.add(f.document_id);
      sourceCandidates.push({ ...f, freshest_primary: true });
    }
  }

  // The funnel orientation block — the hub's live picture, every session.
  const lastClosed = state.prepare(
    `SELECT id FROM sessions WHERE status = 'closed' ORDER BY closed_at DESC LIMIT 1`
  ).get();
  const funnel = funnelSnapshot(state, lastClosed ? lastClosed.id : null);
  const learningTail = state.prepare(
    `SELECT category, learning, occurred_at FROM learnings ORDER BY occurred_at DESC LIMIT 5`
  ).all();
  const wantRow = state.prepare(`SELECT value_json FROM settings WHERE key = 'want_picture'`).get();
  const wantPicture = wantRow ? JSON.parse(wantRow.value_json) : null;

  const interrupted = resumed && (session.situation || session.judgment)
    ? { situation: session.situation, judgment: session.judgment, next_move: session.next_move, open_questions: JSON.parse(session.open_questions_json ?? '[]') }
    : null;

  // ---- COMMAND TAXONOMY (hardcoded, one-word, Bill-facing) ----
  // Session: coach / end
  // Inspect: memory / pipeline / sources / changes / recall
  // Control: correct / forget
  const COMMAND_ROUTING = `COMMAND ROUTING (hardcoded — recognise these exact words as commands; Bill may use them standalone or in a sentence):
SESSION COMMANDS:
  "coach" → already handled (this session is open). If Bill says it mid-session, acknowledge you're here.
  "end" → call end_coach with session judgment and next_move. Closing the window also ends the session.
INSPECT COMMANDS:
  "memory" → full dump of every data store: call inspect_memory across ALL bj-* namespaces, then search_state across ALL tables (roles, interactions, offers, contacts, learnings, voice_deltas, investor_roster, sourcing_runs, commitments), the always-on principal model (people), then summarise the library doc inventory. Present everything, no edits, no omissions. This is the total-transparency command.
  "pipeline" → call search_state(tables:["roles","interactions","offers","contacts"]) and present the full funnel: every company, its stage, lane, latest event, next action, and the history underneath. Format as a table with detail expandable per row.
  "sources" → when Bill says "sources" (or "source" or "why do you believe that"), show the provenance chain for the claim in question: the fact, where it came from (web URL, baseline row, his own words with date, Elliot briefing), and when it was last verified.
  "changes" → call search_state for all role_events, learnings, voice_deltas, and memory writes from the current session_id. Present as a chronological list: what changed, old value, new value, provenance. Nothing hidden.
  "recall [topic]" → call inspect_memory for matching bj-* namespaces + search_state with the topic as query across all tables + search_library. Present everything held on that subject.
CONTROL COMMANDS:
  "correct [statement]" → Bill is overriding a fact or judgment. Identify the record (memory atom, role field, profile entry), update it via save_coaching_state or update_state with provenance "bill-said", preserve the old value in history (role_events for funnel, memory versioning for atoms). Acknowledge the correction and confirm what changed.
  "forget [topic]" → Bill wants something removed. Identify the record, delete or nullify it, confirm what was removed. Irreversible — confirm before executing if the target is ambiguous.
These commands are ALWAYS available, during onboarding and after. They take priority over any other interpretation of Bill's message. If Bill's message matches a command, execute the command; coaching continues in the same response after the command output.`;

  return {
    session_id: session.id,
    session_version: session.version,
    mode,
    voice: 'FIRST OUTPUT: the first visible characters of this reply are the coaching itself; any startup narration before or between tool calls is a defect. Tool work is invisible. Emit no user-visible text until every tool call for this reply is finished — never "I\'ll open the session", "pulling up", "saving", "recorded", no narration of checking or storing, in any text segment. The first words the user sees are already the coaching.',
    commands: COMMAND_ROUTING,
    doctrine_binding: 'ABSOLUTE: the coaching doctrine surfaces (method.md, narrative.md, sourcing.md, funnel-doctrine.md, deliverables.md, voice.md, principal.md, identity.md) govern all coaching reasoning. They are binding input references, not optional context. Every non-deterministic decision must be consistent with applicable doctrine. When doctrine covers a topic, follow it. When doctrine is silent, reason in its spirit and flag the gap. Bill\'s live corrections are the only force that supersedes doctrine.',
    principal: BILL_CONTRACT,
    onboarding: onboardingActive
      ? {
          status: onboarding.status,
          draft_picture: onboarding.draft_picture,
          corrections: onboarding.corrections,
          exchange_contract: onboardingContract(onboarding),
        }
      : null,
    interrupted_work: interrupted,
    funnel,
    learning_ledger_tail: learningTail,
    want_picture: wantPicture,
    active_commitments: commitments,
    current_metrics: metrics,
    relevant_memories: memories,
    ...(principalProfile.length ? { principal_profile: principalProfile } : {}),
    recent_sessions: recentSessions,
    recent_decisions: recentDecisions,
    ...(nextReviewAt ? { next_review_at: nextReviewAt, review_due: nextReviewAt <= now } : {}),
    source_candidates: sourceCandidates,
  };
}

export function endCoach(state, input, nowIso = new Date().toISOString()) {
  const session = state.prepare(`SELECT id, version FROM sessions WHERE id = ?`).get(input.session_id);
  if (!session) return { error: `unknown session: ${input.session_id}` };
  if (session.version !== input.expected_session_version) {
    return {
      error: 'session_version_conflict',
      session_id: session.id,
      session_version: session.version,
    };
  }

  state.exec('BEGIN IMMEDIATE');
  try {
    state.prepare(`
      UPDATE sessions SET status = 'closed', judgment = ?, next_move = ?, closed_at = ?, updated_at = ?, version = version + 1
      WHERE id = ?
    `).run(input.judgment, input.next_move, nowIso, nowIso, session.id);

    const conflicts = [];
    const changedIds = [];
    for (const c of input.commitments ?? []) {
      applyCommitment(state, { ...c, action: 'upsert' }, nowIso, conflicts, changedIds);
    }
    if (input.next_review_at) {
      state.prepare(`
        INSERT INTO settings (key, value_json, updated_at) VALUES ('next_review_at', ?, ?)
        ON CONFLICT(key) DO UPDATE SET value_json = excluded.value_json, updated_at = excluded.updated_at
      `).run(JSON.stringify(input.next_review_at), nowIso);
    }
    state.exec('COMMIT');
  } catch (err) {
    state.exec('ROLLBACK');
    throw err;
  }

  const open = state.prepare(
    `SELECT id, owner, commitment, due_at, next_review_at FROM commitments WHERE status = 'open' ORDER BY due_at IS NULL, due_at`
  ).all();
  return {
    session_id: session.id,
    closed_at: nowIso,
    open_commitments: open,
    next_review_at: input.next_review_at ?? null,
  };
}

// ---------------------------------------------------------------------------
// Hook CLI. Continuity protection only; no coaching, no visible status output.


function active_session_id_for_guard(active) { return active.id; }
async function hookMain(event) {
  const { readFileSync } = await import('node:fs');
  let payload = {};
  try { payload = JSON.parse(readFileSync(0, 'utf8') || '{}'); } catch { /* observation only */ }

  if (event === 'hook-session-start' || event === 'hook-post-compact') {
    const silence = ' Tool work is invisible: write no user-visible text until all tool calls for the reply are done — never "I\'ll open the session", "pulling up", "saving", "recorded" or any narration of checking/retrieving/storing. The first words the user sees are already the coaching.';
    const intent = (event === 'hook-post-compact'
      ? 'Context was compacted. Call start_coach now with recovery intent: it returns the active session, its judgment and open questions — resume that work, do not restart discovery.'
      : 'Begin by calling start_coach with the user\'s opening message before responding. If it reports interrupted work, resume it naturally.') + silence;
    process.stdout.write(JSON.stringify({
      hookSpecificOutput: { hookEventName: event === 'hook-post-compact' ? 'PostCompact' : 'SessionStart', additionalContext: intent },
    }));
    return;
  }

  if (event === 'hook-stop') {
    if (payload.stop_hook_active) return; // never loop
    try {
      const { DatabaseSync } = await import('node:sqlite');
      // Hooks do not inherit the MCP server's env; the plugin root IS the data dir
      // (installer renders __DATA_DIR__ = pluginDir), passed as argv by hooks.json.
      const dataDir = process.env.BILL_COACH_DATA_DIR || process.env.CLAUDE_PLUGIN_ROOT || process.argv[3];
      if (!dataDir) return;
      const db = new DatabaseSync(`${dataDir}/state/coach.sqlite`, { readOnly: true });
      const active = db.prepare(
        `SELECT id, version, updated_at, started_at FROM sessions WHERE status = 'active' ORDER BY updated_at DESC LIMIT 1`
      ).get();
      const ob = db.prepare(`SELECT status, updated_at FROM onboarding WHERE singleton = 1`).get();
      db.close();
      // During the onboarding walkthrough every pane MUST be checkpointed before the
      // response ends; instruction alone proved unreliable, so enforce it here. A recent
      // onboarding save (within the last 2 minutes) means this exchange checkpointed.
      if (ob && ob.status !== 'complete' && Date.now() - Date.parse(ob.updated_at) > 2 * 60_000) {
        process.stdout.write(JSON.stringify({
          decision: 'block',
          reason: 'The pane you just presented is not checkpointed. Call save_coaching_state now with the onboarding status for that pane (pane_N you just presented, plus any corrections Bill gave), then stop. Do not add any further user-visible text.',
        }));
        return;
      }
      // DOCTRINE CITATION GUARD (hard requirement): the works behind the coach are named
      // once, in onboarding pane 1, and never again. A reply that cites them to Bill
      // is a failed reply — block and force a rewrite as embedded philosophy.
      try {
        const tPath = payload.transcript_path;
        const paneOneWindow = !ob || !ob.status || ob.status === 'pane_1';
        if (tPath && !paneOneWindow) {
          const tLines = readFileSync(tPath, 'utf8').trim().split('\n');
          let lastText = '';
          for (let i = tLines.length - 1; i >= 0; i -= 1) {
            try {
              const entry = JSON.parse(tLines[i]);
              if (entry.type === 'assistant' && entry.message && Array.isArray(entry.message.content)) {
                lastText = entry.message.content.filter((b) => b.type === 'text').map((b) => b.text).join('\n');
                if (lastText) break;
              }
            } catch { /* skip unparseable transcript lines */ }
          }
          const bannedNames = ['Kazanjy', 'Founding Sales', 'Fitzpatrick', 'Mom Test', 'Never Search Alone',
            'Phyl Terry', 'Burnett', 'Cal Newport', 'So Good They', 'Heath', 'Decisive',
            'Designing Your Life', 'Goldratt', 'Christensen', 'Munger', 'Cialdini', 'Keenan',
            'Meadows', 'Senge', 'Voss', 'Gap Selling', 'Gap Prospecting', 'High Output Management',
            'Crossing the Chasm', 'Innovator', 'Thinking in Systems', 'Fifth Discipline',
            'Never Split the Difference', 'Poor Charlie', 'Sciences of the Artificial',
            'Design of Everyday Things', 'Constitutional AI', 'LongMemEval', 'CoALA', 'ICLR',
            'EMNLP', 'sycophancy'];
          const hits = bannedNames.filter((t) => lastText.includes(t));
          if (hits.length > 0) {
            process.stdout.write(JSON.stringify({
              decision: 'block',
              reason: 'Your reply cites doctrine sources by name (' + hits.join(', ') + '). The works behind the coach were named once, in onboarding pane 1, and never again: rewrite the same substance as one holistic embedded philosophy in plain language with no author, book, framework or research names, and send that instead.',
            }));
            return;
          }
        }
      } catch { /* never block a stop on guard failure */ }
      // VERBATIM PANE GUARD: pre-written panes are principal-approved and ship verbatim.
      // Instruction alone proved unreliable (a prior build drifted from its locked
      // panes), so enforce mechanically: the response that presented pane N must contain
      // the locked exemplar text. The permitted deviations (integration lines above the
      // pane, Bill's corrections woven in, figures superseded by live data) make an exact
      // hash wrong; require paragraph containment with a small tolerance instead.
      try {
        const tPath = payload.transcript_path;
        const paneM = /^pane_(\d)$/.exec(ob?.status ?? '');
        const recentPane = ob && ob.updated_at && Date.now() - Date.parse(ob.updated_at) <= 2 * 60_000;
        if (tPath && paneM && recentPane) {
          const exemplar = paneExemplar(Number(paneM[1]));
          if (exemplar) {
            const tLines = readFileSync(tPath, 'utf8').trim().split('\n');
            let lastText = '';
            for (let i = tLines.length - 1; i >= 0; i -= 1) {
              try {
                const entry = JSON.parse(tLines[i]);
                if (entry.type === 'assistant' && entry.message && Array.isArray(entry.message.content)) {
                  lastText = entry.message.content.filter((b) => b.type === 'text').map((b) => b.text).join('\n');
                  if (lastText) break;
                }
              } catch { /* skip unparseable transcript lines */ }
            }
            const norm = (s) => s
              .replace(/[\u2018\u2019]/g, "'")
              .replace(/[\u201C\u201D]/g, '"')
              .replace(/\s+/g, ' ')
              .trim();
            const reply = norm(lastText);
            const paras = exemplar.split(/\n\s*\n/).map(norm).filter((p) => p.length >= 60);
            if (reply && paras.length >= 3) {
              const missing = paras.filter((p) => !reply.includes(p));
              const tolerance = Math.max(1, Math.floor(paras.length * 0.2));
              if (missing.length > tolerance) {
                process.stdout.write(JSON.stringify({
                  decision: 'block',
                  reason: 'This pane is pre-written and principal-approved; your response rewrote it instead of printing it. Send the pane again as the locked text, verbatim and in full. The only allowed changes: the one-or-two-line integration of Bill\'s reply above it, his corrections where they apply, and figures superseded by live data. Missing locked passages begin: ' + missing.slice(0, 2).map((p) => '"' + p.slice(0, 70) + '..."').join(' | '),
                }));
                return;
              }
            }
          }
        }
      } catch { /* never block a stop on guard failure */ }
      // UNCLOSED-WORK GUARD: rate of learning is a hard rule — a session that moved the
      // funnel (phase changes, exits, new interactions) but captured zero learnings is
      // incomplete. Block once with an instructive reason.
      try {
        if (active) {
          const movedN = db.prepare(
            `SELECT COUNT(*) AS n FROM role_events WHERE session_id = ? AND event_type IN ('phase_change', 'exit', 'created')`
          ).get(active_session_id_for_guard(active)).n;
          const learnedN = db.prepare(
            `SELECT COUNT(*) AS n FROM learnings WHERE created_at >= ?`
          ).get(active.started_at).n;
          if (movedN > 0 && learnedN === 0) {
            const flagged = db.prepare(`SELECT value FROM state_meta WHERE key = 'unclosed_guard_fired'`).get();
            if (!flagged || flagged.value !== active_session_id_for_guard(active)) {
              // fire once per session; record via side write is not possible on a readOnly
              // handle, so tolerate double-fire on rare double-stop instead of writing here.
              process.stdout.write(JSON.stringify({
                decision: 'block',
                reason: 'Close the work: this session moved the funnel but captured no learning. Save what we learned (save_coaching_state.learnings — one line each, category + source) then stop.',
              }));
              return;
            }
          }
        }
      } catch { /* never block a stop on guard failure */ }

      // Ask once only when an episode has run long past its last checkpoint (any version:
      // material changes after a first save deserve the same protection).
      const staleMs = active ? Date.now() - Date.parse(active.updated_at) : 0;
      if (active && staleMs > 20 * 60_000) {
        process.stdout.write(JSON.stringify({
          decision: 'block',
          reason: 'If this exchange produced material decisions, commitments, corrections or lessons not yet saved, call save_coaching_state once now with all of them; if nothing material changed, simply stop.',
        }));
      }
    } catch { /* never block a stop on hook failure */ }
    return;
  }

  // No SessionEnd hook: an active session row is already the interruption marker, and
  // nothing else is worth doing during termination.
}

const invokedDirectly = process.argv[1] && import.meta.url === (await import('node:url')).pathToFileURL(process.argv[1]).href;
if (invokedDirectly && process.argv[2]?.startsWith('hook-')) {
  await hookMain(process.argv[2]);
}
