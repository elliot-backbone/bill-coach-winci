// Durable coach state: save_coaching_state (one transaction per exchange) and
// inspect_memory. One writer, optimistic session versioning, supersession over deletion.

import { randomUUID } from 'node:crypto';
import { applyOnboarding } from './onboarding.mjs';
import { refreshFts } from './statesearch.mjs';

const STALENESS_DAYS = { fast: 30, normal: 90, slow: 180, static: Infinity };

export function computeStaleness(metric, nowMs = Date.now()) {
  const limit = STALENESS_DAYS[metric.staleness_class] ?? 90;
  if (limit === Infinity) return false;
  const age = (nowMs - Date.parse(metric.as_of)) / 86_400_000;
  // A metric whose date cannot be read is not evidence of freshness. Treat it as
  // stale so it is re-checked, rather than trusting it forever.
  return Number.isFinite(age) ? age > limit : true;
}

function json(value) { return JSON.stringify(value ?? []); }

// A date the runtime cannot parse is worse than no date at all: it is stored,
// it looks set, and every comparison against it quietly answers "no". A
// commitment dated "next tuesday-ish" is never overdue and never at risk, so
// Coach never chases it. Reject the value at the boundary and say so.
const ISO_DATE = /^\d{4}-\d{2}-\d{2}([T ]\d{2}:\d{2}(:\d{2}(\.\d+)?)?(Z|[+-]\d{2}:?\d{2})?)?$/;

export function isParsableDate(value) {
  return typeof value === 'string' && ISO_DATE.test(value) && !Number.isNaN(Date.parse(value));
}

/** Returns the value if it is an ISO-8601 date, otherwise null plus a conflict. */
function isoOrNull(value, { field, table, id, conflicts }) {
  if (value === undefined || value === null || value === '') return null;
  if (isParsableDate(value)) return value;
  conflicts.push({
    type: 'bad_date',
    table,
    id,
    field,
    value: String(value).slice(0, 60),
    resolution: 'give an ISO-8601 date (YYYY-MM-DD, or a full timestamp); the field was left empty',
  });
  return null;
}

export function saveCoachingState(state, input, nowIso = new Date().toISOString()) {
  const conflicts = [];
  const changed = {
    memories: [], metrics: [], decisions: [], commitments: [], learnings: [], voice_deltas: [], principal_profile: [],
    deliverables: [], narrative_coverage: [], green_flags: [], onboarding: null, session: null,
  };

  const session = state.prepare(`SELECT id, version FROM sessions WHERE id = ?`).get(input.session_id);
  if (!session) return { error: `unknown session: ${input.session_id}` };
  if (session.version !== input.expected_session_version) {
    return {
      session_id: session.id,
      session_version: session.version,
      changed: {},
      conflicts: [{
        type: 'session_version',
        expected: input.expected_session_version,
        actual: session.version,
        resolution: 'reload with start_coach or retry with the current version',
      }],
    };
  }

  state.exec('BEGIN IMMEDIATE');
  try {
    if (input.onboarding) {
      applyOnboarding(state, input.onboarding, nowIso);
      changed.onboarding = input.onboarding.status;
    }

    // Data is data. Confirmation is not a tier and never gates a write: what Bill
    // tells Coach is recorded, and if he corrects it later the correction supersedes
    // it. Sensitivity is a separate thing — it governs tact, not trust.
    for (const m of input.memories ?? []) {
      applyStatusRow(state, 'memories', m, nowIso, conflicts, changed.memories, {
        insert: () => state.prepare(`
          INSERT INTO memories (id, type, subject, content, status, effective_at, source_ids_json, sensitive, supersedes_id, created_at, updated_at)
          VALUES (?, ?, ?, ?, 'active', ?, ?, ?, ?, ?, ?)
        `).run(m.id, m.type, m.subject, m.content, m.effective_at ?? null, json(m.source_ids), m.sensitive ? 1 : 0, m.supersedes_id ?? null, nowIso, nowIso),
        update: () => state.prepare(`
          UPDATE memories SET type = ?, subject = ?, content = ?, effective_at = ?, source_ids_json = ?, sensitive = ?, updated_at = ?
          WHERE id = ?
        `).run(m.type, m.subject, m.content, m.effective_at ?? null, json(m.source_ids), m.sensitive ? 1 : 0, nowIso, m.id),
      });
    }

    for (const l of input.learnings ?? []) {
      applyLearning(state, l, nowIso, conflicts, changed.learnings);
    }

    // A debrief review IS a performance learning about one interaction. The doctrine's
    // COMPOUND_RULE names `interaction_reviews`; rather than a table nothing else uses,
    // it lands in the ledger where the next debrief will actually find it.
    for (const r of input.interaction_reviews ?? []) {
      applyLearning(state, {
        id: r.id,
        category: 'performance',
        learning: r.focus_next ?? r.review,
        evidence: r.did_well ?? null,
        source_kind: 'interaction',
        source_id: r.interaction_id ?? null,
        fed_into: r.fed_into,
        occurred_at: r.occurred_at,
      }, nowIso, conflicts, changed.learnings);
    }

    for (const d of input.voice_deltas ?? []) {
      applyVoiceDelta(state, d, nowIso, conflicts, changed.voice_deltas);
    }

    for (const m of input.metrics ?? []) {
      // as_of is what a metric MEANS — a value without a readable date cannot be
      // compared, superseded or aged, so this row is refused rather than stored.
      if (!isParsableDate(m.as_of)) {
        conflicts.push({
          type: 'bad_date',
          table: 'metrics',
          id: m.id,
          field: 'as_of',
          value: String(m.as_of).slice(0, 60),
          resolution: 'give an ISO-8601 date for as_of; this metric was not saved',
        });
        continue;
      }
      // One active value per (name, scope): a new value automatically supersedes an older
      // active row for the same metric even when the model omits the explicit supersede.
      if (m.action === 'upsert' && !m.supersedes_id) {
        const prior = state.prepare(
          `SELECT id FROM metrics WHERE status = 'active' AND id != ? AND LOWER(name) = LOWER(?) AND LOWER(scope) = LOWER(?) AND as_of < ?`
        ).get(m.id, m.name, m.scope, m.as_of);
        if (prior) {
          state.prepare(`UPDATE metrics SET status = 'superseded', updated_at = ? WHERE id = ?`).run(nowIso, prior.id);
        }
      }
      applyStatusRow(state, 'metrics', m, nowIso, conflicts, changed.metrics, {
        insert: () => state.prepare(`
          INSERT INTO metrics (id, name, value_text, unit, definition, scope, as_of, staleness_class, status, supersedes_id, source_ids_json, created_at, updated_at)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'active', ?, ?, ?, ?)
        `).run(m.id, m.name, m.value_text, m.unit ?? null, m.definition ?? null, m.scope, m.as_of, m.staleness_class, m.supersedes_id ?? null, json(m.source_ids), nowIso, nowIso),
        update: () => state.prepare(`
          UPDATE metrics SET name = ?, value_text = ?, unit = ?, definition = ?, scope = ?, as_of = ?, staleness_class = ?, source_ids_json = ?, updated_at = ?
          WHERE id = ?
        `).run(m.name, m.value_text, m.unit ?? null, m.definition ?? null, m.scope, m.as_of, m.staleness_class, json(m.source_ids), nowIso, m.id),
      });
    }

    for (const d of input.decisions ?? []) {
      const existing = state.prepare(`SELECT id FROM decisions WHERE id = ?`).get(d.id);
      if (d.action === 'upsert') {
        if (existing) {
          state.prepare(`UPDATE decisions SET decision = ?, reason = ?, made_at = ?, outcome = ?, source_ids_json = ?, updated_at = ? WHERE id = ?`)
            .run(d.decision, d.reason ?? null, d.made_at, d.outcome ?? null, json(d.source_ids), nowIso, d.id);
        } else {
          state.prepare(`INSERT INTO decisions (id, decision, reason, made_at, status, outcome, source_ids_json, created_at, updated_at) VALUES (?, ?, ?, ?, 'active', ?, ?, ?, ?)`)
            .run(d.id, d.decision, d.reason ?? null, d.made_at, d.outcome ?? null, json(d.source_ids), nowIso, nowIso);
        }
        changed.decisions.push(d.id);
      } else if (!existing) {
        conflicts.push({ type: 'unknown_id', table: 'decisions', id: d.id });
      } else {
        const status = { revisit: 'revisited', reverse: 'reversed', complete: 'complete' }[d.action];
        state.prepare(`UPDATE decisions SET status = ?, outcome = COALESCE(?, outcome), updated_at = ? WHERE id = ?`)
          .run(status, d.outcome ?? null, nowIso, d.id);
        changed.decisions.push(d.id);
      }
    }

    for (const c of input.commitments ?? []) {
      applyCommitment(state, c, nowIso, conflicts, changed.commitments);
    }

    // `people` is the pre-1.3 spelling; both land in the same store so an older
    // instruction surface cannot silently write nothing.
    for (const p of [...(input.principal_profile ?? []), ...(input.people ?? [])]) {
      const existing = state.prepare(`SELECT id FROM principal_profile WHERE id = ?`).get(p.id);
      if (p.action === 'withdraw') {
        if (!existing) { conflicts.push({ type: 'unknown_id', table: 'principal_profile', id: p.id }); continue; }
        state.prepare(`DELETE FROM principal_profile WHERE id = ?`).run(p.id);
        changed.principal_profile.push(p.id);
        continue;
      }
      if (existing) {
        state.prepare(`UPDATE principal_profile SET name = ?, role = ?, strengths_json = ?, focus_areas_json = ?, working_model = ?, source_ids_json = ?, updated_at = ? WHERE id = ?`)
          .run(p.name, p.role ?? null, json(p.strengths), json(p.focus_areas), p.working_model ?? null, json(p.source_ids), nowIso, p.id);
      } else {
        state.prepare(`INSERT INTO principal_profile (id, name, role, strengths_json, focus_areas_json, working_model, source_ids_json, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`)
          .run(p.id, p.name, p.role ?? null, json(p.strengths), json(p.focus_areas), p.working_model ?? null, json(p.source_ids), nowIso, nowIso);
      }
      changed.principal_profile.push(p.id);
    }

    for (const l of input.learnings ?? []) {
      const lid = `learning-${randomUUID().slice(0, 8)}`;
      state.prepare(`
        INSERT INTO learnings (id, category, learning, evidence, source_kind, source_id, fed_into_json, occurred_at, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(lid, l.category, l.learning, l.evidence ?? null, l.source_kind, l.source_id ?? null,
        JSON.stringify(l.fed_into ?? []), nowIso, nowIso);
      refreshFts(state, 'learnings', lid);
      (changed.learnings ??= []).push(lid);
    }

    // Biographical coverage: what the tight-five interview actually has, slot by slot. The
    // gate reads this, so a scene with no age or date attached does not count — an undated
    // scene cannot be sequenced later and is the shape of a story that dies under follow-up.
    for (const c of input.narrative_coverage ?? []) {
      if (!c.slot || !String(c.scene ?? '').trim()) {
        conflicts.push({ table: 'narrative_coverage', reason: 'a coverage row needs a slot and a scene', slot: c.slot });
        continue;
      }
      const cid = `cover-${randomUUID().slice(0, 8)}`;
      state.prepare(`
        INSERT INTO narrative_coverage (id, slot, scene, age_or_date, named_detail, verbatim, flag_id, source_kind, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(cid, c.slot, c.scene, c.age_or_date ?? null, c.named_detail ?? null,
        c.verbatim ?? null, c.flag_id ?? null, c.source_kind ?? 'interview', nowIso);
      (changed.narrative_coverage ??= []).push(cid);
    }

    // Green flag ranking: the library ships fixed, the ORDER is live. A flag that landed in a
    // real conversation rises; one that never comes up falls. Only the ranking and the counters
    // move — the flags themselves are doctrine and are not editable from a session.
    for (const g of input.green_flags ?? []) {
      const row = state.prepare('SELECT id, times_surfaced, times_landed FROM green_flags WHERE name = ?').get(g.name);
      if (!row) {
        conflicts.push({ table: 'green_flags', reason: `no flag named "${g.name}"`, name: g.name });
        continue;
      }
      state.prepare(`
        UPDATE green_flags SET current_rank = COALESCE(?, current_rank),
          times_surfaced = times_surfaced + ?, times_landed = times_landed + ?,
          rank_reason = COALESCE(?, rank_reason), last_ranked_at = ?, updated_at = ?
        WHERE id = ?
      `).run(g.current_rank ?? null, g.surfaced ? 1 : 0, g.landed ? 1 : 0,
        g.rank_reason ?? null, nowIso, nowIso, row.id);
      (changed.green_flags ??= []).push(row.id);
    }

    // Deliverables: the artefact itself, not the lesson drawn from it.
    //
    // Always an INSERT at the next version, never an update. Refining Bill's tight five must
    // leave the previous five intact — the history is the point, because a story that stopped
    // landing needs the version that did. `supersedes` chains a revision to what it replaces
    // and the prior head is retired in the same transaction, so exactly one row per kind is
    // live and the rest remain readable.
    for (const d of input.deliverables ?? []) {
      const kind = String(d.kind || '').trim();
      const body = String(d.body ?? '');
      if (!kind || !body.trim()) {
        conflicts.push({ table: 'deliverables', reason: 'a deliverable needs a kind and a non-empty body', kind });
        continue;
      }
      const scope = d.role_id ?? null;
      const head = state.prepare(
        `SELECT id, version FROM deliverables WHERE kind = ? AND status = 'live'
           AND (role_id IS ? OR role_id = ?) ORDER BY version DESC LIMIT 1`,
      ).get(kind, scope, scope);
      // An identical body is not a new version: re-showing a deliverable is not revising it.
      const same = head && state.prepare('SELECT body FROM deliverables WHERE id = ?').get(head.id)?.body === body;
      if (same) {
        (changed.deliverables ??= []).push(head.id);
        continue;
      }
      const did = `deliv-${randomUUID().slice(0, 8)}`;
      const version = head ? head.version + 1 : 1;
      if (head) state.prepare(`UPDATE deliverables SET status = 'retired', updated_at = ? WHERE id = ?`).run(nowIso, head.id);
      state.prepare(`
        INSERT INTO deliverables (id, kind, title, body, version, supersedes, change_note, status, role_id, session_id, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, 'live', ?, ?, ?, ?)
      `).run(did, kind, d.title ?? kind, body, version, head?.id ?? null,
        d.change_note ?? null, scope, d.session_id ?? null, nowIso, nowIso);
      refreshFts(state, 'deliverables', did);
      (changed.deliverables ??= []).push(did);
    }

    for (const v of input.voice_deltas ?? []) {
      const vid = `voice-${randomUUID().slice(0, 8)}`;
      state.prepare(`
        INSERT INTO voice_deltas (id, feature, rule, example, origin, status, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, 'active', ?, ?)
      `).run(vid, v.feature, v.rule, v.example ?? null, v.origin, nowIso, nowIso);
      refreshFts(state, 'voice_deltas', vid);
      (changed.voice_deltas ??= []).push(vid);
    }

    for (const r of input.interaction_reviews ?? []) {
      const existing = state.prepare('SELECT id FROM interactions WHERE id = ?').get(r.interaction_id);
      if (!existing) { conflicts.push({ type: 'interaction', id: r.interaction_id, reason: 'unknown interaction' }); continue; }
      state.prepare('UPDATE interactions SET review_json = ?, updated_at = ? WHERE id = ?')
        .run(JSON.stringify(r.review ?? {}), nowIso, r.interaction_id);
      refreshFts(state, 'interactions', r.interaction_id);
      (changed.interaction_reviews ??= []).push(r.interaction_id);
    }

    // The session block is optional. Every other branch here treats its input as optional and
    // this one did not, so a save that carried only learnings or only a deliverable threw on
    // `s.status` and lost the whole transaction. The tool schema never required it.
    const s = input.session;
    const newVersion = session.version + 1;
    if (!s) {
      state.prepare('UPDATE sessions SET updated_at = ?, version = ? WHERE id = ? AND version = ?')
        .run(nowIso, newVersion, session.id, session.version);
      state.exec('COMMIT');
      return {
        session_id: session.id,
        session_version: newVersion,
        changed: Object.fromEntries(Object.entries(changed).filter(([, v]) => (Array.isArray(v) ? v.length : v != null))),
        conflicts,
      };
    }
    state.prepare(`
      UPDATE sessions SET status = ?, situation = COALESCE(?, situation), judgment = COALESCE(?, judgment),
        evidence_ids_json = ?, open_questions_json = ?, next_move = COALESCE(?, next_move),
        closed_at = CASE WHEN ? IN ('closed','abandoned') THEN ? ELSE closed_at END,
        updated_at = ?, version = ?
      WHERE id = ? AND version = ?
    `).run(s.status, s.situation ?? null, s.judgment ?? null, json(s.evidence_ids), json(s.open_questions),
      s.next_move ?? null, s.status, nowIso, nowIso, newVersion, session.id, session.version);
    changed.session = s.status;

    state.exec('COMMIT');
    return {
      session_id: session.id,
      session_version: newVersion,
      changed: Object.fromEntries(Object.entries(changed).map(([k, v]) =>
        Array.isArray(v) ? [k, { count: v.length, ids: v }] : [k, v])),
      conflicts,
    };
  } catch (err) {
    state.exec('ROLLBACK');
    throw err;
  }
}

// Shared upsert/supersede/withdraw for memories and metrics (status-tracked tables).
function applyStatusRow(state, table, item, nowIso, conflicts, changedIds, ops) {
  const existing = state.prepare(`SELECT id, status FROM ${table} WHERE id = ?`).get(item.id);
  if (item.action === 'upsert') {
    existing ? ops.update() : ops.insert();
    changedIds.push(item.id);
    return;
  }
  if (item.action === 'supersede') {
    const priorId = item.supersedes_id;
    if (!priorId) { conflicts.push({ type: 'supersede_requires_supersedes_id', table, id: item.id }); return; }
    const prior = state.prepare(`SELECT id FROM ${table} WHERE id = ?`).get(priorId);
    if (!prior) { conflicts.push({ type: 'unknown_id', table, id: priorId }); return; }
    if (existing) { conflicts.push({ type: 'id_already_exists', table, id: item.id }); return; }
    ops.insert();
    state.prepare(`UPDATE ${table} SET status = 'superseded', updated_at = ? WHERE id = ?`).run(nowIso, priorId);
    changedIds.push(item.id);
    return;
  }
  if (item.action === 'withdraw') {
    if (!existing) { conflicts.push({ type: 'unknown_id', table, id: item.id }); return; }
    state.prepare(`UPDATE ${table} SET status = 'withdrawn', updated_at = ? WHERE id = ?`).run(nowIso, item.id);
    changedIds.push(item.id);
  }
}

/**
 * The learning ledger. Doctrine requires a learning at the close of every unit of work
 * and the funnel refuses to exit a role without one — but before 1.2.5 there was no way
 * to write one: `learnings` was absent from this tool and from the funnel's writable
 * tables, so the guard could never be satisfied and dead roles could not leave the funnel.
 */
export function applyLearning(state, l, nowIso, conflicts, changedIds) {
  // A debrief names both `learnings` and `interaction_reviews`, and both land here.
  // A model that fills in both — reasonably, since the doctrine names both — would
  // otherwise write the same insight twice and make the ledger read as if the same
  // lesson were learned repeatedly. Identity is the text, not the id it arrived under.
  const fingerprint = String(l.learning ?? '').trim().toLowerCase().replace(/\s+/g, ' ');
  const twin = fingerprint
    ? state.prepare(`SELECT id FROM learnings WHERE LOWER(TRIM(learning)) = ? AND id != ?`).get(fingerprint, l.id)
    : null;
  if (twin) {
    // Keep the row already on file; record the collapse rather than doing it silently.
    conflicts.push({
      type: 'duplicate_learning', table: 'learnings', id: l.id, kept: twin.id,
      resolution: 'the same insight was already in the ledger; it is stored once',
    });
    return;
  }
  const existing = state.prepare(`SELECT id FROM learnings WHERE id = ?`).get(l.id);
  const occurredAt = isoOrNull(l.occurred_at, { field: 'occurred_at', table: 'learnings', id: l.id, conflicts }) ?? nowIso;
  if (existing) {
    state.prepare(`UPDATE learnings SET category = ?, learning = ?, evidence = ?, source_kind = ?, source_id = ?, fed_into_json = ?, occurred_at = ? WHERE id = ?`)
      .run(l.category, l.learning, l.evidence ?? null, l.source_kind ?? 'session', l.source_id ?? null,
        json(l.fed_into), occurredAt, l.id);
  } else {
    state.prepare(`INSERT INTO learnings (id, category, learning, evidence, source_kind, source_id, fed_into_json, occurred_at, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`)
      .run(l.id, l.category, l.learning, l.evidence ?? null, l.source_kind ?? 'session', l.source_id ?? null,
        json(l.fed_into), occurredAt, nowIso);
  }
  changedIds.push(l.id);
}

/**
 * Voice deltas: the record of how Bill actually writes, learned from his edits.
 * writing-voice.md instructs the coach to record one whenever he rewrites a draft —
 * the table has always existed and been searchable, but nothing could write to it,
 * so every correction to his voice was lost the moment the session ended.
 */
export function applyVoiceDelta(state, d, nowIso, conflicts, changedIds) {
  const existing = state.prepare(`SELECT id FROM voice_deltas WHERE id = ?`).get(d.id);
  const ORIGINS = ['chat-mining', 'onboarding-sample', 'draft-correction', 'session'];
  const origin = ORIGINS.includes(d.origin) ? d.origin : 'draft-correction';
  if (d.origin && !ORIGINS.includes(d.origin)) {
    conflicts.push({
      type: 'bad_value', table: 'voice_deltas', id: d.id, field: 'origin', value: String(d.origin).slice(0, 40),
      resolution: `origin must be one of ${ORIGINS.join(', ')}; recorded as draft-correction`,
    });
  }
  if (existing) {
    state.prepare(`UPDATE voice_deltas SET feature = ?, rule = ?, example = ?, origin = ?, status = ?, updated_at = ? WHERE id = ?`)
      .run(d.feature, d.rule, d.example ?? null, origin, d.status ?? 'active', nowIso, d.id);
  } else {
    state.prepare(`INSERT INTO voice_deltas (id, feature, rule, example, origin, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`)
      .run(d.id, d.feature, d.rule, d.example ?? null, origin, d.status ?? 'active', nowIso, nowIso);
  }
  changedIds.push(d.id);
}

export function applyCommitment(state, c, nowIso, conflicts, changedIds) {
  const existing = state.prepare(`SELECT id, status FROM commitments WHERE id = ?`).get(c.id);
  // The commitment itself is kept — losing it entirely would be worse than losing
  // its date — but an unparsable date is not written as if it worked.
  const dueAt = isoOrNull(c.due_at, { field: 'due_at', table: 'commitments', id: c.id, conflicts });
  const reviewAt = isoOrNull(c.next_review_at, { field: 'next_review_at', table: 'commitments', id: c.id, conflicts });
  c = { ...c, due_at: dueAt, next_review_at: reviewAt };
  if (c.action === 'upsert' || c.action === undefined) {
    if (existing) {
      state.prepare(`UPDATE commitments SET owner = ?, commitment = ?, due_at = ?, next_review_at = ?, source_ids_json = ?, updated_at = ? WHERE id = ?`)
        .run(c.owner, c.commitment, c.due_at ?? null, c.next_review_at ?? null, json(c.source_ids), nowIso, c.id);
    } else {
      state.prepare(`INSERT INTO commitments (id, owner, commitment, due_at, status, outcome, next_review_at, source_ids_json, created_at, updated_at) VALUES (?, ?, ?, ?, 'open', ?, ?, ?, ?, ?)`)
        .run(c.id, c.owner, c.commitment, c.due_at ?? null, c.outcome ?? null, c.next_review_at ?? null, json(c.source_ids), nowIso, nowIso);
    }
    changedIds.push(c.id);
    return;
  }
  if (!existing) { conflicts.push({ type: 'unknown_id', table: 'commitments', id: c.id }); return; }
  if (c.action === 'change') {
    state.prepare(`UPDATE commitments SET owner = ?, commitment = ?, due_at = ?, next_review_at = ?, outcome = COALESCE(?, outcome), source_ids_json = ?, updated_at = ? WHERE id = ?`)
      .run(c.owner, c.commitment, c.due_at ?? null, c.next_review_at ?? null, c.outcome ?? null, json(c.source_ids), nowIso, c.id);
  } else {
    const status = { complete: 'done', drop: 'dropped' }[c.action];
    state.prepare(`UPDATE commitments SET status = ?, outcome = COALESCE(?, outcome), updated_at = ? WHERE id = ?`)
      .run(status, c.outcome ?? null, nowIso, c.id);
  }
  changedIds.push(c.id);
}

// Every table is searched by id as well as by prose. Orientation truncates long
// memories with `[full text: inspect_memory "<id>"]`, and before 1.2.5 following
// that instruction returned nothing at all: id was the one column not matched.
export function inspectMemory(state, input, nowMs = Date.now()) {
  const { query, types, status = 'active', limit = 25 } = input;
  const like = query ? `%${query.replace(/[%_]/g, (ch) => '\\' + ch)}%` : null;

  const statusFilter = (col = 'status') => status === 'all' ? '1=1' : `${col} = '${status}'`;
  const typeFilter = types?.length ? `AND type IN (${types.map(() => '?').join(',')})` : '';

  const memories = state.prepare(`
    SELECT id, type, subject, content, status, effective_at, sensitive, supersedes_id, updated_at
    FROM memories WHERE ${statusFilter()} ${typeFilter}
    ${like ? 'AND (id LIKE ? ESCAPE \'\\\' OR subject LIKE ? ESCAPE \'\\\' OR content LIKE ? ESCAPE \'\\\')' : ''}
    ORDER BY updated_at DESC LIMIT ?
  `).all(...(types ?? []), ...(like ? [like, like, like] : []), limit);

  const metrics = state.prepare(`
    SELECT id, name, value_text, unit, definition, scope, as_of, staleness_class, status, supersedes_id
    FROM metrics WHERE ${statusFilter()}
    ${like ? 'AND (id LIKE ? ESCAPE \'\\\' OR name LIKE ? ESCAPE \'\\\' OR definition LIKE ? ESCAPE \'\\\' OR scope LIKE ? ESCAPE \'\\\')' : ''}
    ORDER BY as_of DESC LIMIT ?
  `).all(...(like ? [like, like, like, like] : []), limit).map((m) => ({ ...m, stale: computeStaleness(m, nowMs) }));

  const decisions = state.prepare(`
    SELECT id, decision, reason, made_at, status, outcome FROM decisions
    WHERE ${status === 'all' ? '1=1' : status === 'active' ? `status = 'active'` : `status != 'active'`}
    ${like ? 'AND (id LIKE ? ESCAPE \'\\\' OR decision LIKE ? ESCAPE \'\\\' OR reason LIKE ? ESCAPE \'\\\')' : ''}
    ORDER BY made_at DESC LIMIT ?
  `).all(...(like ? [like, like, like] : []), limit);

  const commitments = state.prepare(`
    SELECT id, owner, commitment, due_at, status, outcome, next_review_at FROM commitments
    WHERE ${status === 'all' ? '1=1' : `status = 'open'`}
    ${like ? 'AND (id LIKE ? ESCAPE \'\\\' OR owner LIKE ? ESCAPE \'\\\' OR commitment LIKE ? ESCAPE \'\\\')' : ''}
    ORDER BY due_at IS NULL, due_at LIMIT ?
  `).all(...(like ? [like, like, like] : []), limit);

  const principal = state.prepare(`
    SELECT id, name, role, strengths_json, focus_areas_json, working_model FROM principal_profile
    ${like ? 'WHERE (id LIKE ? ESCAPE \'\\\' OR name LIKE ? ESCAPE \'\\\' OR role LIKE ? ESCAPE \'\\\' OR working_model LIKE ? ESCAPE \'\\\')' : ''}
    ORDER BY name LIMIT ?
  `).all(...(like ? [like, like, like, like] : []), limit).map((p) => ({
    ...p,
    strengths: JSON.parse(p.strengths_json), focus_areas: JSON.parse(p.focus_areas_json),
    strengths_json: undefined, focus_areas_json: undefined,
  }));

  const learnings = state.prepare(`
    SELECT id, category, learning, evidence, source_kind, source_id, occurred_at FROM learnings
    ${like ? 'WHERE (id LIKE ? ESCAPE \'\\\' OR learning LIKE ? ESCAPE \'\\\' OR evidence LIKE ? ESCAPE \'\\\' OR category LIKE ? ESCAPE \'\\\')' : ''}
    ORDER BY occurred_at DESC LIMIT ?
  `).all(...(like ? [like, like, like, like] : []), limit);

  return { memories, metrics, decisions, commitments, learnings, principal_profile: principal };
}
