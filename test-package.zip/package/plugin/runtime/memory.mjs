// Durable coach state: save_coaching_state (one transaction per exchange) and
// inspect_memory. One writer, optimistic session versioning, supersession over deletion.

import { randomUUID } from 'node:crypto';
import { applyOnboarding } from './onboarding.mjs';
import { refreshFts } from './statesearch.mjs';

const STALENESS_DAYS = { fast: 30, normal: 90, slow: 180, static: Infinity };

export function computeStaleness(metric, nowMs = Date.now()) {
  const limit = STALENESS_DAYS[metric.staleness_class] ?? 90;
  if (limit === Infinity) return false;
  const age = (nowMs - Date.parse(metric.as_of)) / 86_400_000;
  return Number.isFinite(age) ? age > limit : false;
}

function json(value) { return JSON.stringify(value ?? []); }

export function saveCoachingState(state, input, nowIso = new Date().toISOString()) {
  const conflicts = [];
  const changed = {
    memories: [], metrics: [], decisions: [], commitments: [], people: [],
    onboarding: null, session: null,
  };

  const session = state.prepare(`SELECT id, version FROM sessions WHERE id = ?`).get(input.session_id);
  if (!session) return { error: `unknown session: ${input.session_id}` };
  if (session.version !== input.expected_session_version) {
    return {
      session_id: session.id,
      session_version: session.version,
      changed: {},
      conflicts: [{
        type: 'session_version',
        expected: input.expected_session_version,
        actual: session.version,
        resolution: 'reload with start_coach or retry with the current version',
      }],
    };
  }

  state.exec('BEGIN IMMEDIATE');
  try {
    if (input.onboarding) {
      applyOnboarding(state, input.onboarding, nowIso);
      changed.onboarding = input.onboarding.status;
    }

    for (const m of input.memories ?? []) {
      if (m.sensitive && !m.confirmed) {
        conflicts.push({ type: 'sensitive_requires_confirmation', id: m.id, subject: m.subject });
        continue;
      }
      applyStatusRow(state, 'memories', m, nowIso, conflicts, changed.memories, {
        insert: () => state.prepare(`
          INSERT INTO memories (id, type, subject, content, status, effective_at, source_ids_json, confirmed, sensitive, supersedes_id, created_at, updated_at)
          VALUES (?, ?, ?, ?, 'active', ?, ?, ?, ?, ?, ?, ?)
        `).run(m.id, m.type, m.subject, m.content, m.effective_at ?? null, json(m.source_ids), m.confirmed ? 1 : 0, m.sensitive ? 1 : 0, m.supersedes_id ?? null, nowIso, nowIso),
        update: () => state.prepare(`
          UPDATE memories SET type = ?, subject = ?, content = ?, effective_at = ?, source_ids_json = ?, confirmed = ?, sensitive = ?, updated_at = ?
          WHERE id = ?
        `).run(m.type, m.subject, m.content, m.effective_at ?? null, json(m.source_ids), m.confirmed ? 1 : 0, m.sensitive ? 1 : 0, nowIso, m.id),
      });
    }

    for (const m of input.metrics ?? []) {
      // One active value per (name, scope): a new value automatically supersedes an older
      // active row for the same metric even when the model omits the explicit supersede.
      if (m.action === 'upsert' && !m.supersedes_id) {
        const prior = state.prepare(
          `SELECT id FROM metrics WHERE status = 'active' AND id != ? AND LOWER(name) = LOWER(?) AND LOWER(scope) = LOWER(?) AND as_of < ?`
        ).get(m.id, m.name, m.scope, m.as_of);
        if (prior) {
          state.prepare(`UPDATE metrics SET status = 'superseded', updated_at = ? WHERE id = ?`).run(nowIso, prior.id);
        }
      }
      applyStatusRow(state, 'metrics', m, nowIso, conflicts, changed.metrics, {
        insert: () => state.prepare(`
          INSERT INTO metrics (id, name, value_text, unit, definition, scope, as_of, staleness_class, status, supersedes_id, source_ids_json, created_at, updated_at)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'active', ?, ?, ?, ?)
        `).run(m.id, m.name, m.value_text, m.unit ?? null, m.definition ?? null, m.scope, m.as_of, m.staleness_class, m.supersedes_id ?? null, json(m.source_ids), nowIso, nowIso),
        update: () => state.prepare(`
          UPDATE metrics SET name = ?, value_text = ?, unit = ?, definition = ?, scope = ?, as_of = ?, staleness_class = ?, source_ids_json = ?, updated_at = ?
          WHERE id = ?
        `).run(m.name, m.value_text, m.unit ?? null, m.definition ?? null, m.scope, m.as_of, m.staleness_class, json(m.source_ids), nowIso, m.id),
      });
    }

    for (const d of input.decisions ?? []) {
      const existing = state.prepare(`SELECT id FROM decisions WHERE id = ?`).get(d.id);
      if (d.action === 'upsert') {
        if (existing) {
          state.prepare(`UPDATE decisions SET decision = ?, reason = ?, made_at = ?, outcome = ?, source_ids_json = ?, updated_at = ? WHERE id = ?`)
            .run(d.decision, d.reason ?? null, d.made_at, d.outcome ?? null, json(d.source_ids), nowIso, d.id);
        } else {
          state.prepare(`INSERT INTO decisions (id, decision, reason, made_at, status, outcome, source_ids_json, created_at, updated_at) VALUES (?, ?, ?, ?, 'active', ?, ?, ?, ?)`)
            .run(d.id, d.decision, d.reason ?? null, d.made_at, d.outcome ?? null, json(d.source_ids), nowIso, nowIso);
        }
        changed.decisions.push(d.id);
      } else if (!existing) {
        conflicts.push({ type: 'unknown_id', table: 'decisions', id: d.id });
      } else {
        const status = { revisit: 'revisited', reverse: 'reversed', complete: 'complete' }[d.action];
        state.prepare(`UPDATE decisions SET status = ?, outcome = COALESCE(?, outcome), updated_at = ? WHERE id = ?`)
          .run(status, d.outcome ?? null, nowIso, d.id);
        changed.decisions.push(d.id);
      }
    }

    for (const c of input.commitments ?? []) {
      applyCommitment(state, c, nowIso, conflicts, changed.commitments);
    }

    for (const p of input.people ?? []) {
      const existing = state.prepare(`SELECT id FROM people WHERE id = ?`).get(p.id);
      if (p.action === 'withdraw') {
        if (!existing) { conflicts.push({ type: 'unknown_id', table: 'people', id: p.id }); continue; }
        state.prepare(`DELETE FROM people WHERE id = ?`).run(p.id);
        changed.people.push(p.id);
        continue;
      }
      if (existing) {
        state.prepare(`UPDATE people SET name = ?, role = ?, strengths_json = ?, focus_areas_json = ?, working_model = ?, confirmed = ?, source_ids_json = ?, updated_at = ? WHERE id = ?`)
          .run(p.name, p.role ?? null, json(p.strengths), json(p.focus_areas), p.working_model ?? null, p.confirmed ? 1 : 0, json(p.source_ids), nowIso, p.id);
      } else {
        state.prepare(`INSERT INTO people (id, name, role, strengths_json, focus_areas_json, working_model, confirmed, source_ids_json, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
          .run(p.id, p.name, p.role ?? null, json(p.strengths), json(p.focus_areas), p.working_model ?? null, p.confirmed ? 1 : 0, json(p.source_ids), nowIso, nowIso);
      }
      changed.people.push(p.id);
    }

    for (const l of input.learnings ?? []) {
      const lid = `learning-${randomUUID().slice(0, 8)}`;
      state.prepare(`
        INSERT INTO learnings (id, category, learning, evidence, source_kind, source_id, fed_into_json, occurred_at, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(lid, l.category, l.learning, l.evidence ?? null, l.source_kind, l.source_id ?? null,
        JSON.stringify(l.fed_into ?? []), nowIso, nowIso);
      refreshFts(state, 'learnings', lid);
      (changed.learnings ??= []).push(lid);
    }

    for (const v of input.voice_deltas ?? []) {
      const vid = `voice-${randomUUID().slice(0, 8)}`;
      state.prepare(`
        INSERT INTO voice_deltas (id, feature, rule, example, origin, status, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, 'active', ?, ?)
      `).run(vid, v.feature, v.rule, v.example ?? null, v.origin, nowIso, nowIso);
      refreshFts(state, 'voice_deltas', vid);
      (changed.voice_deltas ??= []).push(vid);
    }

    for (const r of input.interaction_reviews ?? []) {
      const existing = state.prepare('SELECT id FROM interactions WHERE id = ?').get(r.interaction_id);
      if (!existing) { conflicts.push({ type: 'interaction', id: r.interaction_id, reason: 'unknown interaction' }); continue; }
      state.prepare('UPDATE interactions SET review_json = ?, updated_at = ? WHERE id = ?')
        .run(JSON.stringify(r.review ?? {}), nowIso, r.interaction_id);
      refreshFts(state, 'interactions', r.interaction_id);
      (changed.interaction_reviews ??= []).push(r.interaction_id);
    }

    const s = input.session;
    const newVersion = session.version + 1;
    state.prepare(`
      UPDATE sessions SET status = ?, situation = COALESCE(?, situation), judgment = COALESCE(?, judgment),
        evidence_ids_json = ?, open_questions_json = ?, next_move = COALESCE(?, next_move),
        closed_at = CASE WHEN ? IN ('closed','abandoned') THEN ? ELSE closed_at END,
        updated_at = ?, version = ?
      WHERE id = ? AND version = ?
    `).run(s.status, s.situation ?? null, s.judgment ?? null, json(s.evidence_ids), json(s.open_questions),
      s.next_move ?? null, s.status, nowIso, nowIso, newVersion, session.id, session.version);
    changed.session = s.status;

    state.exec('COMMIT');
    return {
      session_id: session.id,
      session_version: newVersion,
      changed: Object.fromEntries(Object.entries(changed).map(([k, v]) =>
        Array.isArray(v) ? [k, { count: v.length, ids: v }] : [k, v])),
      conflicts,
    };
  } catch (err) {
    state.exec('ROLLBACK');
    throw err;
  }
}

// Shared upsert/supersede/withdraw for memories and metrics (status-tracked tables).
function applyStatusRow(state, table, item, nowIso, conflicts, changedIds, ops) {
  const existing = state.prepare(`SELECT id, status FROM ${table} WHERE id = ?`).get(item.id);
  if (item.action === 'upsert') {
    existing ? ops.update() : ops.insert();
    changedIds.push(item.id);
    return;
  }
  if (item.action === 'supersede') {
    const priorId = item.supersedes_id;
    if (!priorId) { conflicts.push({ type: 'supersede_requires_supersedes_id', table, id: item.id }); return; }
    const prior = state.prepare(`SELECT id FROM ${table} WHERE id = ?`).get(priorId);
    if (!prior) { conflicts.push({ type: 'unknown_id', table, id: priorId }); return; }
    if (existing) { conflicts.push({ type: 'id_already_exists', table, id: item.id }); return; }
    ops.insert();
    state.prepare(`UPDATE ${table} SET status = 'superseded', updated_at = ? WHERE id = ?`).run(nowIso, priorId);
    changedIds.push(item.id);
    return;
  }
  if (item.action === 'withdraw') {
    if (!existing) { conflicts.push({ type: 'unknown_id', table, id: item.id }); return; }
    state.prepare(`UPDATE ${table} SET status = 'withdrawn', updated_at = ? WHERE id = ?`).run(nowIso, item.id);
    changedIds.push(item.id);
  }
}

export function applyCommitment(state, c, nowIso, conflicts, changedIds) {
  const existing = state.prepare(`SELECT id, status FROM commitments WHERE id = ?`).get(c.id);
  if (c.action === 'upsert' || c.action === undefined) {
    if (existing) {
      state.prepare(`UPDATE commitments SET owner = ?, commitment = ?, due_at = ?, next_review_at = ?, source_ids_json = ?, updated_at = ? WHERE id = ?`)
        .run(c.owner, c.commitment, c.due_at ?? null, c.next_review_at ?? null, json(c.source_ids), nowIso, c.id);
    } else {
      state.prepare(`INSERT INTO commitments (id, owner, commitment, due_at, status, outcome, next_review_at, source_ids_json, created_at, updated_at) VALUES (?, ?, ?, ?, 'open', ?, ?, ?, ?, ?)`)
        .run(c.id, c.owner, c.commitment, c.due_at ?? null, c.outcome ?? null, c.next_review_at ?? null, json(c.source_ids), nowIso, nowIso);
    }
    changedIds.push(c.id);
    return;
  }
  if (!existing) { conflicts.push({ type: 'unknown_id', table: 'commitments', id: c.id }); return; }
  if (c.action === 'change') {
    state.prepare(`UPDATE commitments SET owner = ?, commitment = ?, due_at = ?, next_review_at = ?, outcome = COALESCE(?, outcome), source_ids_json = ?, updated_at = ? WHERE id = ?`)
      .run(c.owner, c.commitment, c.due_at ?? null, c.next_review_at ?? null, c.outcome ?? null, json(c.source_ids), nowIso, c.id);
  } else {
    const status = { complete: 'done', drop: 'dropped' }[c.action];
    state.prepare(`UPDATE commitments SET status = ?, outcome = COALESCE(?, outcome), updated_at = ? WHERE id = ?`)
      .run(status, c.outcome ?? null, nowIso, c.id);
  }
  changedIds.push(c.id);
}

export function inspectMemory(state, input, nowMs = Date.now()) {
  const { query, types, status = 'active', limit = 25 } = input;
  const like = query ? `%${query.replace(/[%_]/g, (ch) => '\\' + ch)}%` : null;

  const statusFilter = (col = 'status') => status === 'all' ? '1=1' : `${col} = '${status}'`;
  const typeFilter = types?.length ? `AND type IN (${types.map(() => '?').join(',')})` : '';

  const memories = state.prepare(`
    SELECT id, type, subject, content, status, effective_at, confirmed, sensitive, supersedes_id, updated_at
    FROM memories WHERE ${statusFilter()} ${typeFilter}
    ${like ? 'AND (subject LIKE ? ESCAPE \'\\\' OR content LIKE ? ESCAPE \'\\\')' : ''}
    ORDER BY updated_at DESC LIMIT ?
  `).all(...(types ?? []), ...(like ? [like, like] : []), limit);

  const metrics = state.prepare(`
    SELECT id, name, value_text, unit, definition, scope, as_of, staleness_class, status, supersedes_id
    FROM metrics WHERE ${statusFilter()}
    ${like ? 'AND (name LIKE ? ESCAPE \'\\\' OR definition LIKE ? ESCAPE \'\\\' OR scope LIKE ? ESCAPE \'\\\')' : ''}
    ORDER BY as_of DESC LIMIT ?
  `).all(...(like ? [like, like, like] : []), limit).map((m) => ({ ...m, stale: computeStaleness(m, nowMs) }));

  const decisions = state.prepare(`
    SELECT id, decision, reason, made_at, status, outcome FROM decisions
    WHERE ${status === 'all' ? '1=1' : status === 'active' ? `status = 'active'` : `status != 'active'`}
    ${like ? 'AND (decision LIKE ? ESCAPE \'\\\' OR reason LIKE ? ESCAPE \'\\\')' : ''}
    ORDER BY made_at DESC LIMIT ?
  `).all(...(like ? [like, like] : []), limit);

  const commitments = state.prepare(`
    SELECT id, owner, commitment, due_at, status, outcome, next_review_at FROM commitments
    WHERE ${status === 'all' ? '1=1' : `status = 'open'`}
    ${like ? 'AND (owner LIKE ? ESCAPE \'\\\' OR commitment LIKE ? ESCAPE \'\\\')' : ''}
    ORDER BY due_at IS NULL, due_at LIMIT ?
  `).all(...(like ? [like, like] : []), limit);

  const people = state.prepare(`
    SELECT id, name, role, strengths_json, focus_areas_json, working_model, confirmed FROM people
    ${like ? 'WHERE (name LIKE ? ESCAPE \'\\\' OR role LIKE ? ESCAPE \'\\\' OR working_model LIKE ? ESCAPE \'\\\')' : ''}
    ORDER BY name LIMIT ?
  `).all(...(like ? [like, like, like] : []), limit).map((p) => ({
    ...p,
    strengths: JSON.parse(p.strengths_json), focus_areas: JSON.parse(p.focus_areas_json),
    strengths_json: undefined, focus_areas_json: undefined,
  }));

  return { memories, metrics, decisions, commitments, people };
}
