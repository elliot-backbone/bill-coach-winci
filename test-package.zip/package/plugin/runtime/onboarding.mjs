// Onboarding singleton: one coherent first exchange, checkpointed invisibly.

export function getOnboarding(state) {
  const row = state.prepare(
    `SELECT status, presented_at, draft_picture, corrections, confirmed_picture, confirmed_at FROM onboarding WHERE singleton = 1`
  ).get();
  return row ?? { status: 'not_started' };
}

// Runs inside the save_coaching_state transaction.
export function applyOnboarding(state, ob, nowIso) {
  const current = getOnboarding(state);
  if (current.status === 'complete' && ob.status !== 'complete') {
    // Onboarding never regresses; a revisit of the working agreement is ordinary memory.
    return;
  }
  state.prepare(`
    UPDATE onboarding SET
      status = ?,
      presented_at = CASE WHEN ? LIKE 'pane#_%' ESCAPE '#' AND presented_at IS NULL THEN ? ELSE presented_at END,
      draft_picture = COALESCE(?, draft_picture),
      corrections = COALESCE(?, corrections),
      confirmed_picture = COALESCE(?, confirmed_picture),
      confirmed_at = CASE WHEN ? = 'complete' THEN COALESCE(?, ?) ELSE confirmed_at END,
      updated_at = ?
    WHERE singleton = 1
  `).run(
    ob.status, ob.status, nowIso,
    ob.draft_picture ?? null, ob.corrections ?? null, ob.confirmed_picture ?? null,
    ob.status, ob.confirmed_at ?? null, nowIso, nowIso,
  );
}
