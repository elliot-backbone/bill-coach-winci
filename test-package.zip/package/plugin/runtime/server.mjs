#!/usr/bin/env node
// bill-coach MCP server: newline-delimited JSON-RPC 2.0 on stdio, seven tools,
// zero dependencies. stdout is protocol-only; diagnostics go to stderr and never
// contain source bodies or credentials.

import { createInterface } from 'node:readline';
import { DatabaseSync } from 'node:sqlite';
import { join } from 'node:path';
import { existsSync } from 'node:fs';

import { searchLibrary } from './library.mjs';
import { getContext } from './context.mjs';
import { saveCoachingState, inspectMemory } from './memory.mjs';
import { syncSource } from './sources.mjs';
import { startCoach, endCoach } from './lifecycle.mjs';
import { searchState, updateState } from './statesearch.mjs';
import { transitionPhase, createRole, touchRole } from './funnel.mjs';

const SERVER = { name: 'bill-coach', version: '1.2.6' };
const PROTOCOL_VERSIONS = ['2025-06-18', '2025-03-26', '2024-11-05'];

// --- databases -------------------------------------------------------------

const dataDir = process.env.BILL_COACH_DATA_DIR;
if (!dataDir) { console.error('BILL_COACH_DATA_DIR is not set'); process.exit(1); }
const libraryPath = join(dataDir, 'library', 'library.sqlite');
const statePath = join(dataDir, 'state', 'coach.sqlite');
for (const p of [libraryPath, statePath]) {
  if (!existsSync(p)) { console.error(`database missing: ${p}`); process.exit(1); }
}

// Opening is the most lock-prone moment in this process's life: a second coach
// window, or Claude Code restarting this server while the previous one is still
// exiting, contends for the same file. busy_timeout MUST be set before any
// statement that takes a lock — with it set afterwards, `PRAGMA journal_mode`
// failed instantly with "database is locked" and the second window died at boot.
const BUSY_TIMEOUT_MS = 10_000;

function openDb(dbPath, label) {
  try {
    const db = new DatabaseSync(dbPath);
    db.exec(`PRAGMA busy_timeout = ${BUSY_TIMEOUT_MS}`);
    // Every shipped database is already in WAL mode, so this is a confirmation
    // rather than a change. A concurrent reader can still block the mode switch,
    // and dying for a no-op would be the worst possible trade.
    try {
      db.exec('PRAGMA journal_mode = WAL');
    } catch (err) {
      console.error(`[${label}] could not confirm WAL mode (continuing): ${err.message}`);
    }
    db.exec('PRAGMA foreign_keys = ON');
    return db;
  } catch (err) {
    console.error(`cannot open the ${label} database at ${dbPath}: ${err.message}`);
    process.exit(1);
  }
}

const library = openDb(libraryPath, 'library');
const state = openDb(statePath, 'state');

// --- minimal JSON Schema validation (the subset the tool contracts use) ----

function validate(schema, value, path = 'input') {
  const errors = [];
  check(schema, value, path, errors);
  return errors;
}

function typeOf(v) {
  if (v === null) return 'null';
  if (Array.isArray(v)) return 'array';
  if (Number.isInteger(v)) return 'integer';
  return typeof v;
}

function check(schema, value, path, errors) {
  if (!schema) return;
  if (schema.const !== undefined && value !== schema.const) {
    errors.push(`${path} must be ${JSON.stringify(schema.const)}`); return;
  }
  if (schema.enum && !schema.enum.includes(value)) {
    errors.push(`${path} must be one of ${schema.enum.join(', ')}`); return;
  }
  const types = schema.type ? [schema.type].flat() : null;
  if (types) {
    const t = typeOf(value);
    const ok = types.some((want) => want === t || (want === 'number' && t === 'integer') || (want === 'integer' && t === 'integer'));
    if (!ok) { errors.push(`${path} must be ${types.join('|')}, got ${t}`); return; }
  }
  if (typeOf(value) === 'string') {
    if (schema.minLength !== undefined && value.length < schema.minLength) errors.push(`${path} is too short`);
    if (schema.maxLength !== undefined && value.length > schema.maxLength) errors.push(`${path} exceeds ${schema.maxLength} characters`);
  }
  if (typeOf(value) === 'integer' || typeof value === 'number') {
    if (schema.minimum !== undefined && value < schema.minimum) errors.push(`${path} must be >= ${schema.minimum}`);
    if (schema.maximum !== undefined && value > schema.maximum) errors.push(`${path} must be <= ${schema.maximum}`);
  }
  if (Array.isArray(value)) {
    if (schema.maxItems !== undefined && value.length > schema.maxItems) errors.push(`${path} exceeds ${schema.maxItems} items`);
    if (schema.items) value.forEach((v, i) => check(schema.items, v, `${path}[${i}]`, errors));
  }
  if (typeOf(value) === 'object' && schema.properties) {
    for (const key of schema.required ?? []) {
      if (value[key] === undefined) errors.push(`${path}.${key} is required`);
    }
    for (const [key, v] of Object.entries(value)) {
      if (schema.properties[key]) check(schema.properties[key], v, `${path}.${key}`, errors);
      else if (schema.additionalProperties === false) errors.push(`${path}.${key} is not a recognized field`);
    }
  }
}

// --- tool registry ---------------------------------------------------------

const str = (min, max) => ({ type: 'string', minLength: min, maxLength: max });
const idArray = { type: 'array', items: { type: 'string' }, maxItems: 50 };

const SESSION_FIELDS = {
  status: { type: 'string', enum: ['active', 'closed', 'abandoned'] },
  situation: { type: ['string', 'null'], maxLength: 20000 },
  judgment: { type: ['string', 'null'], maxLength: 20000 },
  evidence_ids: { type: 'array', items: { type: 'string' }, maxItems: 100 },
  open_questions: { type: 'array', items: { type: 'string' }, maxItems: 30 },
  next_move: { type: ['string', 'null'], maxLength: 10000 },
};

const TOOLS = [
  {
    name: 'start_coach',
    description: 'Open or resume the coaching session and return the smallest complete orientation context. Call this first in every conversation.',
    inputSchema: {
      type: 'object', additionalProperties: false,
      properties: { user_message: str(1, 30000), now: { type: 'string' } },
      required: ['user_message'],
    },
    handler: (args) => startCoach(state, library, args),
  },
  {
    name: 'get_context',
    description: 'Assemble evidence and memory for one active coaching question using time, entity, topic and lens signals. Evidence includes conflicting and freshest-per-entity sources; never cite a fact the evidence does not carry.',
    inputSchema: {
      type: 'object', additionalProperties: false,
      properties: {
        session_id: str(1), question: str(1, 10000),
        entities: { type: 'array', items: { type: 'string' }, maxItems: 20 },
        lens: { type: 'string', enum: ['strategy', 'product', 'commercial', 'gtm', 'investor', 'organization', 'partnership', 'relationship', 'mixed'] },
        as_of: { type: 'string' },
        max_chunks: { type: 'integer', minimum: 4, maximum: 40 },
      },
      required: ['session_id', 'question'],
    },
    handler: (args) => getContext(state, library, args),
  },
  {
    name: 'search_library',
    description: 'Search the complete local source and doctrine library. Query "doc:<document_id>" (optionally "doc:<id>#<sequence>") returns a full document in ordered parts for continuation-based review.',
    inputSchema: {
      type: 'object', additionalProperties: false,
      properties: {
        query: str(1, 2000),
        kinds: { type: 'array', items: { type: 'string' }, maxItems: 12 },
        entities: { type: 'array', items: { type: 'string' }, maxItems: 20 },
        topics: { type: 'array', items: { type: 'string' }, maxItems: 20 },
        occurred_after: { type: 'string' }, occurred_before: { type: 'string' },
        limit: { type: 'integer', minimum: 1, maximum: 50 },
        include_document_text: { type: 'boolean' },
      },
      required: ['query'],
    },
    handler: (args) => searchLibrary(library, args),
  },
  {
    name: 'save_coaching_state',
    description: 'Persist the meaningful outcome of a coaching exchange in one transaction. Call at most once per exchange, only when something material changed. learnings writes the learning ledger — required at the close of every unit of work, and required before a role can be exited.',
    inputSchema: {
      type: 'object', additionalProperties: false,
      properties: {
        session_id: str(1),
        expected_session_version: { type: 'integer', minimum: 1 },
        onboarding: {
          type: ['object', 'null'], additionalProperties: false,
          properties: {
            status: { type: 'string', enum: ['pane_1', 'pane_2', 'pane_3', 'pane_4', 'pane_5', 'pane_6', 'pane_7', 'complete'] },
            draft_picture: { type: 'string', maxLength: 30000 },
            corrections: { type: 'string', maxLength: 30000 },
            confirmed_picture: { type: 'string', maxLength: 30000 },
            confirmed_at: { type: 'string' },
          },
          required: ['status'],
        },
        session: { type: 'object', additionalProperties: false, properties: SESSION_FIELDS, required: ['status', 'evidence_ids', 'open_questions'] },
        voice_deltas: {
          type: 'array', maxItems: 20,
          items: {
            type: 'object', additionalProperties: false,
            properties: {
              id: str(1),
              feature: str(1, 200),
              rule: str(1, 2000),
              example: { type: ['string', 'null'], maxLength: 2000 },
              origin: { type: 'string', enum: ['chat-mining', 'onboarding-sample', 'draft-correction', 'session'] },
              status: { type: 'string', enum: ['active', 'retired'] },
            },
            required: ['id', 'feature', 'rule'],
          },
        },
        interaction_reviews: {
          type: 'array', maxItems: 20,
          items: {
            type: 'object', additionalProperties: false,
            properties: {
              id: str(1),
              interaction_id: { type: ['string', 'null'], maxLength: 200 },
              did_well: { type: ['string', 'null'], maxLength: 4000 },
              focus_next: str(1, 4000),
              fed_into: { type: 'array', items: { type: 'string' }, maxItems: 20 },
              occurred_at: { type: 'string' },
            },
            required: ['id', 'focus_next'],
          },
        },
        learnings: {
          type: 'array', maxItems: 20,
          items: {
            type: 'object', additionalProperties: false,
            properties: {
              id: str(1),
              category: { type: 'string', enum: ['market', 'positioning', 'want', 'performance', 'narrative', 'process'] },
              learning: str(1, 4000),
              evidence: { type: ['string', 'null'], maxLength: 4000 },
              source_kind: { type: 'string', maxLength: 60 },
              source_id: { type: ['string', 'null'], maxLength: 200 },
              fed_into: { type: 'array', items: { type: 'string' }, maxItems: 20 },
              occurred_at: { type: 'string' },
            },
            required: ['id', 'category', 'learning'],
          },
        },
        memories: {
          type: 'array', maxItems: 20,
          items: {
            type: 'object', additionalProperties: false,
            properties: {
              action: { type: 'string', enum: ['upsert', 'supersede', 'withdraw'] },
              id: str(1),
              type: { type: 'string', enum: ['company', 'person', 'pattern', 'preference', 'constraint', 'hypothesis', 'context'] },
              subject: str(1, 500), content: str(1, 10000),
              effective_at: { type: ['string', 'null'] },
              source_ids: idArray, confirmed: { type: 'boolean' }, sensitive: { type: 'boolean' },
              supersedes_id: { type: ['string', 'null'] },
            },
            required: ['action', 'id', 'type', 'subject', 'content', 'source_ids', 'confirmed', 'sensitive'],
          },
        },
        metrics: {
          type: 'array', maxItems: 20,
          items: {
            type: 'object', additionalProperties: false,
            properties: {
              action: { type: 'string', enum: ['upsert', 'supersede', 'withdraw'] },
              id: str(1), name: str(1, 300), value_text: str(1, 1000),
              unit: { type: ['string', 'null'], maxLength: 100 },
              definition: { type: ['string', 'null'], maxLength: 2000 },
              scope: str(1, 500), as_of: { type: 'string' },
              staleness_class: { type: 'string', enum: ['fast', 'normal', 'slow', 'static'] },
              source_ids: idArray, supersedes_id: { type: ['string', 'null'] },
            },
            required: ['action', 'id', 'name', 'value_text', 'scope', 'as_of', 'staleness_class', 'source_ids'],
          },
        },
        decisions: {
          type: 'array', maxItems: 20,
          items: {
            type: 'object', additionalProperties: false,
            properties: {
              action: { type: 'string', enum: ['upsert', 'revisit', 'reverse', 'complete'] },
              id: str(1), decision: str(1, 10000),
              reason: { type: ['string', 'null'], maxLength: 10000 },
              made_at: { type: 'string' },
              outcome: { type: ['string', 'null'], maxLength: 10000 },
              source_ids: idArray,
            },
            required: ['action', 'id', 'decision', 'made_at', 'source_ids'],
          },
        },
        commitments: {
          type: 'array', maxItems: 20,
          items: {
            type: 'object', additionalProperties: false,
            properties: {
              action: { type: 'string', enum: ['upsert', 'complete', 'drop', 'change'] },
              id: str(1), owner: str(1, 300), commitment: str(1, 10000),
              due_at: { type: ['string', 'null'] },
              outcome: { type: ['string', 'null'], maxLength: 10000 },
              next_review_at: { type: ['string', 'null'] },
              source_ids: idArray,
            },
            required: ['action', 'id', 'owner', 'commitment', 'source_ids'],
          },
        },
        people: {
          type: 'array', maxItems: 20,
          items: {
            type: 'object', additionalProperties: false,
            properties: {
              action: { type: 'string', enum: ['upsert', 'withdraw'] },
              id: str(1), name: str(1, 300),
              role: { type: ['string', 'null'], maxLength: 500 },
              strengths: { type: 'array', items: { type: 'string' }, maxItems: 20 },
              focus_areas: { type: 'array', items: { type: 'string' }, maxItems: 20 },
              working_model: { type: ['string', 'null'], maxLength: 10000 },
              confirmed: { type: 'boolean' }, source_ids: idArray,
            },
            required: ['action', 'id', 'name', 'strengths', 'focus_areas', 'confirmed', 'source_ids'],
          },
        },
      },
        learnings: {
          type: 'array', maxItems: 20,
          items: {
            type: 'object', additionalProperties: false,
            properties: {
              category: { type: 'string', enum: ['market', 'positioning', 'want', 'performance', 'narrative', 'process'] },
              learning: str(1, 4000), evidence: { type: ['string', 'null'] },
              source_kind: str(1, 60), source_id: { type: ['string', 'null'] },
              fed_into: { type: 'array', maxItems: 6, items: { type: 'string' } },
            },
            required: ['category', 'learning', 'source_kind'],
          },
        },
        voice_deltas: {
          type: 'array', maxItems: 10,
          items: {
            type: 'object', additionalProperties: false,
            properties: {
              feature: str(1, 60), rule: str(1, 2000), example: { type: ['string', 'null'] },
              origin: { type: 'string', enum: ['chat-mining', 'onboarding-sample', 'draft-correction', 'session'] },
            },
            required: ['feature', 'rule', 'origin'],
          },
        },
        interaction_reviews: {
          type: 'array', maxItems: 10,
          items: {
            type: 'object', additionalProperties: false,
            properties: { interaction_id: str(1), review: { type: 'object' } },
            required: ['interaction_id', 'review'],
          },
        },
      required: ['session_id', 'expected_session_version', 'session'],
    },
    handler: (args) => saveCoachingState(state, args),
  },
  {
    name: 'inspect_memory',
    description: 'Retrieve or review durable coach memory when Bill asks what is remembered or wants something changed. Corrections themselves go through save_coaching_state.',
    inputSchema: {
      type: 'object', additionalProperties: false,
      properties: {
        query: { type: 'string', maxLength: 2000 },
        types: { type: 'array', items: { type: 'string' }, maxItems: 8 },
        status: { type: 'string', enum: ['active', 'superseded', 'withdrawn', 'all'] },
        limit: { type: 'integer', minimum: 1, maximum: 100 },
      },
    },
    handler: (args) => inspectMemory(state, args),
  },
  {
    name: 'sync_source',
    description: 'Import current information from an already configured read-only source after explicit approval in this conversation. Append-only; never edits or deletes an existing source.',
    inputSchema: {
      type: 'object', additionalProperties: false,
      properties: {
        source_id: str(1),
        scope: { type: 'object' },
        approved: { const: true },
        reason: str(1, 1000),
      },
      required: ['source_id', 'approved', 'reason'],
    },
    handler: (args) => syncSource(state, library, args),
  },
  {
    name: 'end_coach',
    description: 'Close the active episode with the judgment, commitments and next review point preserved.',
    inputSchema: {
      type: 'object', additionalProperties: false,
      properties: {
        session_id: str(1),
        expected_session_version: { type: 'integer', minimum: 1 },
        judgment: str(1, 10000),
        next_move: str(1, 5000),
        commitments: {
          type: 'array', maxItems: 10,
          items: {
            type: 'object', additionalProperties: false,
            properties: {
              id: str(1), owner: str(1, 300), commitment: str(1, 10000),
              due_at: { type: ['string', 'null'] }, next_review_at: { type: ['string', 'null'] },
              source_ids: idArray,
            },
            required: ['id', 'owner', 'commitment', 'source_ids'],
          },
        },
        next_review_at: { type: ['string', 'null'] },
      },
      required: ['session_id', 'expected_session_version', 'judgment', 'next_move'],
    },
    handler: (args) => endCoach(state, args),
  },
  {
    name: 'search_state',
    description: 'One search across ALL durable state (funnel roles, interactions, offers, contacts, learnings, voice deltas, investor roster, sourcing runs, memories, metrics, commitments) and the market_deals baseline. Use before updating anything.',
    inputSchema: {
      type: 'object', additionalProperties: false,
      properties: {
        query: str(1, 500),
        tables: { type: 'array', maxItems: 12, items: { type: 'string' } },
        filters: {
          type: 'object', additionalProperties: false,
          properties: {
            phase: { type: 'string' }, lane: { type: 'string' }, mode: { type: 'string' },
            relationship: { type: 'string' }, category: { type: 'string' },
            due_before: { type: 'string' }, updated_since: { type: 'string' },
          },
        },
        limit: { type: 'integer', minimum: 1, maximum: 50 },
      },
      required: ['query'],
    },
    handler: (args) => searchState(state, library, { ...args, limit: args.limit ?? 20 }),
  },
  {
    name: 'update_state',
    description: 'Audited field-level write to funnel state (roles, interactions, offers, contacts, investor_roster, sourcing_runs). target "<table>:<id>" from search_state, or "<table>:new" to create. Creating a role requires company, lane (core-ft | fractional | us-remote | other) and source; a create that is missing a required field returns the field names and their allowed values. Facts update freely with provenance; fields carrying Bill\'s judgment require provenance beginning "bill-said". Special actions: fields.action = "transition" (with to_phase) routes phase moves through the evidence guards; "touch" records a touchpoint.',
    inputSchema: {
      type: 'object', additionalProperties: false,
      properties: {
        target: str(3, 200),
        fields: { type: 'object' },
        provenance: str(3, 500),
        as_of: { type: 'string' },
        session_id: str(1),
        autonomous: { type: 'boolean' },
      },
      required: ['target', 'fields', 'provenance', 'session_id'],
    },
    handler: (args) => {
      const { target, fields, provenance, session_id, autonomous } = args;
      if (fields && fields.action === 'transition') {
        const roleId = target.split(':').slice(1).join(':');
        const { to_phase, ...extras } = fields;
        delete extras.action;
        return transitionPhase(state, roleId, to_phase, provenance, session_id, extras);
      }
      if (fields && fields.action === 'touch') {
        const roleId = target.split(':').slice(1).join(':');
        return touchRole(state, roleId, fields.note ?? null, provenance, session_id);
      }
      // Both spellings reach the validated creator: the documented `roles:new` and the
      // action form. Before 1.2.5 only the action form did, so following the tool's own
      // description produced a raw insert and a NOT NULL constraint failure.
      if ((fields && fields.action === 'create_role') || target === 'roles:new') {
        const input = { ...fields, provenance, autonomous };
        delete input.action;
        if (args.as_of && !input.as_of) input.as_of = args.as_of;
        return createRole(state, input, session_id);
      }
      return updateState(state, args);
    },
  },
  // ---- HARDCODED BILL COMMANDS ----
  // Deterministic handlers: each executes a fixed tool sequence, returning structured
  // results. The model presents the output; the data assembly is code, not prompt.
  {
    name: 'bill_command',
    description: 'Execute a hardcoded Bill command. Commands: memory (full data dump), pipeline (funnel export), sources (provenance for a claim), changes (session changelog), recall (everything on a topic), correct (override a record), forget (delete a record). These are deterministic — same command always produces the same query sequence.',
    inputSchema: {
      type: 'object', additionalProperties: false,
      properties: {
        command: { type: 'string', enum: ['memory', 'pipeline', 'sources', 'changes', 'recall', 'correct', 'forget'] },
        session_id: str(1),
        subject: { type: 'string', maxLength: 2000, description: 'For recall/sources/correct/forget: the topic, claim, or record in question' },
        correction: { type: 'object', description: 'For correct: { target, fields, provenance }' },
      },
      required: ['command', 'session_id'],
    },
    handler: (args) => {
      const { command, session_id, subject } = args;
      const result = {};

      if (command === 'memory') {
        // Full transparency dump: every store, every namespace, nothing hidden
        result.memories = inspectMemory(state, { status: 'all', limit: 100 });
        const allTables = ['roles', 'interactions', 'offers', 'contacts', 'learnings', 'voice_deltas', 'investor_roster', 'sourcing_runs'];
        result.state = {};
        for (const tbl of allTables) {
          try { result.state[tbl] = state.prepare(`SELECT * FROM ${tbl} ORDER BY rowid DESC LIMIT 100`).all(); } catch { result.state[tbl] = []; }
        }
        result.commitments = state.prepare('SELECT * FROM commitments WHERE status = \'active\' ORDER BY due_at').all();
        result.settings = state.prepare('SELECT key, value_json FROM settings').all();
        result.library_docs = library.prepare('SELECT id, title, kind FROM documents ORDER BY title').all();
        result.command = 'memory';
        return result;
      }

      if (command === 'pipeline') {
        result.roles = state.prepare('SELECT * FROM roles ORDER BY phase, updated_at DESC').all();
        result.recent_events = state.prepare('SELECT * FROM role_events ORDER BY occurred_at DESC LIMIT 50').all();
        result.active_interactions = state.prepare('SELECT * FROM interactions ORDER BY occurred_at DESC LIMIT 30').all();
        result.offers = state.prepare('SELECT * FROM offers ORDER BY created_at DESC').all();
        result.contacts = state.prepare('SELECT * FROM contacts ORDER BY updated_at DESC LIMIT 50').all();
        result.command = 'pipeline';
        return result;
      }

      if (command === 'sources' && subject) {
        // Find every record mentioning the subject with its provenance
        result.memories = inspectMemory(state, { query: subject, status: 'all', limit: 20 });
        result.role_events = state.prepare(
          `SELECT * FROM role_events WHERE lower(provenance) LIKE ? OR lower(new_value) LIKE ? ORDER BY occurred_at DESC LIMIT 20`
        ).all(`%${subject.toLowerCase()}%`, `%${subject.toLowerCase()}%`);
        result.sourcing_runs = state.prepare(
          `SELECT * FROM sourcing_runs WHERE lower(scope) LIKE ? OR lower(notes) LIKE ? ORDER BY started_at DESC LIMIT 10`
        ).all(`%${subject.toLowerCase()}%`, `%${subject.toLowerCase()}%`);
        result.command = 'sources';
        result.subject = subject;
        return result;
      }

      if (command === 'changes') {
        result.role_events = state.prepare(
          `SELECT * FROM role_events WHERE session_id = ? ORDER BY occurred_at`
        ).all(session_id);
        result.learnings = state.prepare(
          `SELECT * FROM learnings WHERE created_at >= (SELECT started_at FROM sessions WHERE id = ?) ORDER BY created_at`
        ).all(session_id);
        result.voice_deltas = state.prepare(
          `SELECT * FROM voice_deltas WHERE created_at >= (SELECT started_at FROM sessions WHERE id = ?) ORDER BY created_at`
        ).all(session_id);
        result.memories_changed = inspectMemory(state, {
          query: session_id, status: 'all', limit: 20,
        });
        result.command = 'changes';
        result.session_id = session_id;
        return result;
      }

      if (command === 'recall' && subject) {
        result.memories = inspectMemory(state, { query: subject, status: 'all', limit: 30 });
        result.state_hits = searchState(state, library, { query: subject, limit: 20 });
        result.library_hits = searchLibrary(library, { query: subject, limit: 10 });
        result.command = 'recall';
        result.subject = subject;
        return result;
      }

      if (command === 'correct' && args.correction) {
        const { target, fields, provenance } = args.correction;
        // The tool schema declares `correction` as a free-form object, so a
        // caller can easily send a different shape. Validate before handing it
        // to updateState, which would otherwise throw on target.split() and
        // surface as an opaque "internal error" to Bill.
        if (typeof target !== 'string' || !target.includes(':') || !fields || typeof fields !== 'object') {
          return {
            error: 'correct needs correction.target as "<table>:<id>" (from search_state) and correction.fields as an object',
            got: { target: target ?? null, fields_type: fields === undefined ? 'undefined' : typeof fields },
            hint: 'To change a memory atom rather than a funnel row, use save_coaching_state with a superseding memory instead.',
          };
        }
        result.update = updateState(state, {
          target,
          fields,
          provenance: `bill-said: ${provenance || 'correction issued by Bill'}`,
          session_id,
          as_of: new Date().toISOString(),
        });
        result.command = 'correct';
        return result;
      }

      if (command === 'forget' && subject) {
        // Mark matching memories as withdrawn. The columns are subject/content —
        // an earlier version queried name/value_text, which do not exist on this
        // table, so every forget failed with "no such column".
        // Bill may also name a record id directly, since the memory dump shows them.
        const needle = `%${subject.toLowerCase()}%`;
        const matches = state.prepare(
          `SELECT id FROM memories
             WHERE (lower(subject) LIKE ? OR lower(content) LIKE ? OR lower(id) = ?)
               AND status = 'active'`
        ).all(needle, needle, subject.toLowerCase());
        for (const m of matches) {
          state.prepare(`UPDATE memories SET status = 'withdrawn', updated_at = ? WHERE id = ?`).run(new Date().toISOString(), m.id);
        }
        result.withdrawn = matches.length;
        result.command = 'forget';
        result.subject = subject;
        return result;
      }

      return { error: 'unrecognised command or missing required subject' };
    },
  },
];

const toolsByName = new Map(TOOLS.map((t) => [t.name, t]));

// --- JSON-RPC loop ---------------------------------------------------------

function respond(id, result) {
  process.stdout.write(JSON.stringify({ jsonrpc: '2.0', id, result }) + '\n');
}
function respondError(id, code, message) {
  process.stdout.write(JSON.stringify({ jsonrpc: '2.0', id, error: { code, message } }) + '\n');
}

function handle(msg) {
  const { id, method, params } = msg;
  if (method === 'initialize') {
    const requested = params?.protocolVersion;
    respond(id, {
      protocolVersion: PROTOCOL_VERSIONS.includes(requested) ? requested : PROTOCOL_VERSIONS[0],
      capabilities: { tools: { listChanged: false } },
      serverInfo: SERVER,
    });
    return;
  }
  if (method === 'notifications/initialized' || method?.startsWith('notifications/')) return;
  if (method === 'ping') { respond(id, {}); return; }
  if (method === 'tools/list') {
    respond(id, { tools: TOOLS.map(({ name, description, inputSchema }) => ({ name, description, inputSchema })) });
    return;
  }
  if (method === 'tools/call') {
    const tool = toolsByName.get(params?.name);
    if (!tool) { respondError(id, -32602, `unknown tool: ${params?.name}`); return; }
    const args = params?.arguments ?? {};
    const errors = validate(tool.inputSchema, args);
    if (errors.length) {
      respond(id, { content: [{ type: 'text', text: JSON.stringify({ error: 'invalid input', details: errors }) }], isError: true });
      return;
    }
    try {
      const result = tool.handler(args);
      const isError = !!result?.error;
      respond(id, { content: [{ type: 'text', text: JSON.stringify(result) }], ...(isError ? { isError: true } : {}) });
    } catch (err) {
      // The messages thrown in here are written FOR the model — "lane is required",
      // "P1->P2 blocked: no outreach recorded, record the interaction first". Replacing
      // them with "internal error" threw away the entire guard vocabulary of the funnel
      // and left the coach unable to fix anything it got wrong.
      console.error(`[${tool.name}] ${err?.message ?? err}`);
      respond(id, {
        content: [{ type: 'text', text: JSON.stringify({ error: `${tool.name} failed: ${err?.message ?? String(err)}` }) }],
        isError: true,
      });
    }
    return;
  }
  if (id !== undefined) respondError(id, -32601, `unknown method: ${method}`);
}

const rl = createInterface({ input: process.stdin, terminal: false });
rl.on('line', (line) => {
  if (!line.trim()) return;
  let msg;
  try { msg = JSON.parse(line); } catch { respondError(null, -32700, 'parse error'); return; }
  try { handle(msg); } catch (err) {
    console.error(`protocol error: ${err?.message ?? err}`);
    if (msg?.id !== undefined) respondError(msg.id, -32603, 'internal error');
  }
});

function shutdown() {
  try { state.close(); library.close(); } catch { /* closing */ }
  process.exit(0);
}
rl.on('close', shutdown);
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
