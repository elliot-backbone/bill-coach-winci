#!/usr/bin/env node
// bill-coach MCP server: newline-delimited JSON-RPC 2.0 on stdio, seven tools,
// zero dependencies. stdout is protocol-only; diagnostics go to stderr and never
// contain source bodies or credentials.

import { createInterface } from 'node:readline';
import { DatabaseSync } from 'node:sqlite';
import { join } from 'node:path';
import { existsSync, readFileSync } from 'node:fs';

import { searchLibrary } from './library.mjs';
import { getContext } from './context.mjs';
import { saveCoachingState, inspectMemory } from './memory.mjs';
import { syncSource } from './sources.mjs';
import { assertVoiceContractSurface, emissionGate } from './gate.mjs';
import { startCoach, endCoach } from './lifecycle.mjs';
import { searchState, updateState } from './statesearch.mjs';
import { transitionPhase, createRole, touchRole } from './funnel.mjs';

const SERVER = { name: 'bill-coach', version: '1.5.2' };
const PROTOCOL_VERSIONS = ['2025-06-18', '2025-03-26', '2024-11-05'];

// --- databases -------------------------------------------------------------

const dataDir = process.env.BILL_COACH_DATA_DIR;
if (!dataDir) { console.error('BILL_COACH_DATA_DIR is not set'); process.exit(1); }
try {
  assertVoiceContractSurface(
    readFileSync(new URL('../coach/system-prompt.md', import.meta.url), 'utf8'),
    'installed system prompt',
  );
} catch (err) {
  console.error(`voice covenant unavailable: ${err.message}`);
  process.exit(1);
}
const libraryPath = join(dataDir, 'library', 'library.sqlite');
const statePath = join(dataDir, 'state', 'coach.sqlite');
for (const p of [libraryPath, statePath]) {
  if (!existsSync(p)) { console.error(`database missing: ${p}`); process.exit(1); }
}

// Opening is the most lock-prone moment in this process's life: a second coach
// window, or Claude Code restarting this server while the previous one is still
// exiting, contends for the same file. busy_timeout MUST be set before any
// statement that takes a lock — with it set afterwards, `PRAGMA journal_mode`
// failed instantly with "database is locked" and the second window died at boot.
const BUSY_TIMEOUT_MS = 10_000;

function openDb(dbPath, label) {
  try {
    const db = new DatabaseSync(dbPath);
    db.exec(`PRAGMA busy_timeout = ${BUSY_TIMEOUT_MS}`);
    // Every shipped database is already in WAL mode, so this is a confirmation
    // rather than a change. A concurrent reader can still block the mode switch,
    // and dying for a no-op would be the worst possible trade.
    try {
      db.exec('PRAGMA journal_mode = WAL');
    } catch (err) {
      console.error(`[${label}] could not confirm WAL mode (continuing): ${err.message}`);
    }
    db.exec('PRAGMA foreign_keys = ON');
    return db;
  } catch (err) {
    console.error(`cannot open the ${label} database at ${dbPath}: ${err.message}`);
    process.exit(1);
  }
}

const library = openDb(libraryPath, 'library');
const state = openDb(statePath, 'state');

// --- minimal JSON Schema validation (the subset the tool contracts use) ----

function validate(schema, value, path = 'input') {
  const errors = [];
  check(schema, value, path, errors);
  return errors;
}

function typeOf(v) {
  if (v === null) return 'null';
  if (Array.isArray(v)) return 'array';
  if (Number.isInteger(v)) return 'integer';
  return typeof v;
}

function check(schema, value, path, errors) {
  if (!schema) return;
  if (schema.const !== undefined && value !== schema.const) {
    errors.push(`${path} must be ${JSON.stringify(schema.const)}`); return;
  }
  if (schema.enum && !schema.enum.includes(value)) {
    errors.push(`${path} must be one of ${schema.enum.join(', ')}`); return;
  }
  const types = schema.type ? [schema.type].flat() : null;
  if (types) {
    const t = typeOf(value);
    const ok = types.some((want) => want === t || (want === 'number' && t === 'integer') || (want === 'integer' && t === 'integer'));
    if (!ok) { errors.push(`${path} must be ${types.join('|')}, got ${t}`); return; }
  }
  if (typeOf(value) === 'string') {
    if (schema.minLength !== undefined && value.length < schema.minLength) errors.push(`${path} is too short`);
    if (schema.maxLength !== undefined && value.length > schema.maxLength) errors.push(`${path} exceeds ${schema.maxLength} characters`);
  }
  if (typeOf(value) === 'integer' || typeof value === 'number') {
    if (schema.minimum !== undefined && value < schema.minimum) errors.push(`${path} must be >= ${schema.minimum}`);
    if (schema.maximum !== undefined && value > schema.maximum) errors.push(`${path} must be <= ${schema.maximum}`);
  }
  if (Array.isArray(value)) {
    if (schema.maxItems !== undefined && value.length > schema.maxItems) errors.push(`${path} exceeds ${schema.maxItems} items`);
    if (schema.items) value.forEach((v, i) => check(schema.items, v, `${path}[${i}]`, errors));
  }
  if (typeOf(value) === 'object' && schema.properties) {
    for (const key of schema.required ?? []) {
      if (value[key] === undefined) errors.push(`${path}.${key} is required`);
    }
    for (const [key, v] of Object.entries(value)) {
      if (schema.properties[key]) check(schema.properties[key], v, `${path}.${key}`, errors);
      else if (schema.additionalProperties === false) errors.push(`${path}.${key} is not a recognized field`);
    }
  }
}

// --- tool registry ---------------------------------------------------------

const str = (min, max) => ({ type: 'string', minLength: min, maxLength: max });
const idArray = { type: 'array', items: { type: 'string' }, maxItems: 50 };

// Approved-reply history is runtime context, not durable memory. It is bounded, keyed by
// the explicit Coach session id, cleared on a successful end_coach, and never populated by
// held drafts. With no session_id we use only caller-supplied priors and do not guess which
// active episode owns the text; cross-session contamination is worse than a missing metric.
const MAX_GATE_PRIORS = 20;
const MAX_GATE_SESSIONS = 32;
const approvedGateReplies = new Map();

function gateSessionKey(value) {
  return typeof value === 'string' && value.trim() ? value.trim() : null;
}

function exactDedupe(items) {
  const out = [];
  const seen = new Set();
  for (const item of items) {
    const text = String(item ?? '');
    if (!text.trim() || seen.has(text)) continue;
    seen.add(text);
    out.push(text);
  }
  return out;
}

function priorsForGate(sessionId, supplied = []) {
  const explicit = Array.isArray(supplied) ? supplied : [];
  if (!sessionId) return exactDedupe(explicit).slice(-MAX_GATE_PRIORS);
  // Caller-supplied priors are documented oldest-first and may reach farther back than this
  // process-local cache. Put them first, then the automatically retained recent tail.
  return exactDedupe([...explicit, ...(approvedGateReplies.get(sessionId) ?? [])]).slice(-MAX_GATE_PRIORS);
}

function rememberApprovedReply(sessionId, text) {
  if (!sessionId || typeof text !== 'string' || !text.trim()) return;
  const prior = approvedGateReplies.get(sessionId) ?? [];
  const next = exactDedupe([...prior, text]).slice(-MAX_GATE_PRIORS);
  // Delete-and-set makes Map insertion order an LRU order for the session bound below.
  approvedGateReplies.delete(sessionId);
  approvedGateReplies.set(sessionId, next);
  while (approvedGateReplies.size > MAX_GATE_SESSIONS) {
    approvedGateReplies.delete(approvedGateReplies.keys().next().value);
  }
}

function reviewDraft(args) {
  const sessionId = gateSessionKey(args.session_id);
  const result = emissionGate(args.draft, {
    attempt: args.attempt ?? 1,
    priors: priorsForGate(sessionId, args.priors),
  });
  // 1.13.2: a clean emit no longer echoes the text (the submitted draft IS the
  // approved bytes); a repaired emit still returns the repaired text. The rolling
  // reply history must hold whichever bytes Bill will actually read.
  if (result.decision === 'emit') rememberApprovedReply(sessionId, result.text ?? String(args.draft ?? ''));
  return result;
}

const SESSION_FIELDS = {
  status: { type: 'string', enum: ['active', 'closed', 'abandoned'] },
  situation: { type: ['string', 'null'], maxLength: 20000 },
  judgment: { type: ['string', 'null'], maxLength: 20000 },
  evidence_ids: { type: 'array', items: { type: 'string' }, maxItems: 100 },
  open_questions: { type: 'array', items: { type: 'string' }, maxItems: 30 },
  next_move: { type: ['string', 'null'], maxLength: 10000 },
};

const TOOLS = [
  {
    name: 'start_coach',
    description: 'Open or resume the coaching session and return the smallest complete orientation context. Call this first in every conversation.',
    inputSchema: {
      type: 'object', additionalProperties: false,
      properties: { user_message: str(1, 30000), now: { type: 'string' } },
      required: ['user_message'],
    },
    handler: (args) => startCoach(state, library, args),
  },
  {
    name: 'get_context',
    description: 'Assemble evidence and memory for one active coaching question using time, entity, topic and lens signals. Evidence includes conflicting and freshest-per-entity sources; never cite a fact the evidence does not carry.',
    inputSchema: {
      type: 'object', additionalProperties: false,
      properties: {
        session_id: str(1), question: str(1, 10000),
        entities: { type: 'array', items: { type: 'string' }, maxItems: 20 },
        lens: { type: 'string', enum: ['strategy', 'product', 'commercial', 'gtm', 'investor', 'organization', 'partnership', 'relationship', 'mixed'] },
        as_of: { type: 'string' },
        max_chunks: { type: 'integer', minimum: 4, maximum: 40 },
      },
      required: ['session_id', 'question'],
    },
    handler: (args) => getContext(state, library, args),
  },
  {
    name: 'search_library',
    description: 'Search the complete local source and doctrine library. Query "doc:<document_id>" (optionally "doc:<id>#<sequence>") returns a full document in ordered parts for continuation-based review.',
    inputSchema: {
      type: 'object', additionalProperties: false,
      properties: {
        query: str(1, 2000),
        kinds: { type: 'array', items: { type: 'string' }, maxItems: 12 },
        entities: { type: 'array', items: { type: 'string' }, maxItems: 20 },
        topics: { type: 'array', items: { type: 'string' }, maxItems: 20 },
        occurred_after: { type: 'string' }, occurred_before: { type: 'string' },
        limit: { type: 'integer', minimum: 1, maximum: 50 },
        include_document_text: { type: 'boolean' },
      },
      required: ['query'],
    },
    handler: (args) => searchLibrary(library, args),
  },
  {
    name: 'save_coaching_state',
    description: 'Persist the meaningful outcome of a coaching exchange in one transaction. Call at most once per exchange, only when something material changed. learnings writes the learning ledger — required at the close of every unit of work, and required before a role can be exited. deliverables writes the artefact itself and is REQUIRED whenever one was produced: without it the CV or the tight five is shown to Bill and then lost, and the next session rebuilds it from scratch instead of refining it.',
    inputSchema: {
      type: 'object', additionalProperties: false,
      properties: {
        session_id: str(1),
        expected_session_version: { type: 'integer', minimum: 1 },
        onboarding: {
          type: ['object', 'null'], additionalProperties: false,
          properties: {
            status: { type: 'string', enum: ['pane_1', 'pane_2', 'pane_3', 'pane_4', 'pane_5', 'pane_6', 'pane_7', 'complete'] },
            draft_picture: { type: 'string', maxLength: 30000 },
            corrections: { type: 'string', maxLength: 30000 },
            confirmed_picture: { type: 'string', maxLength: 30000 },
            confirmed_at: { type: 'string' },
          },
          required: ['status'],
        },
        session: { type: 'object', additionalProperties: false, properties: SESSION_FIELDS, required: ['status', 'evidence_ids', 'open_questions'] },
        voice_deltas: {
          type: 'array', maxItems: 20,
          items: {
            type: 'object', additionalProperties: false,
            properties: {
              id: str(1),
              feature: str(1, 200),
              rule: str(1, 2000),
              example: { type: ['string', 'null'], maxLength: 2000 },
              origin: { type: 'string', enum: ['chat-mining', 'onboarding-sample', 'draft-correction', 'session'] },
              status: { type: 'string', enum: ['active', 'retired'] },
            },
            required: ['id', 'feature', 'rule'],
          },
        },
        interaction_reviews: {
          type: 'array', maxItems: 20,
          items: {
            type: 'object', additionalProperties: false,
            properties: {
              id: str(1),
              interaction_id: { type: ['string', 'null'], maxLength: 200 },
              did_well: { type: ['string', 'null'], maxLength: 4000 },
              focus_next: str(1, 4000),
              fed_into: { type: 'array', items: { type: 'string' }, maxItems: 20 },
              occurred_at: { type: 'string' },
            },
            required: ['id', 'focus_next'],
          },
        },
        positions_held: {
          type: 'array', maxItems: 12,
          description: 'What Bill actually believes about selling, hiring, founders or his market, that he '
            + 'would defend in public under his own name. A position needs EVIDENCE — what he has seen that '
            + 'makes him hold it — and someone who would disagree. A position nobody could disagree with is '
            + 'not a position, it is a status update. public_ok records whether he is willing to say it '
            + 'publicly, and if he is not, that is a complete answer.',
          items: {
            type: 'object', additionalProperties: false,
            properties: {
              position: str(1, 2000),
              evidence: str(1, 4000),
              who_disagrees: { type: ['string', 'null'], maxLength: 1000 },
              public_ok: { type: 'boolean' },
              verbatim: { type: ['string', 'null'], maxLength: 2000 },
            },
            required: ['position', 'evidence'],
          },
        },
        rehearsal_rounds: {
          type: 'array', maxItems: 15,
          description: 'One row per attempt at a hard question. Record the question, what he actually said, '
            + 'and your verdict: weak, holding or strong. The session CANNOT CLOSE while any answer is weak '
            + '— accepting the first decent answer is the failure this module exists to prevent. Escalate: '
            + '1 is the question, 2 adds the follow-up he did not expect, 3 is the hostile version. Take the '
            + 'questions from the prep brief and from what he actually fumbled in the last debrief, not from '
            + 'imagination.',
          items: {
            type: 'object', additionalProperties: false,
            properties: {
              role_id: { type: ['string', 'null'], maxLength: 200 },
              interaction_id: { type: ['string', 'null'], maxLength: 200 },
              topic: str(1, 300),
              question: str(1, 2000),
              escalation: { type: 'integer', minimum: 1, maximum: 3 },
              his_answer: { type: ['string', 'null'], maxLength: 6000 },
              verdict: { type: ['string', 'null'], enum: ['weak', 'holding', 'strong', null] },
              what_was_weak: { type: ['string', 'null'], maxLength: 2000 },
              source: { type: 'string', enum: ['coach', 'prep_brief', 'debrief', 'negotiation'] },
              source_ref: { type: ['string', 'null'], maxLength: 200 },
            },
            required: ['topic', 'question'],
          },
        },
        facts: {
          type: 'array', maxItems: 25,
          description: 'What you established about a company: the claim, when it was true, and where it '
            + 'came from if you know. Nothing here outranks anything else — Bill can correct any of it at '
            + 'any time, and a correction simply becomes the record.',
          items: {
            type: 'object', additionalProperties: false,
            properties: {
              role_id: str(1, 200),
              kind: { type: 'string', enum: ['funding', 'headcount', 'revenue', 'product', 'customer',
                'person', 'market', 'hiring', 'other'] },
              claim: str(1, 2000),
              value_text: { type: ['string', 'null'], maxLength: 500 },
              as_of: str(4, 40),
              source: { type: ['string', 'null'], maxLength: 500 },
              source_url: { type: ['string', 'null'], maxLength: 1000 },
            },
            required: ['role_id', 'kind', 'claim', 'as_of'],
          },
        },
        debrief_capture: {
          type: 'array', maxItems: 20,
          description: 'What actually happened in ONE meeting with ONE company, near-verbatim. REQUIRED '
            + 'after every conversation Bill reports. Their words beat your summary: a question a founder '
            + 'asks twice is the decision criterion, so mark it. This is what the NEXT brief for that '
            + 'company reads, so it is the difference between round two knowing what round one taught and '
            + 'starting again.',
          items: {
            type: 'object', additionalProperties: false,
            properties: {
              role_id: str(1, 200),
              interaction_id: { type: ['string', 'null'], maxLength: 200 },
              slot: { type: 'string', enum: ['what_was_asked', 'what_he_said', 'where_it_stalled',
                'their_language', 'signals_read', 'commitments_made', 'what_he_would_do_differently'] },
              detail: str(1, 4000),
              verbatim: { type: ['string', 'null'], maxLength: 4000, description: 'their exact words where he can recall them' },
              who: { type: ['string', 'null'], maxLength: 200 },
              asked_twice: { type: 'boolean' },
              flag_id: { type: ['string', 'null'], description: 'the green flag this moment evidences, if any' },
            },
            required: ['role_id', 'slot', 'detail'],
          },
        },
        cv_lines: {
          type: 'array', maxItems: 40,
          description: 'HIS CV, line by line. Ingest every line with current_text when he supplies the '
            + 'document. During the pass, add ONE proposed_text with the rationale and the evidence_refs '
            + 'that support it, then his ruling. Nothing is final without bill_ruling: he accepts, rejects '
            + 'or amends, and his amendment wins. Never compose a replacement CV — this is his document.',
          items: {
            type: 'object', additionalProperties: false,
            properties: {
              line_no: { type: 'integer', minimum: 1 },
              surface: { type: 'string', enum: ['cv', 'headline', 'about', 'experience'] },
              section: { type: ['string', 'null'], maxLength: 200 },
              lane: { type: ['string', 'null'], enum: ['core-ft', 'fractional', 'us-remote', null] },
              current_text: str(1, 4000),
              proposed_text: { type: ['string', 'null'], maxLength: 4000 },
              rationale: { type: ['string', 'null'], maxLength: 4000 },
              evidence_refs: {
                type: 'array', maxItems: 8, items: str(1, 200),
                description: 'ids or plain references to what on file supports the change: a coverage '
                  + 'scene, a memory, a learning, a role, the live tight five. REQUIRED with any proposal.',
              },
              challenge_asked: { type: ['string', 'null'], maxLength: 2000 },
              challenge_answer: { type: ['string', 'null'], maxLength: 4000 },
              bill_ruling: { type: ['string', 'null'], enum: ['accepted', 'rejected', 'amended', null] },
              final_text: { type: ['string', 'null'], maxLength: 4000 },
              source_deliverable_id: { type: ['string', 'null'], maxLength: 200 },
            },
            required: ['line_no', 'current_text'],
          },
        },
        narrative_coverage: {
          type: 'array', maxItems: 12,
          description: 'What the biographical interview just surfaced, one row per scene. REQUIRED after every '
            + 'tight-five interview turn. A scene without an age or a date does not count toward coverage, '
            + 'because it cannot be sequenced later.',
          items: {
            type: 'object', additionalProperties: false,
            properties: {
              slot: { type: 'string', enum: ['childhood', 'family_and_money', 'schooling', 'first_work',
                'professional_sequence', 'cost_and_doubt', 'turning_point', 'present_want'] },
              scene: str(1, 4000),
              age_or_date: {
                type: 'string', minLength: 1, maxLength: 60,
                description: 'his age or the year. A RELATIVE anchor is fine and often truer — "before '
                  + 'secondary school", "the year his dad stopped playing" — and sequences just as well. '
                  + 'Never supply an age he did not give: pressing for specificity is what makes a person '
                  + 'fill the gap with something plausible, and a fabricated detail in his narrative gets '
                  + 'him caught in a real room.',
              },
              named_detail: { type: ['string', 'null'], description: 'the place, person, company or number he named' },
              verbatim: { type: ['string', 'null'], description: 'his own words, exactly, where a usable phrase came out' },
              flag_id: { type: ['string', 'null'], description: 'the green flag this scene evidences, if any' },
            },
            // age_or_date is REQUIRED, not optional. MEASURED 2026-08-23: with it optional, Coach
            // filed six scenes and dated one, so coverage sat at 1 of 8 while the interview
            // looked productive. If he genuinely does not know when something happened, ASK
            // him — that question is part of the method, not an inconvenience around it.
            required: ['slot', 'scene', 'age_or_date'],
          },
        },
        green_flags: {
          type: 'array', maxItems: 13,
          description: 'Re-rank the green flag library for the conversation in hand. The flags are doctrine and '
            + 'cannot be edited from a session; only their order and their counters move. Rank by what THIS '
            + 'audience weights — a seed founder hiring a first commercial hire is not an investor.',
          items: {
            type: 'object', additionalProperties: false,
            properties: {
              name: str(1, 80),
              current_rank: { type: ['integer', 'null'], minimum: 1 },
              surfaced: { type: 'boolean', description: 'this flag was hunted in this conversation' },
              landed: { type: 'boolean', description: 'evidence for it actually came out' },
              rank_reason: { type: ['string', 'null'], maxLength: 500 },
            },
            required: ['name'],
          },
        },
        deliverables: {
          type: 'array', maxItems: 6,
          description: 'The artefact itself, in full, exactly as it was given to Bill — not a summary of it and '
            + 'not the lesson drawn from it. REQUIRED whenever a module produces one: a CV, a tight five, LinkedIn '
            + 'copy, a one-pager, posts, an outreach message, a prep brief, a debrief, an offer review, a '
            + 'negotiation plan, a weekly review. No confirmation from Bill is needed or waited for. Saving is '
            + 'automatic and unchallenged; if he later corrects it, save the corrected version and the old one is '
            + 'kept underneath it.',
          items: {
            type: 'object', additionalProperties: false,
            properties: {
              kind: { type: 'string', enum: ['tight_five', 'cv', 'linkedin', 'content', 'positioning_one_pager',
                'discovery_pipeline', 'outreach', 'prep_brief', 'rehearsal', 'debrief', 'offer_review',
                'negotiation_plan', 'weekly_review', 'thread_pull', 'other'] },
              title: str(1, 200),
              body: str(1, 60000),
              change_note: { type: ['string', 'null'], description: 'what prompted this revision, if it revises one' },
              role_id: { type: ['string', 'null'], description: 'set when the artefact belongs to one company' },
            },
            required: ['kind', 'title', 'body'],
          },
        },
        learnings: {
          type: 'array', maxItems: 20,
          items: {
            type: 'object', additionalProperties: false,
            properties: {
              id: str(1),
              category: { type: 'string', enum: ['market', 'positioning', 'want', 'performance', 'narrative', 'process'] },
              learning: str(1, 4000),
              evidence: { type: ['string', 'null'], maxLength: 4000 },
              source_kind: { type: 'string', maxLength: 60 },
              source_id: { type: ['string', 'null'], maxLength: 200 },
              fed_into: { type: 'array', items: { type: 'string' }, maxItems: 20 },
              occurred_at: { type: 'string' },
            },
            // `id` is NOT required. A caller recording what it just learned has no id to supply
            // and no way to invent a meaningful one; demanding it refused the write outright,
            // and inside the runtime an absent id crashed the de-duplication query and took the
            // whole transaction with it. Coach generates the id.
            required: ['category', 'learning'],
          },
        },
        memories: {
          type: 'array', maxItems: 20,
          items: {
            type: 'object', additionalProperties: false,
            properties: {
              action: { type: 'string', enum: ['upsert', 'supersede', 'withdraw'] },
              id: str(1),
              type: { type: 'string', enum: ['company', 'person', 'pattern', 'preference', 'constraint', 'hypothesis', 'context'] },
              subject: str(1, 500), content: str(1, 10000),
              effective_at: { type: ['string', 'null'] },
              source_ids: idArray, sensitive: { type: 'boolean' },
              supersedes_id: { type: ['string', 'null'] },
            },
            required: ['action', 'id', 'type', 'subject', 'content', 'source_ids', 'sensitive'],
          },
        },
        metrics: {
          type: 'array', maxItems: 20,
          items: {
            type: 'object', additionalProperties: false,
            properties: {
              action: { type: 'string', enum: ['upsert', 'supersede', 'withdraw'] },
              id: str(1), name: str(1, 300), value_text: str(1, 1000),
              unit: { type: ['string', 'null'], maxLength: 100 },
              definition: { type: ['string', 'null'], maxLength: 2000 },
              scope: str(1, 500), as_of: { type: 'string' },
              staleness_class: { type: 'string', enum: ['fast', 'normal', 'slow', 'static'] },
              source_ids: idArray, supersedes_id: { type: ['string', 'null'] },
            },
            required: ['action', 'id', 'name', 'value_text', 'scope', 'as_of', 'staleness_class', 'source_ids'],
          },
        },
        decisions: {
          type: 'array', maxItems: 20,
          items: {
            type: 'object', additionalProperties: false,
            properties: {
              action: { type: 'string', enum: ['upsert', 'revisit', 'reverse', 'complete'] },
              id: str(1), decision: str(1, 10000),
              reason: { type: ['string', 'null'], maxLength: 10000 },
              made_at: { type: 'string' },
              outcome: { type: ['string', 'null'], maxLength: 10000 },
              source_ids: idArray,
            },
            required: ['action', 'id', 'decision', 'made_at', 'source_ids'],
          },
        },
        commitments: {
          type: 'array', maxItems: 20,
          items: {
            type: 'object', additionalProperties: false,
            properties: {
              action: { type: 'string', enum: ['upsert', 'complete', 'drop', 'change'] },
              id: str(1), owner: str(1, 300), commitment: str(1, 10000),
              due_at: { type: ['string', 'null'] },
              outcome: { type: ['string', 'null'], maxLength: 10000 },
              next_review_at: { type: ['string', 'null'] },
              source_ids: idArray,
            },
            required: ['action', 'id', 'owner', 'commitment', 'source_ids'],
          },
        },
        // ONE row: the always-on model of Bill himself, and the only place his own
        // corrections to it can persist. Network contacts belong in `contacts`,
        // which is searchable; anything written here is in EVERY orientation.
        principal_profile: {
          type: 'array', maxItems: 4,
          items: {
            type: 'object', additionalProperties: false,
            properties: {
              action: { type: 'string', enum: ['upsert', 'withdraw'] },
              id: str(1), name: str(1, 300),
              role: { type: ['string', 'null'], maxLength: 500 },
              strengths: { type: 'array', items: { type: 'string' }, maxItems: 20 },
              focus_areas: { type: 'array', items: { type: 'string' }, maxItems: 20 },
              working_model: { type: ['string', 'null'], maxLength: 10000 },
              source_ids: idArray,
            },
            required: ['action', 'id', 'name', 'strengths', 'focus_areas', 'source_ids'],
          },
        },
      },
        learnings: {
          type: 'array', maxItems: 20,
          items: {
            type: 'object', additionalProperties: false,
            properties: {
              category: { type: 'string', enum: ['market', 'positioning', 'want', 'performance', 'narrative', 'process'] },
              learning: str(1, 4000), evidence: { type: ['string', 'null'] },
              source_kind: str(1, 60), source_id: { type: ['string', 'null'] },
              fed_into: { type: 'array', maxItems: 6, items: { type: 'string' } },
            },
            required: ['category', 'learning', 'source_kind'],
          },
        },
        voice_deltas: {
          type: 'array', maxItems: 10,
          items: {
            type: 'object', additionalProperties: false,
            properties: {
              feature: str(1, 60), rule: str(1, 2000), example: { type: ['string', 'null'] },
              origin: { type: 'string', enum: ['chat-mining', 'onboarding-sample', 'draft-correction', 'session'] },
            },
            required: ['feature', 'rule', 'origin'],
          },
        },
        interaction_reviews: {
          type: 'array', maxItems: 10,
          items: {
            type: 'object', additionalProperties: false,
            properties: { interaction_id: str(1), review: { type: 'object' } },
            required: ['interaction_id', 'review'],
          },
        },
      // `session` is NOT required. The runtime has handled its absence since 2026-08-23, but the
      // schema still demanded it, so a call that saved only facts or only learnings was refused
      // with "input.session is required" — a caller forced to touch the session block for a write
      // that has nothing to do with the session.
      required: ['session_id', 'expected_session_version'],
    },
    handler: (args) => saveCoachingState(state, args),
  },
  {
    name: 'inspect_memory',
    description: 'Retrieve or review durable coach memory when Bill asks what is remembered or wants something changed. Corrections themselves go through save_coaching_state.',
    inputSchema: {
      type: 'object', additionalProperties: false,
      properties: {
        query: { type: 'string', maxLength: 2000 },
        types: { type: 'array', items: { type: 'string' }, maxItems: 8 },
        status: { type: 'string', enum: ['active', 'superseded', 'withdrawn', 'all'] },
        limit: { type: 'integer', minimum: 1, maximum: 100 },
      },
    },
    handler: (args) => inspectMemory(state, args),
  },
  {
    name: 'sync_source',
    description: 'Import current information from an already configured read-only source after explicit approval in this conversation. Append-only; never edits or deletes an existing source.',
    inputSchema: {
      type: 'object', additionalProperties: false,
      properties: {
        source_id: str(1),
        scope: { type: 'object' },
        approved: { const: true },
        reason: str(1, 1000),
      },
      required: ['source_id', 'approved', 'reason'],
    },
    handler: (args) => syncSource(state, library, args),
  },
  {
    // The emission gate. Bill's chassis streams model text straight to the terminal, so a
    // reply cannot be held back once it starts — unless emission is routed through a tool.
    // The draft comes here first and only the returned text is printed.
    name: 'review_draft',
    description: 'THE EMISSION GATE — every reply to Bill passes through this before he sees a word of it. '
      + 'Compose the full reply, submit it here as `draft`. decision "emit" with no `text` field means your '
      + 'draft was approved unchanged: print the EXACT draft you submitted, verbatim, nothing added before '
      + 'or after (the result carries its sha256). If the result DOES carry `text`, the gate repaired it: '
      + 'print that returned text exactly. decision "hold" means it was not sent — rewrite the same substance '
      + 'without the listed violations and submit again with attempt 2. The gate repairs safe '
      + 'punctuation/narration, then re-runs every block; attempt count never waives a violation. Never print '
      + 'a draft that has not been through this. EXCEPTION — pre-written onboarding pane bodies are '
      + 'principal-approved and gate-exempt: submit only the lines you authored around them.',
    inputSchema: {
      type: 'object', additionalProperties: false,
      properties: {
        draft: str(1, 30000),
        attempt: { type: 'integer', minimum: 1, maximum: 5 },
        session_id: { type: ['string', 'null'], maxLength: 200 },
        priors: {
          type: 'array', maxItems: 20,
          description: 'Your earlier replies to Bill in THIS session, oldest first, so the gate can see what '
            + 'no single reply can show: the same opening used three times, the same numbered shape every '
            + 'turn, a phrase becoming a tic. Pass them whenever you have them.',
          items: str(1, 8000),
        },
      },
      required: ['draft'],
    },
    handler: reviewDraft,
  },
  {
    name: 'end_coach',
    description: 'Close the active episode with the judgment, commitments and next review point preserved.',
    inputSchema: {
      type: 'object', additionalProperties: false,
      properties: {
        session_id: str(1),
        expected_session_version: { type: 'integer', minimum: 1 },
        judgment: str(1, 10000),
        next_move: str(1, 5000),
        commitments: {
          type: 'array', maxItems: 10,
          items: {
            type: 'object', additionalProperties: false,
            properties: {
              id: str(1), owner: str(1, 300), commitment: str(1, 10000),
              due_at: { type: ['string', 'null'] }, next_review_at: { type: ['string', 'null'] },
              source_ids: idArray,
            },
            required: ['id', 'owner', 'commitment', 'source_ids'],
          },
        },
        next_review_at: { type: ['string', 'null'] },
      },
      required: ['session_id', 'expected_session_version', 'judgment', 'next_move'],
    },
    handler: (args) => {
      const result = endCoach(state, args);
      if (!result?.error) approvedGateReplies.delete(gateSessionKey(args.session_id));
      return result;
    },
  },
  {
    name: 'search_state',
    description: 'One search across ALL durable state (funnel roles, interactions, offers, contacts, learnings, voice deltas, investor roster, sourcing runs, memories, metrics, commitments, deliverables, green flags, narrative coverage) and the market_deals baseline. Use before updating anything, and before drafting anything Bill already has a version of.',
    inputSchema: {
      type: 'object', additionalProperties: false,
      properties: {
        query: str(1, 500),
        tables: { type: 'array', maxItems: 12, items: { type: 'string' } },
        filters: {
          type: 'object', additionalProperties: false,
          properties: {
            phase: { type: 'string' }, lane: { type: 'string' }, mode: { type: 'string' },
            relationship: { type: 'string' }, category: { type: 'string' },
            due_before: { type: 'string' }, updated_since: { type: 'string' },
          },
        },
        limit: { type: 'integer', minimum: 1, maximum: 50 },
      },
      required: ['query'],
    },
    handler: (args) => searchState(state, library, { ...args, limit: args.limit ?? 20 }),
  },
  {
    name: 'update_state',
    description: 'Audited field-level write to funnel state (roles, interactions, offers, contacts, investor_roster, sourcing_runs). target "<table>:<id>" from search_state, or "<table>:new" to create. Creating a role requires company, lane (core-ft | fractional | us-remote | other) and source; a create that is missing a required field returns the field names and their allowed values. Facts update freely with provenance; fields carrying Bill\'s judgment require provenance beginning "bill-said". Special actions: fields.action = "transition" (with to_phase) routes phase moves through the evidence guards; "touch" records a touchpoint.',
    inputSchema: {
      type: 'object', additionalProperties: false,
      properties: {
        target: str(3, 200),
        fields: { type: 'object' },
        provenance: str(3, 500),
        as_of: { type: 'string' },
        session_id: str(1),
        autonomous: { type: 'boolean' },
      },
      required: ['target', 'fields', 'provenance', 'session_id'],
    },
    handler: (args) => {
      const { target, fields, provenance, session_id, autonomous } = args;
      if (fields && fields.action === 'transition') {
        const roleId = target.split(':').slice(1).join(':');
        const { to_phase, ...extras } = fields;
        delete extras.action;
        return transitionPhase(state, roleId, to_phase, provenance, session_id, extras);
      }
      if (fields && fields.action === 'touch') {
        const roleId = target.split(':').slice(1).join(':');
        return touchRole(state, roleId, fields.note ?? null, provenance, session_id);
      }
      // Both spellings reach the validated creator: the documented `roles:new` and the
      // action form. Before 1.2.5 only the action form did, so following the tool's own
      // description produced a raw insert and a NOT NULL constraint failure.
      if ((fields && fields.action === 'create_role') || target === 'roles:new') {
        const input = { ...fields, provenance, autonomous };
        delete input.action;
        if (args.as_of && !input.as_of) input.as_of = args.as_of;
        return createRole(state, input, session_id);
      }
      return updateState(state, args);
    },
  },
  // ---- HARDCODED BILL COMMANDS ----
  // Deterministic handlers: each executes a fixed tool sequence, returning structured
  // results. The model presents the output; the data assembly is code, not prompt.
  {
    name: 'bill_command',
    description: 'Execute a hardcoded Bill command. Commands: memory (full data dump), pipeline (funnel export), sources (provenance for a claim), changes (session changelog), recall (everything on a topic), correct (override a record), forget (delete a record). These are deterministic — same command always produces the same query sequence.',
    inputSchema: {
      type: 'object', additionalProperties: false,
      properties: {
        command: { type: 'string', enum: ['memory', 'pipeline', 'sources', 'changes', 'recall', 'correct', 'forget'] },
        session_id: str(1),
        subject: { type: 'string', maxLength: 2000, description: 'For recall/sources/correct/forget: the topic, claim, or record in question' },
        correction: { type: 'object', description: 'For correct: { target, fields, provenance }' },
      },
      required: ['command', 'session_id'],
    },
    handler: (args) => {
      const { command, session_id, subject } = args;
      const result = {};

      if (command === 'memory') {
        // Full transparency dump: every store, every namespace, nothing hidden
        result.memories = inspectMemory(state, { status: 'all', limit: 100 });
        const allTables = ['roles', 'interactions', 'offers', 'contacts', 'learnings', 'voice_deltas', 'investor_roster', 'sourcing_runs'];
        result.state = {};
        for (const tbl of allTables) {
          try { result.state[tbl] = state.prepare(`SELECT * FROM ${tbl} ORDER BY rowid DESC LIMIT 100`).all(); } catch { result.state[tbl] = []; }
        }
        result.commitments = state.prepare('SELECT * FROM commitments WHERE status = \'active\' ORDER BY due_at').all();
        result.settings = state.prepare('SELECT key, value_json FROM settings').all();
        result.library_docs = library.prepare('SELECT id, title, kind FROM documents ORDER BY title').all();
        result.command = 'memory';
        return result;
      }

      if (command === 'pipeline') {
        result.roles = state.prepare('SELECT * FROM roles ORDER BY phase, updated_at DESC').all();
        result.recent_events = state.prepare('SELECT * FROM role_events ORDER BY occurred_at DESC LIMIT 50').all();
        result.active_interactions = state.prepare('SELECT * FROM interactions ORDER BY occurred_at DESC LIMIT 30').all();
        result.offers = state.prepare('SELECT * FROM offers ORDER BY created_at DESC').all();
        result.contacts = state.prepare('SELECT * FROM contacts ORDER BY updated_at DESC LIMIT 50').all();
        result.command = 'pipeline';
        return result;
      }

      if (command === 'sources' && subject) {
        // Find every record mentioning the subject with its provenance
        result.memories = inspectMemory(state, { query: subject, status: 'all', limit: 20 });
        result.role_events = state.prepare(
          `SELECT * FROM role_events WHERE lower(provenance) LIKE ? OR lower(new_value) LIKE ? ORDER BY occurred_at DESC LIMIT 20`
        ).all(`%${subject.toLowerCase()}%`, `%${subject.toLowerCase()}%`);
        result.sourcing_runs = state.prepare(
          `SELECT * FROM sourcing_runs WHERE lower(scope) LIKE ? OR lower(notes) LIKE ? ORDER BY started_at DESC LIMIT 10`
        ).all(`%${subject.toLowerCase()}%`, `%${subject.toLowerCase()}%`);
        result.command = 'sources';
        result.subject = subject;
        return result;
      }

      if (command === 'changes') {
        result.role_events = state.prepare(
          `SELECT * FROM role_events WHERE session_id = ? ORDER BY occurred_at`
        ).all(session_id);
        result.learnings = state.prepare(
          `SELECT * FROM learnings WHERE created_at >= (SELECT started_at FROM sessions WHERE id = ?) ORDER BY created_at`
        ).all(session_id);
        result.voice_deltas = state.prepare(
          `SELECT * FROM voice_deltas WHERE created_at >= (SELECT started_at FROM sessions WHERE id = ?) ORDER BY created_at`
        ).all(session_id);
        result.memories_changed = inspectMemory(state, {
          query: session_id, status: 'all', limit: 20,
        });
        result.command = 'changes';
        result.session_id = session_id;
        return result;
      }

      if (command === 'recall' && subject) {
        result.memories = inspectMemory(state, { query: subject, status: 'all', limit: 30 });
        result.state_hits = searchState(state, library, { query: subject, limit: 20 });
        result.library_hits = searchLibrary(library, { query: subject, limit: 10 });
        result.command = 'recall';
        result.subject = subject;
        return result;
      }

      if (command === 'correct' && args.correction) {
        const { target, fields, provenance } = args.correction;
        // The tool schema declares `correction` as a free-form object, so a
        // caller can easily send a different shape. Validate before handing it
        // to updateState, which would otherwise throw on target.split() and
        // surface as an opaque "internal error" to Bill.
        if (typeof target !== 'string' || !target.includes(':') || !fields || typeof fields !== 'object') {
          return {
            error: 'correct needs correction.target as "<table>:<id>" (from search_state) and correction.fields as an object',
            got: { target: target ?? null, fields_type: fields === undefined ? 'undefined' : typeof fields },
            hint: 'To change a memory atom rather than a funnel row, use save_coaching_state with a superseding memory instead.',
          };
        }
        result.update = updateState(state, {
          target,
          fields,
          provenance: `bill-said: ${provenance || 'correction issued by Bill'}`,
          session_id,
          as_of: new Date().toISOString(),
        });
        result.command = 'correct';
        return result;
      }

      if (command === 'forget' && subject) {
        // Mark matching memories as withdrawn. The columns are subject/content —
        // an earlier version queried name/value_text, which do not exist on this
        // table, so every forget failed with "no such column".
        // Bill may also name a record id directly, since the memory dump shows them.
        const needle = `%${subject.toLowerCase()}%`;
        const matches = state.prepare(
          `SELECT id FROM memories
             WHERE (lower(subject) LIKE ? OR lower(content) LIKE ? OR lower(id) = ?)
               AND status = 'active'`
        ).all(needle, needle, subject.toLowerCase());
        for (const m of matches) {
          state.prepare(`UPDATE memories SET status = 'withdrawn', updated_at = ? WHERE id = ?`).run(new Date().toISOString(), m.id);
        }
        result.withdrawn = matches.length;
        result.command = 'forget';
        result.subject = subject;
        return result;
      }

      return { error: 'unrecognised command or missing required subject' };
    },
  },
];

const toolsByName = new Map(TOOLS.map((t) => [t.name, t]));

// --- JSON-RPC loop ---------------------------------------------------------

function respond(id, result) {
  process.stdout.write(JSON.stringify({ jsonrpc: '2.0', id, result }) + '\n');
}
function respondError(id, code, message) {
  process.stdout.write(JSON.stringify({ jsonrpc: '2.0', id, error: { code, message } }) + '\n');
}

function handle(msg) {
  const { id, method, params } = msg;
  if (method === 'initialize') {
    const requested = params?.protocolVersion;
    respond(id, {
      protocolVersion: PROTOCOL_VERSIONS.includes(requested) ? requested : PROTOCOL_VERSIONS[0],
      capabilities: { tools: { listChanged: false } },
      serverInfo: SERVER,
    });
    return;
  }
  if (method === 'notifications/initialized' || method?.startsWith('notifications/')) return;
  if (method === 'ping') { respond(id, {}); return; }
  if (method === 'tools/list') {
    respond(id, { tools: TOOLS.map(({ name, description, inputSchema }) => ({ name, description, inputSchema })) });
    return;
  }
  if (method === 'tools/call') {
    const tool = toolsByName.get(params?.name);
    if (!tool) { respondError(id, -32602, `unknown tool: ${params?.name}`); return; }
    const args = params?.arguments ?? {};
    // `confirmed` was a two-tier confidence model, removed in 1.3.1. An instruction
    // surface written before that may still send it; dropping it here — ahead of
    // validation — means such a caller keeps working instead of having a whole memory
    // write rejected over a field that no longer means anything.
    for (const list of ['memories', 'principal_profile', 'people']) {
      if (Array.isArray(args?.[list])) {
        for (const row of args[list]) { if (row && typeof row === 'object') delete row.confirmed; }
      }
    }
    const errors = validate(tool.inputSchema, args);
    if (errors.length) {
      respond(id, { content: [{ type: 'text', text: JSON.stringify({ error: 'invalid input', details: errors }) }], isError: true });
      return;
    }
    try {
      const result = tool.handler(args);
      const isError = !!result?.error;
      respond(id, { content: [{ type: 'text', text: JSON.stringify(result) }], ...(isError ? { isError: true } : {}) });
    } catch (err) {
      // The messages thrown in here are written FOR the model — "lane is required",
      // "P1->P2 blocked: no outreach recorded, record the interaction first". Replacing
      // them with "internal error" threw away the entire guard vocabulary of the funnel
      // and left the coach unable to fix anything it got wrong.
      console.error(`[${tool.name}] ${err?.message ?? err}`);
      respond(id, {
        content: [{ type: 'text', text: JSON.stringify({ error: `${tool.name} failed: ${err?.message ?? String(err)}` }) }],
        isError: true,
      });
    }
    return;
  }
  if (id !== undefined) respondError(id, -32601, `unknown method: ${method}`);
}

const rl = createInterface({ input: process.stdin, terminal: false });
rl.on('line', (line) => {
  if (!line.trim()) return;
  let msg;
  try { msg = JSON.parse(line); } catch { respondError(null, -32700, 'parse error'); return; }
  try { handle(msg); } catch (err) {
    console.error(`protocol error: ${err?.message ?? err}`);
    if (msg?.id !== undefined) respondError(msg.id, -32603, 'internal error');
  }
});

function shutdown() {
  try { state.close(); library.close(); } catch { /* closing */ }
  process.exit(0);
}
rl.on('close', shutdown);
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
