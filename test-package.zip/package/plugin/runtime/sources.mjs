// sync_source: append-only import from an already configured read-only source.
// The only write path into library.sqlite. No edit or delete of existing bodies, ever.

import { createHash } from 'node:crypto';

const ALLOWED_SCOPE_KEYS = new Set(['documents', 'kinds']);

function sha256(text) { return createHash('sha256').update(text, 'utf8').digest('hex'); }

function chunkParagraphs(text, target = 5200) {
  const paras = text.split(/\n{2,}/);
  const chunks = [];
  let current = '';
  for (const p of paras) {
    if (current && current.length + p.length + 2 > target) { chunks.push(current); current = ''; }
    current = current ? `${current}\n\n${p}` : p;
    while (current.length > target * 1.6) { chunks.push(current.slice(0, target)); current = current.slice(target); }
  }
  if (current.trim()) chunks.push(current);
  return chunks.length ? chunks : [text];
}

export function syncSource(state, library, input, nowIso = new Date().toISOString()) {
  const { source_id: sourceId, scope = {}, approved, reason } = input;
  const warnings = [];

  const connection = state.prepare(`SELECT * FROM source_connections WHERE id = ?`).get(sourceId);
  if (!connection) return { error: `source not configured: ${sourceId}` };
  if (approved !== true) return { error: 'sync requires explicit approval (approved: true)' };
  if (connection.read_only !== 1) return { error: 'source is not read-only; refusing' };
  if (!['configured', 'ready'].includes(connection.status)) {
    return { error: `source ${sourceId} is ${connection.status}; refusing` };
  }

  const configuredScope = JSON.parse(connection.scope_json ?? '{}');
  for (const key of Object.keys(scope)) {
    if (!ALLOWED_SCOPE_KEYS.has(key) || !(key in configuredScope)) {
      return { error: `scope expansion rejected: "${key}" is not within the configured scope` };
    }
  }
  const allowedKinds = new Set(configuredScope.kinds ?? []);
  const docs = scope.documents;
  if (!Array.isArray(docs) || docs.length === 0) {
    return { error: 'nothing to import: scope.documents must be a non-empty array of retrieved documents' };
  }
  if (docs.length > 50) return { error: 'too many documents in one sync (max 50)' };

  let added = 0, updated = 0, latest = null;

  state.exec('BEGIN IMMEDIATE');
  try {
    const insertDoc = library.prepare(`
      INSERT INTO documents (id, kind, title, author, occurred_at, captured_at, authority_rank, authority_scope,
        media_type, source_group, external_id, extracted_text, content_sha256, status, attributes_json)
      VALUES (?, ?, ?, ?, ?, ?, 80, 'general', 'text/plain', ?, ?, ?, ?, 'active', ?)
    `);
    const insertChunk = library.prepare(`
      INSERT INTO chunks (document_id, sequence, heading, speaker, text, token_count, content_sha256, attributes_json)
      VALUES (?, ?, ?, ?, ?, ?, ?, '{}')
    `);
    const insertEntity = library.prepare(`INSERT OR IGNORE INTO document_entities (document_id, entity, role) VALUES (?, ?, '')`);
    const insertTopic = library.prepare(`INSERT OR IGNORE INTO document_topics (document_id, topic) VALUES (?, ?)`);
    const insertRelation = library.prepare(`INSERT OR IGNORE INTO document_relations (from_document_id, relation, to_document_id) VALUES (?, ?, ?)`);

    for (const d of docs) {
      if (typeof d?.kind !== 'string' || typeof d?.title !== 'string' || typeof d?.text !== 'string' || !d.text.trim()) {
        warnings.push(`skipped document without kind/title/text: ${JSON.stringify(d?.title ?? d?.external_id ?? 'unknown').slice(0, 120)}`);
        continue;
      }
      if (allowedKinds.size && !allowedKinds.has(d.kind)) {
        warnings.push(`skipped "${d.title}": kind "${d.kind}" outside configured scope`);
        continue;
      }
      if (/write|send|post|update|delete/i.test(d.kind)) {
        warnings.push(`skipped "${d.title}": kind suggests a write capability`);
        continue;
      }

      const hash = sha256(d.text);
      const existingByContent = library.prepare(`SELECT id FROM documents WHERE content_sha256 = ?`).get(hash);
      if (existingByContent) { updated += 1; continue; }

      const sourceGroup = `sync:${sourceId}`;
      const externalId = d.external_id ?? null;
      let id = `${sourceGroup}:${externalId ?? hash.slice(0, 16)}`;

      const existingByExternal = externalId
        ? library.prepare(`SELECT id FROM documents WHERE source_group = ? AND external_id = ?`).get(sourceGroup, externalId)
        : null;
      let supersedes = null;
      let effectiveExternalId = externalId;
      if (existingByExternal) {
        // Same external identity, new content: append a new version, never edit the old body.
        id = `${sourceGroup}:${externalId}:${hash.slice(0, 12)}`;
        effectiveExternalId = `${externalId}:${hash.slice(0, 12)}`;
        supersedes = existingByExternal.id;
      }

      const occurred = d.occurred_at ?? null;
      insertDoc.run(id, d.kind, d.title, d.author ?? null, occurred, nowIso, sourceGroup,
        effectiveExternalId, d.text, hash,
        JSON.stringify(d.attributes ?? {}));

      chunkParagraphs(d.text).forEach((text, i) => {
        insertChunk.run(id, i, null, null, text, Math.ceil(text.length / 4), sha256(text));
      });
      for (const e of d.entities ?? []) insertEntity.run(id, String(e).toLowerCase());
      for (const t of d.topics ?? []) insertTopic.run(id, String(t).toLowerCase());
      if (supersedes) {
        insertRelation.run(id, 'supersedes', supersedes);
        library.prepare(`UPDATE documents SET status = 'superseded' WHERE id = ?`).run(supersedes);
      }

      added += 1;
      if (occurred && (!latest || occurred > latest)) latest = occurred;
    }

    state.prepare(`UPDATE source_connections SET last_sync_at = ?, updated_at = ? WHERE id = ?`)
      .run(nowIso, nowIso, sourceId);
    state.exec('COMMIT');
  } catch (err) {
    state.exec('ROLLBACK');
    throw err;
  }

  return { documents_added: added, documents_updated: updated, latest_occurred_at: latest, warnings };
}
