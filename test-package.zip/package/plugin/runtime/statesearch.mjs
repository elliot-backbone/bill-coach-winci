// Bill Jennings Coach — search_state / update_state. One FTS-backed search across
// all durable state, and one audited field-level write path. Every update emits a
// role_events row (roles use their own id; other tables log with role_id '*' and a
// namespaced field), so unaudited edits are impossible by construction.

import { randomUUID } from 'node:crypto';

const nowIso = () => new Date().toISOString();

// Tables the two tools may touch. memories/metrics/commitments stay behind
// save_coaching_state (their supersession semantics live there).
export const SEARCHABLE = [
  'roles', 'interactions', 'offers', 'contacts', 'learnings', 'voice_deltas',
  'investor_roster', 'sourcing_runs', 'memories', 'metrics', 'commitments', 'market_deals',
];
export const WRITABLE = new Set(['roles', 'interactions', 'offers', 'contacts', 'investor_roster', 'sourcing_runs']);

// Fields that carry Bill's judgment: never written without his say-so.
// provenance must begin 'bill-said' for these.
const VERDICT_GUARDS = {
  roles: ['bill_fit_json', 'mode', 'lane'],
  offers: ['status'],
};
// Phase changes route through funnel.transitionPhase, never raw update.
const BLOCKED_FIELDS = { roles: ['phase', 'exit_reason', 'exit_by', 'id', 'created_at'], '*': ['id', 'created_at'] };

// ---------------------------------------------------------------------------
// FTS projection

const PROJECTIONS = {
  roles: (r) => [r.company, r.role_shape, r.lane, r.phase, r.source, r.next_action,
    r.thesis_fit_json, r.bill_fit_json, r.their_side_json, r.investor_names_json].join(' \n '),
  interactions: (r) => [r.kind, r.participants_json, r.review_json, r.commitments_theirs_json].join(' \n '),
  offers: (r) => [r.status, r.terms_json, r.benchmark_json].join(' \n '),
  contacts: (r) => [r.name, r.org, r.title, r.relationship, r.via, r.notes].filter(Boolean).join(' \n '),
  learnings: (r) => [r.category, r.learning, r.evidence].filter(Boolean).join(' \n '),
  voice_deltas: (r) => [r.feature, r.rule, r.example].filter(Boolean).join(' \n '),
  investor_roster: (r) => [r.name, r.tier, r.region, r.notes].filter(Boolean).join(' \n '),
  sourcing_runs: (r) => [r.kind, r.scope, r.notes].filter(Boolean).join(' \n '),
};

export function refreshFts(state, tbl, id) {
  const project = PROJECTIONS[tbl];
  if (!project) return;
  const row = state.prepare(`SELECT * FROM ${tbl} WHERE id = ?`).get(id);
  const ref = `${tbl}:${id}`;
  state.prepare('DELETE FROM state_fts WHERE ref = ?').run(ref);
  if (row) state.prepare('INSERT INTO state_fts (ref, tbl, text) VALUES (?, ?, ?)').run(ref, tbl, project(row));
}

export function rebuildStateFts(state) {
  state.exec('DELETE FROM state_fts');
  for (const tbl of Object.keys(PROJECTIONS)) {
    for (const row of state.prepare(`SELECT * FROM ${tbl}`).all()) {
      state.prepare('INSERT INTO state_fts (ref, tbl, text) VALUES (?, ?, ?)')
        .run(`${tbl}:${row.id}`, tbl, PROJECTIONS[tbl](row));
    }
  }
}

// ---------------------------------------------------------------------------
// The single audited write path

export function writeWithEvent(state, tbl, id, fields, { provenance, sessionId, eventType = 'field_update', autonomous = false, note = null, internal = false } = {}) {
  if (!WRITABLE.has(tbl)) throw new Error(`update not permitted on "${tbl}"`);
  if (!provenance) throw new Error('provenance is required on every write');
  const blocked = [...(BLOCKED_FIELDS[tbl] ?? []), ...(BLOCKED_FIELDS['*'] ?? [])];
  const guarded = VERDICT_GUARDS[tbl] ?? [];
  const rejections = [];
  const applied = {};
  for (const [field, value] of Object.entries(fields)) {
    if (blocked.includes(field) && !internal) {
      rejections.push({ field, reason: field === 'phase' ? 'phase moves via the funnel transition (with its evidence guards), not a raw update' : `"${field}" is not writable` });
      continue;
    }
    if (guarded.includes(field) && !String(provenance).startsWith('bill-said') && !internal) {
      rejections.push({ field, reason: `"${field}" carries Bill's judgment — it changes only on his say-so (provenance must begin "bill-said")` });
      continue;
    }
    applied[field] = typeof value === 'object' && value !== null ? JSON.stringify(value) : value;
  }
  const existing = state.prepare(`SELECT * FROM ${tbl} WHERE id = ?`).get(id);
  if (!existing) throw new Error(`unknown ${tbl} row "${id}"`);
  const now = nowIso();
  const events = [];
  const insEvent = state.prepare(`
    INSERT INTO role_events (id, role_id, session_id, event_type, field, old_value, new_value, provenance, autonomous, occurred_at, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  for (const [field, value] of Object.entries(applied)) {
    const oldValue = existing[field];
    if (String(oldValue ?? '') === String(value ?? '')) continue;
    state.prepare(`UPDATE ${tbl} SET ${field} = ?, updated_at = ? WHERE id = ?`).run(value, now, id);
    const roleId = tbl === 'roles' ? id : '*';
    const fieldRef = tbl === 'roles' ? field : `${tbl}:${id}:${field}`;
    insEvent.run(randomUUID(), roleId, sessionId ?? null, eventType, fieldRef,
      oldValue === null || oldValue === undefined ? null : String(oldValue).slice(0, 2000),
      value === null || value === undefined ? null : String(value).slice(0, 2000),
      provenance, autonomous ? 1 : 0, now, now);
    events.push({ field, old: oldValue, new: value });
  }
  if (note) {
    insEvent.run(randomUUID(), tbl === 'roles' ? id : '*', sessionId ?? null, 'note',
      tbl === 'roles' ? null : `${tbl}:${id}`, null, String(note).slice(0, 2000), provenance, autonomous ? 1 : 0, now, now);
  }
  refreshFts(state, tbl, id);
  return { updated: events.length, events, guarded_rejections: rejections };
}

export function createRow(state, tbl, fields, { provenance, sessionId, autonomous = false } = {}) {
  if (!WRITABLE.has(tbl)) throw new Error(`create not permitted on "${tbl}"`);
  if (!provenance) throw new Error('provenance is required on every write');
  const now = nowIso();
  const id = fields.id ?? `${tbl.replace(/s$/, '')}-${randomUUID().slice(0, 8)}`;
  const row = { ...fields, id };
  for (const [k, v] of Object.entries(row)) {
    if (typeof v === 'object' && v !== null) row[k] = JSON.stringify(v);
  }
  const columns = state.prepare(`SELECT name FROM pragma_table_info('${tbl}')`).all().map((r) => r.name);
  if (columns.includes('created_at') && !row.created_at) row.created_at = now;
  if (columns.includes('updated_at') && !row.updated_at) row.updated_at = now;
  if (columns.includes('as_of') && !row.as_of) row.as_of = now;
  if (columns.includes('occurred_at') && !row.occurred_at) row.occurred_at = now;
  if (columns.includes('started_at') && !row.started_at) row.started_at = now;
  if (columns.includes('received_at') && !row.received_at) row.received_at = now;
  const cols = Object.keys(row).filter((c) => columns.includes(c));
  state.prepare(`INSERT INTO ${tbl} (${cols.join(', ')}) VALUES (${cols.map(() => '?').join(', ')})`)
    .run(...cols.map((c) => row[c]));
  state.prepare(`
    INSERT INTO role_events (id, role_id, session_id, event_type, field, old_value, new_value, provenance, autonomous, occurred_at, created_at)
    VALUES (?, ?, ?, 'created', ?, NULL, ?, ?, ?, ?, ?)
  `).run(randomUUID(), tbl === 'roles' ? id : '*', sessionId ?? null,
    tbl === 'roles' ? null : `${tbl}:${id}`, cols.join(','), provenance, autonomous ? 1 : 0, now, now);
  refreshFts(state, tbl, id);
  return { created: `${tbl}:${id}`, id };
}

// ---------------------------------------------------------------------------
// search_state

function ftsEscape(q) {
  // Phrase-quote each term: forgiving of punctuation, no FTS syntax surprises.
  return q.split(/\s+/).filter(Boolean).map((t) => `"${t.replace(/"/g, '')}"`).join(' ');
}

export function searchState(state, library, { query, tables, filters = {}, limit = 20 }) {
  const wanted = (tables && tables.length ? tables : SEARCHABLE).filter((t) => SEARCHABLE.includes(t));
  const results = [];

  // market_deals lives in the library DB
  if (wanted.includes('market_deals') && library) {
    try {
      const rows = library.prepare(`
        SELECT md.rowid AS rid, md.company, md.deal_date, md.vc_round, md.deal_size_musd,
               md.current_employees, md.investors, md.description
        FROM market_deals_fts f JOIN market_deals md ON md.rowid = f.rowid
        WHERE market_deals_fts MATCH ? LIMIT ?
      `).all(ftsEscape(query), Math.min(limit, 15));
      for (const r of rows) {
        results.push({ ref: `market_deals:${r.rid}`, tbl: 'market_deals',
          headline: `${r.company} — ${r.vc_round ?? '?'} ${r.deal_date ?? ''} $${r.deal_size_musd ?? '?'}M, ${r.current_employees || '?'} employees`,
          row: r });
      }
    } catch { /* fts miss tolerated */ }
  }

  // state tables via state_fts
  const stateTables = wanted.filter((t) => t !== 'market_deals' && !['memories', 'metrics', 'commitments'].includes(t));
  if (stateTables.length) {
    let rows = [];
    try {
      rows = state.prepare(`
        SELECT ref, tbl FROM state_fts WHERE state_fts MATCH ? AND tbl IN (${stateTables.map(() => '?').join(',')}) LIMIT ?
      `).all(ftsEscape(query), ...stateTables, limit);
    } catch { rows = []; }
    if (rows.length === 0) {
      // LIKE fallback — the single-substring lesson from the chassis, encoded.
      rows = state.prepare(`
        SELECT ref, tbl FROM state_fts WHERE text LIKE ? AND tbl IN (${stateTables.map(() => '?').join(',')}) LIMIT ?
      `).all(`%${query}%`, ...stateTables, limit);
    }
    for (const { ref, tbl } of rows) {
      const id = ref.slice(tbl.length + 1);
      let row = state.prepare(`SELECT * FROM ${tbl} WHERE id = ?`).get(id);
      if (!row) continue;
      if (!passesFilters(tbl, row, filters)) continue;
      results.push({ ref, tbl, headline: headline(tbl, row), row });
    }
  }

  // memories/metrics/commitments (chassis tables, no id-uniform FTS): LIKE search
  for (const tbl of wanted.filter((t) => ['memories', 'metrics', 'commitments'].includes(t))) {
    const col = tbl === 'memories' ? 'content' : tbl === 'metrics' ? 'name' : 'commitment';
    const rows = state.prepare(`SELECT * FROM ${tbl} WHERE ${col} LIKE ? AND status IN ('active','open') LIMIT 8`)
      .all(`%${query}%`);
    for (const row of rows) {
      results.push({ ref: `${tbl}:${row.id}`, tbl, headline: String(row[col]).slice(0, 140), row });
    }
  }

  return { matches: results.slice(0, limit), total: results.length };
}

function passesFilters(tbl, row, f) {
  if (f.phase && row.phase !== f.phase) return false;
  if (f.lane && row.lane !== f.lane) return false;
  if (f.mode && row.mode !== f.mode) return false;
  if (f.relationship && row.relationship !== f.relationship) return false;
  if (f.category && row.category !== f.category) return false;
  if (f.due_before && !(row.next_action_due && row.next_action_due <= f.due_before)) return false;
  if (f.updated_since && !(row.updated_at && row.updated_at >= f.updated_since)) return false;
  return true;
}

function headline(tbl, row) {
  switch (tbl) {
    case 'roles': return `${row.company} [${row.phase}/${row.lane}/${row.mode}] next: ${row.next_action ?? '—'}`;
    case 'interactions': return `${row.kind} for ${row.role_id} at ${row.occurred_at}`;
    case 'offers': return `offer for ${row.role_id}: ${row.status}`;
    case 'contacts': return `${row.name}${row.org ? ` (${row.org})` : ''} — ${row.relationship}${row.via ? ` via ${row.via}` : ''}`;
    case 'learnings': return `[${row.category}] ${String(row.learning).slice(0, 120)}`;
    case 'voice_deltas': return `[${row.feature}] ${String(row.rule).slice(0, 120)}`;
    case 'investor_roster': return `${row.name} (${row.tier}/${row.region}) ${row.status}`;
    case 'sourcing_runs': return `${row.kind} ${row.started_at}: ${row.candidates_found} candidates`;
    default: return `${tbl}:${row.id}`;
  }
}

export function updateState(state, { target, fields, provenance, as_of, session_id, autonomous = false }) {
  const [tbl, ...rest] = target.split(':');
  const id = rest.join(':');
  if (!tbl || !id) throw new Error('target must be "<table>:<id>" or "<table>:new"');
  if (id === 'new') {
    if (as_of) fields.as_of = as_of;
    return createRow(state, tbl, fields, { provenance, sessionId: session_id, autonomous });
  }
  if (as_of && !fields.as_of) fields.as_of = as_of;
  return writeWithEvent(state, tbl, id, fields, { provenance, sessionId: session_id, autonomous });
}
