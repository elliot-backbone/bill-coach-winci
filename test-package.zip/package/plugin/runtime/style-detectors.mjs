#!/usr/bin/env node
// AUDIENCE: MACHINE
// STYLE DETECTORS · CC-04, PRECONDITION of CC-06. Extracted from style-check.mjs. Design
// section 13 and the adopted JB-1 text name this reuse. The design's own instruction could
// not execute: style-check.mjs exported only checkStyle and selfTest. This module is the fix,
// one compiled detector set shared by the write path and the read path. Holds:
// compile(), proseOnly(), sentencesOf(), the two-register load, and spansOf(), the offset
// locator the read path (CC-06) needs and the write path never did.
import { readFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = dirname(fileURLToPath(import.meta.url));
const REGISTER = join(HERE, '..', 'coach-plugin', 'authorities',
                      'style-prohibition-register.v1.json');
const AW_REGISTER = join(HERE, '..', 'coach-plugin', 'authorities',
                         'ai-writing-signs-register.v1.json');

const spRegister = JSON.parse(readFileSync(REGISTER, 'utf8'));
const awRegister = JSON.parse(readFileSync(AW_REGISTER, 'utf8'));
export const register = {
  ...spRegister,
  rules: [...spRegister.rules, ...awRegister.rules],
  classes: [...spRegister.classes, ...awRegister.classes]
};

/** Build a regex, or return the error. Never swallow: a rule that cannot compile is a defect. */
export function compile(pattern, flags) {
  const wanted = new Set([...(flags ?? ''), 'g', 'u']);   // dedupe, always global + unicode
  try { return { re: new RegExp(pattern, [...wanted].join('')) }; }
  catch (e) { return { error: e.message }; }
}

/**
 * Markdown structure is not prose and must not be scanned as prose.
 *
 * `MEASURED 2026-08-15`: SP-019 counts short verbless sentences, and the splitter breaks on any
 * period. An ordered list therefore contributed one "sentence" per marker — "2.", "3.", "4." —
 * each one token long with no finite verb, so a document was flagged for staccato writing on
 * the strength of having a numbered list in it. Every numbered list would have failed.
 *
 * Stripped before splitting: ordered and bulleted list markers, table rows (a pipe table is
 * data, and its cells are labels rather than sentences), fenced code, heading hashes, and the
 * blockquote marker. This narrows what the rules see to actual prose, which is what they are
 * about. It cannot hide a violation that occurs in prose.
 */
export const proseOnly = (t) => t
  .replace(/```[\s\S]*?```/g, ' ')          // fenced code
  .replace(/^\s*\|.*\|\s*$/gm, ' ')         // table rows, header and separator alike
  .replace(/^\s{0,3}#{1,6}\s+/gm, '')       // heading hashes, keep the heading text
  .replace(/^\s{0,3}>\s?/gm, '')            // blockquote marker
  .replace(/^\s*\d+[.)]\s+/gm, '')          // "1. " ordered-list markers — the false positive
  .replace(/^\s*[-*+]\s+/gm, '');           // bullets

/* SOURCE-CLASS PROSE SURFACE (enforcer gen-35 F-ENF35-style-scope, master dual-agreed
 * 2026-08-21). A source file's prose surface is its COMMENTS and its USER-FACING STRINGS.
 * Executable syntax is not prose and must not be scored as prose, exactly as fenced code
 * blocks are already stripped from markdown above. MEASURED CAUSE: style-check FAILED
 * fleet/shell/rail-feed.mjs on three rules, all three firing on CLI syntax read as English,
 * SP-017b on a usage separator " - ", AW-011 on the POSIX argument form <query>, and AW-017
 * on a complete usage line plus JavaScript.
 *
 * REVERT CONDITION, WRITTEN HERE SO A FUTURE AUTHOR CANNOT LOSE IT: the fixture
 * tools/fixtures/style-source-wrongcase.mjs carries an em dash inside a COMMENT and must
 * continue to FAIL. If it ever passes, this is no longer a scope repair, it has become an
 * exemption, and this change reverts. The em-dash ban and the AI-writing signs are untouched
 * inside comments and user-facing strings; only non-prose spans stop being scored. */
const CLI_SPANS = [
  /(^|\s)--?[A-Za-z][\w-]*/g,        // --sessions, -n
  /<[A-Za-z][\w -]*>/g,               // <query>, the POSIX required-argument form
  /\[[^\]]*\]/g,                      // [--limit N], optional-argument form
  /\s\|\s/g,                          // alternation between flags
];

export const proseOnlySource = (t) => {
  const kept = [];
  /* Block comments, line comments and string literals are the retained surface. Everything
   * outside them is executable syntax and is dropped rather than blanked, so no rule can
   * read a statement as an unfinished sentence. */
  const re = /\/\*[\s\S]*?\*\/|(?:^|\s)\/\/[^\n]*|(?:^|\s)#[^\n]*|'(?:[^'\\\n]|\\.)*'|"(?:[^"\\\n]|\\.)*"|`(?:[^`\\]|\\.)*`/gm;
  let m;
  while ((m = re.exec(t)) !== null) {
    let span = m[0]
      .replace(/^\s*/, '')
      .replace(/^\/\*+/, '').replace(/\*+\/$/, '')
      .replace(/^\/\//, '').replace(/^#/, '')
      .replace(/^\s*\*\s?/gm, '')     // leading stars of a block-comment continuation line
      .replace(/^['"`]/, '').replace(/['"`]$/, '');
    /* A STRING CONTAINING CLI SYNTAX IS INTERFACE TEXT, NOT PROSE, AND IS DROPPED WHOLE
     * rather than stripped and retained. Stripping the spans left residues like
     * "usage: rail-feed.mjs" which AW-017 then read as a sentence stopping mid-way, so the
     * span strip alone moved the false positive rather than ending it. THE TRADEOFF IS
     * STATED, NOT HIDDEN: a user-facing sentence that names a flag is dropped with it. That
     * is accepted because prose needing to name a flag belongs in a comment, which is
     * retained in full, and because the alternative silently scores machine-interface text
     * as English. */
    const isInterface = CLI_SPANS.some((c) => { c.lastIndex = 0; return c.test(span); });
    if (isInterface) continue;
    if (span.trim()) kept.push(span.trim());
  }
  return proseOnly(kept.join('\n'));
};

export const sentencesOf = (t) => proseOnly(t)
  .replace(/\n+/g, ' ')
  .split(/(?<=[.!?])\s+/)
  .map((x) => x.trim())
  .filter(Boolean);

/* OUT-OF-SCOPE, enumerated by rule id rather than left implicit in a kind name, so the
 * exclusion is visible in code and never silent (CC-04, JB-1 v). RE-DERIVED AT BUILD TIME
 * FROM THE REGISTERS (round 2 A9's wrong case 64 names exactly this: a hardcoded list that
 * can drift from the registers must fail the unit; a derived one cannot drift). A rule lands
 * here when its detector has no literal `pattern`/`patterns` a regex can locate in text: the
 * ten STRUCTURAL kinds below score markdown shape or corpus-wide prose rhythm, not a matchable
 * span, so `spansOf` cannot place them for removal from a chat bubble. MEASURED 2026-08-21:
 * every one of the 10 STRUCTURAL-kind rules in the two live registers carries no `pattern` or
 * `patterns` field; every other rule carries at least one. The two sets are therefore already
 * disjoint in the data and this list only names the kinds, never the ids, so it tracks the
 * registers automatically as rules are added or removed.
 */
const STRUCTURAL_KINDS = new Set([
  'adjective_triad', 'fragment_count_max', 'sentence_shape_repeat', 'unterminated_ending',
  'heading_title_case', 'heading_empty_parent', 'heading_level_skip', 'bold_density',
  'break_per_heading', 'length_variance_floor',
]);

const outOfScope = register.rules.filter((r) => STRUCTURAL_KINDS.has(r.detector?.kind));
export const OUT_OF_SCOPE_RULE_IDS = outOfScope.map((r) => r.rule_id);
export const CODIFIED_COUNT = register.rules.length;
export const OUT_OF_SCOPE_COUNT = OUT_OF_SCOPE_RULE_IDS.length;
export const PORTABLE_COUNT = CODIFIED_COUNT - OUT_OF_SCOPE_COUNT;

/**
 * `spansOf(text)` · the read-path adaptation JB-1 ii names. `checkStyle` answers the write
 * path's question ("does this draft violate a rule"; `block` means fail the whole draft) and
 * returns matched strings deduped and capped, with no offsets. The read path (CC-06) needs to
 * excise or dim ONE MATCHED SPAN inside a rendered chat bubble, which is a different question
 * with a different answer shape. This locates every PORTABLE rule's matches in `text` and
 * returns `{ruleId, severity, start, end}` per match; CC-06 decides what each severity does.
 * OUT-OF-SCOPE rules (STRUCTURAL_KINDS) are skipped, by id, not silently: see
 * OUT_OF_SCOPE_RULE_IDS above, which a caller can log or reconcile against CODIFIED_COUNT.
 */
export function spansOf(text) {
  const spans = [];
  for (const rule of register.rules) {
    const d = rule.detector;
    if (!d || OUT_OF_SCOPE_RULE_IDS.includes(rule.rule_id)) continue;
    const patterns = d.patterns ?? (d.pattern ? [d.pattern] : []);
    if (!patterns.length) continue;
    for (const p of patterns) {
      const { re, error } = compile(p, d.flags);
      if (error) continue;   // same "never swallow" law as checkStyle: a broken pattern is
                              // already reported there; spansOf just cannot locate it.
      for (const m of text.matchAll(re)) {
        spans.push({ ruleId: rule.rule_id, severity: rule.severity,
                     start: m.index, end: m.index + m[0].length });
      }
    }
  }
  return spans;
}
