#!/usr/bin/env node
/**
 * F-140 — deterministic style-register checker.
 *
 * check(text, register, ctx) -> Violation[]
 *
 * Implements exactly the detector_kinds documented in
 * style-prohibition-register.v1.json (`detector_kinds`), and the
 * normalisation / segmentation rules documented alongside them. No network,
 * no model call, no npm dependency — this is what R-010 runs at stage 1.
 *
 * Stage-2 rules (severity: "escalate", e.g. uniform_rhythm, congratulation,
 * usefulness_pitch) are candidate detectors only per R12.7: this checker
 * still runs their stage-1 candidate pattern (so callers can see what would
 * be escalated) but NEVER treats an escalate severity as a block. Only
 * severity "block" fails StyleVerdict.v1.
 *
 * Usage:
 *   node check-style-register.js                 # run the built-in PRD anti-example test
 *   node check-style-register.js --file <path>    # check arbitrary text file
 */

'use strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const REGISTER_PATH = path.join(__dirname, '..', 'authorities', 'style-prohibition-register.v1.json');

// ---------------------------------------------------------------------------
// Normalisation (register.normalisation)
// ---------------------------------------------------------------------------
function normalise(text, register) {
  const n = register.normalisation;
  let s = text.normalize(n.unicode_form || 'NFC');
  for (const ch of n.apostrophes.map) s = s.split(ch).join(n.apostrophes.to);
  for (const ch of n.quotes.map) s = s.split(ch).join(n.quotes.to);
  return s;
}

// ---------------------------------------------------------------------------
// Segmentation (register.segmentation)
// ---------------------------------------------------------------------------
function tokenize(str, tokenRegexSrc) {
  const re = new RegExp(tokenRegexSrc, 'gu');
  return str.match(re) || [];
}

function isLetterBearing(str) {
  return /\p{L}/u.test(str);
}

function splitSentences(text, seg) {
  // Split on the sentence_split_regex, keeping track of absolute offsets.
  const splitRe = new RegExp(seg.sentence_split_regex, 'u');
  const rawParts = [];
  let rest = text;
  let base = 0;
  while (true) {
    const m = rest.match(splitRe);
    if (!m) {
      rawParts.push({ text: rest, start: base, end: base + rest.length });
      break;
    }
    const cut = m.index + m[0].length;
    const piece = rest.slice(0, cut);
    rawParts.push({ text: piece, start: base, end: base + cut });
    base += cut;
    rest = rest.slice(cut);
  }

  // Abbreviation guard: if a segment (trimmed of trailing space) ends with a
  // guard string, re-join it with the following segment.
  const guards = seg.abbreviation_guard;
  const merged = [];
  for (const part of rawParts) {
    if (merged.length > 0) {
      const prevTrim = merged[merged.length - 1].text.replace(/\s+$/, '');
      const endsWithGuard = guards.some((g) => prevTrim.toLowerCase().endsWith(g.toLowerCase()));
      if (endsWithGuard) {
        const prev = merged[merged.length - 1];
        prev.text += part.text;
        prev.end = part.end;
        continue;
      }
    }
    merged.push({ text: part.text, start: part.start, end: part.end });
  }
  return merged.filter((p) => p.text.length > 0);
}

function letterBearingSentences(sentences) {
  return sentences.filter((s) => isLetterBearing(s.text));
}

function resolveScopeSpans(scopeName, normText, seg) {
  const sentences = splitSentences(normText, seg);
  switch (scopeName) {
    case 'response':
      return [{ text: normText, start: 0, end: normText.length }];
    case 'sentence':
      return sentences;
    case 'first_sentence': {
      const lb = letterBearingSentences(sentences);
      return lb.length ? [lb[0]] : [];
    }
    case 'last_sentence': {
      const lb = letterBearingSentences(sentences);
      return lb.length ? [lb[lb.length - 1]] : [];
    }
    case 'paragraph': {
      const paras = [];
      const re = /[^\n]*(\n(?!\n)[^\n]*)*/g; // blocks separated by blank line
      let base = 0;
      for (const block of normText.split(/\n\s*\n/)) {
        const start = normText.indexOf(block, base);
        paras.push({ text: block, start, end: start + block.length });
        base = start + block.length;
      }
      return paras;
    }
    default:
      throw new Error(`unknown scope: ${scopeName}`);
  }
}

// ---------------------------------------------------------------------------
// Violation helper
// ---------------------------------------------------------------------------
function makeViolation(rule, span, matchStart, matchEnd, matchedText) {
  return {
    rule_id: rule.rule_id,
    class: rule.class,
    stage: rule.stage,
    severity: rule.severity,
    start: matchStart,
    end: matchEnd,
    matched_text: matchedText,
    sentence_index: span.sentenceIndex !== undefined ? span.sentenceIndex : null,
    message: rule.message,
  };
}

function unlessSuppresses(text, matchStart, matchEnd, unlessPatterns, windowSize) {
  if (!unlessPatterns || unlessPatterns.length === 0) return false;
  const winStart = Math.max(0, matchStart - windowSize);
  const winEnd = Math.min(text.length, matchEnd + windowSize);
  const window = text.slice(winStart, winEnd);
  return unlessPatterns.some((p) => new RegExp(p, 'iu').test(window));
}

// ---------------------------------------------------------------------------
// Detector kind implementations
// ---------------------------------------------------------------------------
function detectRegex(rule, normText, seg) {
  const d = rule.detector;
  const spans = resolveScopeSpans(d.scope, normText, seg);
  const violations = [];
  const unlessWindow = d.unless_window || 24;
  spans.forEach((span, idx) => {
    span.sentenceIndex = d.scope === 'sentence' ? idx : null;
    for (const patSrc of d.patterns) {
      const flags = (d.flags || 'iu').includes('g') ? d.flags : d.flags + 'g';
      const re = new RegExp(patSrc, flags.replace(/g/g, '') + 'g');
      let m;
      while ((m = re.exec(span.text)) !== null) {
        const absStart = span.start + m.index;
        const absEnd = absStart + m[0].length;
        if (!unlessSuppresses(normText, absStart, absEnd, d.unless, unlessWindow)) {
          violations.push(makeViolation(rule, span, absStart, absEnd, m[0]));
        }
        if (m[0].length === 0) re.lastIndex++; // guard against zero-length loops
      }
    }
  });
  return violations;
}

function detectCountMax(rule, normText, seg) {
  const d = rule.detector;
  const spans = resolveScopeSpans(d.scope, normText, seg);
  const violations = [];
  for (const span of spans) {
    const flags = d.flags.includes('g') ? d.flags : d.flags + 'g';
    const re = new RegExp(d.pattern, flags);
    const matches = [];
    let m;
    while ((m = re.exec(span.text)) !== null) {
      matches.push({ start: span.start + m.index, end: span.start + m.index + m[0].length, text: m[0] });
      if (m[0].length === 0) re.lastIndex++;
    }
    if (matches.length > d.max) {
      const nth = matches[d.max]; // (max+1)th match, 0-indexed
      violations.push(makeViolation(rule, span, nth.start, nth.end, nth.text));
    }
  }
  return violations;
}

function detectPerSentenceCountMax(rule, normText, seg) {
  const d = rule.detector;
  const sentences = splitSentences(normText, seg);
  const violations = [];
  sentences.forEach((span, idx) => {
    span.sentenceIndex = idx;
    const flags = d.flags.includes('g') ? d.flags : d.flags + 'g';
    const re = new RegExp(d.pattern, flags);
    const matches = [];
    let m;
    while ((m = re.exec(span.text)) !== null) {
      matches.push({ start: span.start + m.index, end: span.start + m.index + m[0].length, text: m[0] });
      if (m[0].length === 0) re.lastIndex++;
    }
    if (matches.length > d.max) {
      const nth = matches[d.max];
      violations.push(makeViolation(rule, span, nth.start, nth.end, nth.text));
    }
  });
  return violations;
}

function detectFragmentCountMax(rule, normText, seg) {
  const d = rule.detector;
  const sentences = letterBearingSentences(splitSentences(normText, seg));
  const lexicon = new Set(d.finite_verb_lexicon.map((w) => w.toLowerCase()));
  const fragments = [];
  for (const span of sentences) {
    const tokens = tokenize(span.text, seg.word_token_regex);
    if (tokens.length === 0) continue;
    const hasFiniteVerb = tokens.some((t) => lexicon.has(t.toLowerCase()));
    if (tokens.length <= d.max_tokens && !hasFiniteVerb) {
      fragments.push(span);
    }
  }
  const violations = [];
  if (fragments.length > d.max) {
    const nth = fragments[d.max];
    violations.push(makeViolation(rule, nth, nth.start, nth.end, nth.text));
  }
  return violations;
}

function isAdjectival(token, suffixes, lexicon) {
  const low = token.toLowerCase();
  if (lexicon.includes(low)) return true;
  return suffixes.some((suf) => low.endsWith(suf));
}

function detectAdjectiveTriad(rule, normText, seg) {
  const d = rule.detector;
  const sentences = splitSentences(normText, seg);
  const violations = [];
  sentences.forEach((span, idx) => {
    span.sentenceIndex = idx;
    if (d.forbid_if_sentence_matches.some((p) => new RegExp(p, 'u').test(span.text))) return;
    const re = new RegExp(d.candidate_pattern, d.flags);
    let m;
    while ((m = re.exec(span.text)) !== null) {
      const [x, y, z] = [m[1], m[2], m[3]];
      if (
        isAdjectival(x, d.adjective_suffixes, d.adjective_lexicon) &&
        isAdjectival(y, d.adjective_suffixes, d.adjective_lexicon) &&
        isAdjectival(z, d.adjective_suffixes, d.adjective_lexicon)
      ) {
        const absStart = span.start + m.index;
        const absEnd = absStart + m[0].length;
        violations.push(makeViolation(rule, span, absStart, absEnd, m[0]));
      }
      if (m[0].length === 0) re.lastIndex++;
    }
  });
  return violations;
}

function detectShortReplyOpener(rule, normText, seg) {
  const d = rule.detector;
  const words = tokenize(normText, seg.word_token_regex);
  const lbSentences = letterBearingSentences(splitSentences(normText, seg));
  const isShort = words.length <= d.short_reply_max_words || lbSentences.length <= d.short_reply_max_sentences;
  if (!isShort || lbSentences.length === 0) return [];
  const span = lbSentences[0];
  const violations = [];
  for (const patSrc of d.patterns) {
    const flags = d.flags.includes('g') ? d.flags : d.flags + 'g';
    const re = new RegExp(patSrc, flags);
    let m;
    while ((m = re.exec(span.text)) !== null) {
      const absStart = span.start + m.index;
      const absEnd = absStart + m[0].length;
      violations.push(makeViolation(rule, span, absStart, absEnd, m[0]));
      if (m[0].length === 0) re.lastIndex++;
    }
  }
  return violations;
}

function detectSentenceShapeRepeat(rule, normText, seg) {
  // Stage-2 candidate only (R12.7). We still compute a candidate signal so
  // callers can see what would be escalated, but per the register's own
  // description this NEVER blocks on its own.
  const d = rule.detector;
  const sentences = letterBearingSentences(splitSentences(normText, seg));
  const openingClass = (s) => {
    const first = tokenize(s.text, seg.word_token_regex)[0] || '';
    const low = first.toLowerCase();
    if (['a', 'an', 'the'].includes(low)) return 'article';
    if (['i', 'you', 'he', 'she', 'it', 'we', 'they', 'this', 'that', 'these', 'those'].includes(low)) return 'pronoun';
    if (['and', 'but', 'or', 'so', 'because', 'although', 'while'].includes(low)) return 'conjunction';
    return 'other';
  };
  const violations = [];
  for (let i = 0; i + d.run <= sentences.length; i++) {
    const windowSents = sentences.slice(i, i + d.run);
    const counts = windowSents.map((s) => tokenize(s.text, seg.word_token_regex).length);
    const spanLen = Math.max(...counts) - Math.min(...counts);
    const sameOpening = d.compare_opening_class
      ? windowSents.every((s) => openingClass(s) === openingClass(windowSents[0]))
      : true;
    const sameTerminal = d.compare_terminal_punctuation
      ? windowSents.every((s) => {
          const t = s.text.trim();
          return t[t.length - 1] === windowSents[0].text.trim().slice(-1);
        })
      : true;
    if (spanLen <= d.length_tolerance_tokens && sameOpening && sameTerminal) {
      const span = windowSents[0];
      violations.push(makeViolation(rule, span, span.start, windowSents[windowSents.length - 1].end, span.text));
      break; // one candidate signal is enough
    }
  }
  return violations;
}

function detectLexiconRegex(rule, normText, seg, ctx) {
  // lexicon_ref is unresolved at this stage (package-time binding, B-012's
  // job to report). Only the literal `patterns[]` are active, per the
  // register's own note on OP-3.
  const d = rule.detector;
  const spans = resolveScopeSpans(d.scope, normText, seg);
  const violations = [];
  const patterns = [...(d.patterns || [])];
  if (d.lexicon_ref && ctx && ctx.resolvedLexicons && ctx.resolvedLexicons[d.lexicon_ref]) {
    for (const entry of ctx.resolvedLexicons[d.lexicon_ref]) {
      patterns.push(d.lexicon_pattern_template.replace('{{entry}}', entry));
    }
  }
  for (const span of spans) {
    for (const patSrc of patterns) {
      const flags = (d.flags || 'u').includes('g') ? d.flags : d.flags + 'g';
      const re = new RegExp(patSrc, flags);
      let m;
      while ((m = re.exec(span.text)) !== null) {
        const absStart = span.start + m.index;
        const absEnd = absStart + m[0].length;
        violations.push(makeViolation(rule, span, absStart, absEnd, m[0]));
        if (m[0].length === 0) re.lastIndex++;
      }
    }
  }
  return violations;
}

// ---------------------------------------------------------------------------
// Dispatcher — F-140 check(text, register, ctx) -> Violation[]
// ---------------------------------------------------------------------------
function check(text, register, ctx) {
  const seg = register.segmentation;
  const normText = normalise(text, register);
  const violations = [];
  for (const rule of register.rules) {
    const kind = rule.detector.kind;
    let found;
    switch (kind) {
      case 'regex':
        found = detectRegex(rule, normText, seg);
        break;
      case 'count_max':
        found = detectCountMax(rule, normText, seg);
        break;
      case 'per_sentence_count_max':
        found = detectPerSentenceCountMax(rule, normText, seg);
        break;
      case 'fragment_count_max':
        found = detectFragmentCountMax(rule, normText, seg);
        break;
      case 'adjective_triad':
        found = detectAdjectiveTriad(rule, normText, seg);
        break;
      case 'short_reply_opener':
        found = detectShortReplyOpener(rule, normText, seg);
        break;
      case 'sentence_shape_repeat':
        found = detectSentenceShapeRepeat(rule, normText, seg);
        break;
      // The structural detectors return plain strings; the regex path returns violation
      // objects. Wrapping here keeps one shape coming out of check().
      case 'unterminated_ending': found = asViolations(rule, unterminatedEnding(text)); break;
      case 'heading_title_case': found = asViolations(rule, headingTitleCase(text, rule.detector)); break;
      case 'heading_empty_parent': found = asViolations(rule, headingEmptyParent(text)); break;
      case 'heading_level_skip': found = asViolations(rule, headingLevelSkip(text)); break;
      case 'bold_density': found = asViolations(rule, boldDensity(text, rule.detector)); break;
      case 'break_per_heading': found = asViolations(rule, breakPerHeading(text, rule.detector)); break;
      case 'length_variance_floor': found = asViolations(rule, lengthVarianceFloor(text, rule.detector)); break;
      case 'lexicon_regex':
        found = detectLexiconRegex(rule, normText, seg, ctx);
        break;
      default:
        throw new Error(`unknown detector kind: ${kind}`);
    }
    violations.push(...found);
  }
  return violations;
}

export { check, normalise, splitSentences };



// ---------------------------------------------------------------------------
const proseOnly = (t) => t
  .replace(/```[\s\S]*?```/g, ' ')          // fenced code
  .replace(/^\s*\|.*\|\s*$/gm, ' ')         // table rows, header and separator alike
  .replace(/^\s{0,3}#{1,6}\s+/gm, '')       // heading hashes, keep the heading text
  .replace(/^\s{0,3}>\s?/gm, '')            // blockquote marker
  .replace(/^\s*\d+[.)]\s+/gm, '')          // "1. " ordered-list markers — the false positive
  .replace(/^\s*[-*+]\s+/gm, '');           // bullets

/* SOURCE-CLASS PROSE SURFACE (enforcer gen-35 F-ENF35-style-scope, master dual-agreed
 * 2026-08-21). A source file's prose surface is its COMMENTS and its USER-FACING STRINGS.
 * Executable syntax is not prose and must not be scored as prose, exactly as fenced code
 * blocks are already stripped from markdown above. MEASURED CAUSE: style-check FAILED
 * fleet/shell/rail-feed.mjs on three rules, all three firing on CLI syntax read as English,
 * SP-017b on a usage separator " - ", AW-011 on the POSIX argument form <query>, and AW-017
 * on a complete usage line plus JavaScript.
 *
 * REVERT CONDITION, WRITTEN HERE SO A FUTURE AUTHOR CANNOT LOSE IT: the fixture
 * tools/fixtures/style-source-wrongcase.mjs carries an em dash inside a COMMENT and must
 * continue to FAIL. If it ever passes, this is no longer a scope repair, it has become an
 * exemption, and this change reverts. The em-dash ban and the AI-writing signs are untouched
 * inside comments and user-facing strings; only non-prose spans stop being scored. */
const CLI_SPANS = [
  /(^|\s)--?[A-Za-z][\w-]*/g,        // --sessions, -n
  /<[A-Za-z][\w -]*>/g,               // <query>, the POSIX required-argument form
  /\[[^\]]*\]/g,                      // [--limit N], optional-argument form
  /\s\|\s/g,                          // alternation between flags
];

const proseOnlySource = (t) => {
  const kept = [];
  /* Block comments, line comments and string literals are the retained surface. Everything
   * outside them is executable syntax and is dropped rather than blanked, so no rule can
   * read a statement as an unfinished sentence. */
  const re = /\/\*[\s\S]*?\*\/|(?:^|\s)\/\/[^\n]*|(?:^|\s)#[^\n]*|'(?:[^'\\\n]|\\.)*'|"(?:[^"\\\n]|\\.)*"|`(?:[^`\\]|\\.)*`/gm;
  let m;
  while ((m = re.exec(t)) !== null) {
    let span = m[0]
      .replace(/^\s*/, '')
      .replace(/^\/\*+/, '').replace(/\*+\/$/, '')
      .replace(/^\/\//, '').replace(/^#/, '')
      .replace(/^\s*\*\s?/gm, '')     // leading stars of a block-comment continuation line
      .replace(/^['"`]/, '').replace(/['"`]$/, '');
    /* A STRING CONTAINING CLI SYNTAX IS INTERFACE TEXT, NOT PROSE, AND IS DROPPED WHOLE
     * rather than stripped and retained. Stripping the spans left residues like
     * "usage: rail-feed.mjs" which AW-017 then read as a sentence stopping mid-way, so the
     * span strip alone moved the false positive rather than ending it. THE TRADEOFF IS
     * STATED, NOT HIDDEN: a user-facing sentence that names a flag is dropped with it. That
     * is accepted because prose needing to name a flag belongs in a comment, which is
     * retained in full, and because the alternative silently scores machine-interface text
     * as English. */
    const isInterface = CLI_SPANS.some((c) => { c.lastIndex = 0; return c.test(span); });
    if (isInterface) continue;
    if (span.trim()) kept.push(span.trim());
  }
  return proseOnly(kept.join('\n'));
};

const sentencesOf = (t) => proseOnly(t)
  .replace(/\n+/g, ' ')
  .split(/(?<=[.!?])\s+/)
  .map((x) => x.trim())
  .filter(Boolean);

function asViolations(rule, results) {
  return (results ?? []).map((r) => (typeof r === 'string'
    ? { rule_id: rule.rule_id, class: rule.class, severity: rule.severity, matched_text: r, start: 0, end: 0 }
    : r));
}

// Structural detectors for the AI-writing register. The authority declares these
// kinds; without an implementation they read as enforced and are not.

const tokensOf = (s) => s.split(/\s+/).filter(Boolean);

const headingsOf = (text) => [...text.matchAll(/^(#{1,6})\s+(.+?)\s*$/gm)]
  .map((m) => ({ level: m[1].length, text: m[2], index: m.index }));

/** AW-017 · the text stops mid-sentence. */
function unterminatedEnding(text) {
  const t = text.trimEnd();
  if (!t) return [];
  const last = t.split('\n').filter((l) => l.trim()).pop() ?? '';
  /* Strip trailing markdown emphasis and link syntax before judging completeness. A line
   * ending "...it is a defect.*" is a finished sentence inside italics, not a truncation. */
  const line = last.trim().replace(/[*_`~\]\)]+$/, '');
  // Structure is not a sentence and does not need terminal punctuation.
  if (/^[#>|]/.test(line) || /^\s*([-*+]|\d+[.)])\s/.test(line)) return [];
  if (/^```/.test(line) || /^\s*(-{3,}|\*{3,}|_{3,})\s*$/.test(line)) return [];
  if (/[.!?:…"')\]}]$/.test(line)) return [];
  return [line.slice(-60)];
}

/** AW-018 · Title Case headings. Sentence case is the house style. */
function headingTitleCase(text, d) {
  const min = d.min_words ?? 3;
  const out = [];
  for (const h of headingsOf(text)) {
    // Strip markup and anything that is legitimately capitalised: identifiers, acronyms,
    // numbers, and rule ids. Otherwise "E-09 Company Hygiene" scores as Title Case for
    // reasons that have nothing to do with the writing.
    const words = h.text
      .replace(/`[^`]*`/g, '')
      .replace(/[*_]/g, '')
      .split(/[\s·:,-]+/)
      .filter((w) => /^[A-Za-z][a-z]*$/.test(w) || /^[A-Z][a-z]+$/.test(w));
    if (words.length < min) continue;
    const capped = words.filter((w) => /^[A-Z]/.test(w)).length;
    // The first word is capitalised in sentence case too, so it is excluded from the ratio.
    const rest = words.slice(1);
    if (!rest.length) continue;
    const cappedRest = rest.filter((w) => /^[A-Z]/.test(w)).length;
    if (cappedRest / rest.length >= 0.6 && capped >= 2) out.push(h.text);
  }
  return out;
}

/** AW-019 · a heading whose only content is more headings. */
function headingEmptyParent(text) {
  const hs = headingsOf(text);
  const out = [];
  for (let i = 0; i < hs.length - 1; i++) {
    const between = text.slice(hs[i].index + hs[i].text.length, hs[i + 1].index);
    const prose = between.replace(/^#{1,6}.*$/gm, '').replace(/[\s>|*_-]/g, '');
    if (!prose && hs[i + 1].level > hs[i].level) out.push(hs[i].text);
  }
  return out;
}

/** AW-020 · a heading level skipped, e.g. h1 straight to h3. */
function headingLevelSkip(text) {
  const hs = headingsOf(text);
  const out = [];
  for (let i = 1; i < hs.length; i++) {
    if (hs[i].level > hs[i - 1].level + 1) out.push(`h${hs[i - 1].level} -> h${hs[i].level}: ${hs[i].text}`);
  }
  return out;
}

/** AW-022 · what share of the prose is bold. Thresholded, because bold has a real job. */
function boldDensity(text, d) {
  const max = d.max_ratio ?? 0.12;
  const body = text.replace(/```[\s\S]*?```/g, ' ').replace(/^#{1,6}.*$/gm, ' ');
  const total = body.replace(/\s+/g, ' ').trim().length;
  if (total < 400) return [];                       // too short for a ratio to mean anything
  const bold = [...body.matchAll(/\*\*([^*\n]{1,200})\*\*/g)].map((m) => m[1]);
  const bolded = bold.join('').length;
  const ratio = bolded / total;
  return ratio > max
    ? [`${(100 * ratio).toFixed(1)}% of the text is bold (limit ${(100 * max).toFixed(0)}%)`]
    : [];
}

/** AW-021 · thematic breaks as decoration. RELATIVE to headings, because the tell is a rule
 *  under every heading, not a rule existing at all. */
function breakPerHeading(text, d) {
  const min = d.min_breaks ?? 3;
  const breaks = [...text.matchAll(/^\s*(-{3,}|\*{3,}|_{3,})\s*$/gm)].length;
  if (breaks < min) return [];
  const headings = headingsOf(text).length;
  if (headings === 0) return breaks > min ? [`${breaks} horizontal rules and no headings`] : [];
  return breaks >= headings
    ? [`${breaks} horizontal rules against ${headings} headings`]
    : [];
}

/** AW-023 · how much sentence length varies across the whole response.
 *
 *  SP-020 only looks at three neighbours and only nominates a draft for a model pass, so a
 *  response that is uniformly paced end to end can pass it completely. This measures the
 *  response. The THRESHOLD is an open parameter belonging to the operator (AW-OP-1): it is a
 *  definition of how Coach should sound, and no corpus can settle it. In particular it is NOT
 *  taken from Bill's own writing, which describes Bill and prescribes nothing for Coach. */
function lengthVarianceFloor(text, d) {
  const ss = sentencesOf(text).filter((s) => /[A-Za-z]/.test(s) && tokensOf(s).length > 1);
  if (ss.length < (d.min_sentences ?? 12)) return [];
  const L = ss.map((s) => tokensOf(s).length);
  const mean = L.reduce((a, b) => a + b, 0) / L.length;
  if (!mean) return [];
  const sd = Math.sqrt(L.reduce((a, b) => a + (b - mean) ** 2, 0) / L.length);
  const cv = sd / mean;
  const floor = d.min_cv ?? 0.55;
  return cv < floor
    ? [`sentence-length variation ${cv.toFixed(3)}, floor ${floor} (mean ${mean.toFixed(1)} words over ${ss.length} sentences)`]
    : [];
}

// ---------------------------------------------------------------------------
// One entry point over both authorities.
//
// The style register governs Coach's own prose; the AI-writing register extends it
// with the signs catalogued from the Wikipedia page. They share a segmentation and
// a violation shape, so a caller checks a reply once and gets one ranked list.

const SP = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'authorities', 'style-prohibition-register.v1.json'), 'utf8'));
const AW = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'authorities', 'ai-writing-signs-register.v1.json'), 'utf8'));
const MERGED = { ...SP, rules: [...SP.rules, ...AW.rules] };

/** Every violation in one reply, worst first. */
/**
 * SESSION SCOPE. Every detector in the registers scores ONE reply, so a fault that only exists
 * across replies cannot be seen by any of them.
 *
 * MEASURED 2026-08-23 on a live nine-turn interview: five consecutive replies opened with the
 * identical words "Three questions", each carrying exactly three numbered items. The registers
 * returned zero block violations on those nine turns and were right to, reply by reply. The
 * sameness was the whole problem and it lived between the replies, not inside any of them.
 *
 * `priors` is every earlier assistant reply in this session, oldest first.
 */
export function checkSession(draft, priors = []) {
  const found = [];
  const norm = (s) => String(s).trim().toLowerCase().replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim();
  const firstLine = (s) => norm(String(s).trim().split('\n')[0]).slice(0, 40);
  const all = [...priors, draft];

  // 1. The same opening, twice or more.
  const op = firstLine(draft);
  if (op.length >= 10) {
    const same = priors.filter((p) => firstLine(p) === op).length;
    if (same >= 1) {
      found.push({
        rule_id: 'SS-001', class: 'repeated_opening', severity: 'block',
        message: `${same + 1} replies in this session open with the same words: "${String(draft).trim().split('\n')[0].slice(0, 60)}". `
          + 'Open somewhere else: react to what he just said, or ask the question cold with no preamble.',
      });
    }
  }

  // 2. The same structural skeleton every time — a numbered list of the same length, repeatedly.
  const shape = (s) => {
    const n = (String(s).match(/^\s*\d+\.\s/gm) || []).length;
    const b = (String(s).match(/^\s*[-*]\s/gm) || []).length;
    return n ? `numbered:${n}` : (b ? `bulleted:${b}` : 'prose');
  };
  const mine = shape(draft);
  if (mine !== 'prose') {
    const same = priors.filter((p) => shape(p) === mine).length;
    if (same >= 2) {
      found.push({
        rule_id: 'SS-002', class: 'repeated_structure', severity: 'block',
        message: `${same + 1} replies in this session have the identical shape (${mine}). Bill is reading a `
          + 'template. Write this one as plain sentences, or change how many things you put in it.',
      });
    }
  }

  // 3. A phrase of yours becoming a tic across the session.
  const phrases = (s) => {
    const words = norm(s).split(' ');
    const out = new Set();
    for (let i = 0; i + 3 <= words.length; i += 1) out.add(words.slice(i, i + 3).join(' '));
    return out;
  };
  if (priors.length >= 2) {
    const mineP = phrases(draft);
    for (const ph of mineP) {
      if (ph.split(' ').some((w) => w.length < 3)) continue;
      const hits = priors.filter((p) => phrases(p).has(ph)).length;
      if (hits >= 3) {
        found.push({
          rule_id: 'SS-003', class: 'session_tic', severity: 'flag',
          message: `"${ph}" has now appeared in ${hits + 1} replies this session. Say it a different way or not at all.`,
        });
        break;
      }
    }
  }
  return found;
}

// ---------------------------------------------------------------------------
// Voice diversity profile.
//
// Sentence CV alone is a weak proxy for cadence: a draft can alternate two-word and
// forty-word sentences mechanically, or hide ten same-shaped sentences behind one extreme,
// and score as "varied". This profile keeps the raw distributions at four distinct scales and
// combines length with paragraph skeletons, openings and construction. The runtime gate only
// holds when several independent signals agree; one short reply, one tidy paragraph or one
// naturally repeated opening is never enough.

const VOICE_WORD_RE = /[\p{L}\p{N}]+(?:['’][\p{L}\p{N}]+)*/gu;
const voiceWords = (text) => String(text ?? '').match(VOICE_WORD_RE) ?? [];

function voiceProseParagraphs(text) {
  const cleaned = String(text ?? '')
    .replace(/```[\s\S]*?```/g, '\n\n')
    .replace(/^\s*\|.*\|\s*$/gm, '')
    .replace(/^\s{0,3}#{1,6}\s+.*$/gm, '')
    .replace(/^\s*(-{3,}|\*{3,}|_{3,})\s*$/gm, '');
  return cleaned.split(/\n\s*\n/).map((block) => block.split('\n')
    // Lists and tables have useful visual regularity of their own. They remain in response
    // word counts, but do not masquerade as conversational prose for rhythm enforcement.
    .filter((line) => !/^\s*(?:[-*+] |\d+[.)] )/.test(line))
    .map((line) => line.replace(/^\s*>\s?/, '').trim())
    .filter(Boolean)
    .join(' '))
    .filter((block) => voiceWords(block).length >= 3);
}

function voiceSentences(paragraph) {
  return letterBearingSentences(splitSentences(paragraph, SP.segmentation))
    .map((span) => span.text.trim())
    .filter((sentence) => voiceWords(sentence).length >= 2);
}

function voiceClauses(sentence) {
  const pieces = String(sentence).split(
    // A comma before "and" is only a clause boundary when the tail plausibly starts a
    // finite clause. Splitting every comma-and would turn ordinary noun lists into fake
    // clauses and reward the very detector-gaming this profile is meant to resist.
    /(?<=[;:])\s+|,\s+(?=(?:and\s+)?(?:i|you|he|she|it|we|they|this|that|these|those|there)\b)|,\s+(?=(?:because|although|though|while|whereas|unless|if|when|before|after|until|since|but|yet|so)\b)|\s+(?=(?:because|although|though|while|whereas|unless|if|when|before|after|until|since|but|yet|so)\b)/i,
  ).map((piece) => piece.trim()).filter(Boolean);
  const merged = [];
  for (const piece of pieces) {
    if (voiceWords(piece).length < 3 && merged.length) merged[merged.length - 1] += ` ${piece}`;
    else merged.push(piece);
  }
  if (merged.length > 1 && voiceWords(merged[0]).length < 3) {
    merged[1] = `${merged[0]} ${merged[1]}`;
    merged.shift();
  }
  return merged.filter((piece) => voiceWords(piece).length >= 2);
}

const rounded = (value) => (Number.isFinite(value) ? Number(value.toFixed(3)) : null);

function quantile(sorted, q) {
  if (!sorted.length) return null;
  const at = (sorted.length - 1) * q;
  const lo = Math.floor(at); const hi = Math.ceil(at);
  return sorted[lo] + (sorted[hi] - sorted[lo]) * (at - lo);
}

function lengthStats(values) {
  if (!values.length) {
    return { count: 0, min: null, max: null, mean: null, median: null, p25: null, p75: null,
      cv: null, winsorized_cv: null };
  }
  const sorted = [...values].sort((a, b) => a - b);
  const mean = values.reduce((sum, value) => sum + value, 0) / values.length;
  const cvOf = (list) => {
    const m = list.reduce((sum, value) => sum + value, 0) / list.length;
    if (!m) return 0;
    return Math.sqrt(list.reduce((sum, value) => sum + (value - m) ** 2, 0) / list.length) / m;
  };
  const lo = quantile(sorted, 0.15); const hi = quantile(sorted, 0.85);
  const winsorized = values.map((value) => Math.max(lo, Math.min(hi, value)));
  return {
    count: values.length,
    min: sorted[0], max: sorted.at(-1), mean: rounded(mean), median: rounded(quantile(sorted, 0.5)),
    p25: rounded(quantile(sorted, 0.25)), p75: rounded(quantile(sorted, 0.75)),
    cv: rounded(cvOf(values)), winsorized_cv: rounded(cvOf(winsorized)),
  };
}

function countValues(values) {
  const counts = {};
  for (const value of values) counts[value] = (counts[value] ?? 0) + 1;
  return counts;
}

function dominantShare(values) {
  if (!values.length) return 0;
  return Math.max(...Object.values(countValues(values))) / values.length;
}

function uniqueRatio(values) {
  return values.length ? new Set(values).size / values.length : 0;
}

function lengthBand(words) {
  if (words <= 4) return 'tiny';
  if (words <= 10) return 'short';
  if (words <= 20) return 'medium';
  if (words <= 35) return 'long';
  return 'extended';
}

function openingClass(text) {
  const first = (voiceWords(text)[0] ?? '').toLowerCase();
  if (['what', 'why', 'when', 'where', 'who', 'which', 'how'].includes(first)) return 'question-word';
  if (['and', 'but', 'or', 'so', 'because', 'although', 'though', 'while', 'if', 'when', 'yet'].includes(first)) return 'connector';
  if (['i', 'you', 'he', 'she', 'it', 'we', 'they', 'this', 'that', 'these', 'those'].includes(first)) return 'pronoun';
  if (['a', 'an', 'the'].includes(first)) return 'article';
  if (['ask', 'call', 'tell', 'take', 'put', 'keep', 'start', 'stop', 'write', 'send', 'ring',
    'go', 'get', 'make', 'give', 'find', 'look', 'cut', 'fill', 'pick', 'hold', 'run'].includes(first)) return 'imperative';
  return 'other';
}

function sentenceConstruction(sentence, clauseCount) {
  const terminal = sentence.trim().endsWith('?') ? 'question'
    : (sentence.trim().endsWith('!') ? 'exclamation' : 'statement');
  const punctuation = sentence.includes(';') ? 'semicolon'
    : (sentence.includes(':') ? 'colon' : ((sentence.match(/,/g) ?? []).length >= 2 ? 'multi-comma'
      : (sentence.includes(',') ? 'comma' : 'plain')));
  const clauses = clauseCount >= 4 ? '4+' : String(clauseCount);
  return `${terminal}:${openingClass(sentence)}:${punctuation}:${clauses}`;
}

function longestNearEqualRun(values) {
  if (!values.length) return 0;
  let longest = 1; let run = 1;
  for (let i = 1; i < values.length; i += 1) {
    const ratio = Math.max(values[i], values[i - 1]) / Math.max(1, Math.min(values[i], values[i - 1]));
    if (ratio <= 1.25) run += 1;
    else run = 1;
    longest = Math.max(longest, run);
  }
  return longest;
}

function forcedAlternationScore(values) {
  if (values.length < 6) return 0;
  let eligible = 0; let alternating = 0; let previousDirection = 0;
  for (let i = 1; i < values.length; i += 1) {
    const ratio = Math.max(values[i], values[i - 1]) / Math.max(1, Math.min(values[i], values[i - 1]));
    const direction = Math.sign(values[i] - values[i - 1]);
    if (ratio < 2.2 || direction === 0) { previousDirection = direction; continue; }
    eligible += 1;
    if (previousDirection && direction === -previousDirection) alternating += 1;
    previousDirection = direction;
  }
  // Two naturally contrasted sentences are not a pattern. Require both four extreme jumps
  // and density across nearly half the transitions before calling this forced alternation.
  return eligible >= 4 && eligible / (values.length - 1) >= 0.45 ? alternating / eligible : 0;
}

const COUNT_WORDS = '(?:one|two|three|four|five|six|seven|eight|nine|ten|a pair of)';
const COUNT_NOUNS = '(?:things?|points?|questions?|calls?|moves?|changes?|edits?|cuts?|reps?|reasons?|jobs?|roles?|problems?|truths?|parts?|ways?|pieces?|tests?|asks?|notes?|arguments?)';
const COUNT_BUNDLE_RE = new RegExp(`\\b${COUNT_WORDS}\\s+${COUNT_NOUNS}\\b`, 'gi');
const COUNT_OPENING_RE = new RegExp(`^(?:there (?:are|is)\\s+)?${COUNT_WORDS}\\s+${COUNT_NOUNS}\\b`, 'i');
const FUNCTIONAL_LABEL_RE = /^\s*(?:[-*+]\s*)?(?:\*\*)?(yours|mine|on file|the challenge)(?:\*\*)?\s*[:—-]/i;

function proseOpeningPhrase(paragraph, size) {
  return voiceWords(paragraph).slice(0, size).map((word) => word.toLowerCase()).join(' ');
}

function openingFamily(paragraph) {
  const plain = String(paragraph).trim().replace(/^\W+/, '');
  if (COUNT_OPENING_RE.test(plain) || /^rep\s+(?:one|two|three|four|five|six|seven|eight|nine|ten|\d+)\b/i.test(plain)) return 'count-bundle';
  if (/^(?:(?:do not|don['’]t)\s+)?(?:send|ask|answer|call|tell|take|put|keep|start|stop|write|ring|go|get|make|give|find|look|cut|fill|pick|hold|run|paste|park|bring|name|choose|read|bin|draft|use|leave|show|say|reply|record|check|chase|counter|pay|drop|decline|tune)\b/i.test(plain)) {
    return 'direct-command';
  }
  if (/^(?:what|why|when|where|who|which|how)\b/i.test(plain) || /\?\s*$/.test(plain)) return 'question';
  if (/^(?:the case against|rather than|instead of|not\b.{0,50}\bbut\b)/i.test(plain)) return 'binary-reframe';
  const watched = plain.match(/^(now the|one thing|two things|the case|on the|yours|mine|on file|the challenge)\b/i);
  if (watched) return `repeated-label:${watched[1].toLowerCase()}`;
  return openingClass(plain);
}

function scaffoldProfile(text, paragraphs) {
  const source = String(text ?? '');
  const lines = source.split(/\r?\n/);
  const countBundles = source.match(COUNT_BUNDLE_RE) ?? [];
  const numberedStarts = lines.filter((line) => /^\s*(?:[-*+]\s*)?\d+[.)]\s+/.test(line)).length;
  const ratherThanCount = (source.match(/\brather than\b/gi) ?? []).length;
  const caseAgainstCount = (source.match(/\b(?:the )?(?:case|argument) against\b/gi) ?? []).length;
  const notButCount = (source.match(/\bnot\b[^.!?\n]{0,80}\bbut\b/gi) ?? []).length;
  const insteadCount = (source.match(/\binstead(?: of)?\b/gi) ?? []).length;
  const functionalLabels = lines.map((line) => line.match(FUNCTIONAL_LABEL_RE)?.[1]?.toLowerCase())
    .filter(Boolean);
  const openingTwo = paragraphs.map((paragraph) => proseOpeningPhrase(paragraph, 2)).filter(Boolean);
  const openingThree = paragraphs.map((paragraph) => proseOpeningPhrase(paragraph, 3)).filter(Boolean);
  const families = paragraphs.map(openingFamily);
  const commaAndClauseConstructions = (source.match(/,\s+and\s+(?=(?:i|you|he|she|it|we|they|this|that|these|those|there)\b)/gi) ?? []).length;
  return {
    count_bundle_count: countBundles.length + numberedStarts,
    counted_phrase_count: countBundles.length,
    numbered_item_count: numberedStarts,
    rather_than_count: ratherThanCount,
    case_against_count: caseAgainstCount,
    not_but_count: notButCount,
    instead_count: insteadCount,
    binary_signpost_count: ratherThanCount + caseAgainstCount + notButCount + insteadCount,
    paragraph_opening_two: countValues(openingTwo),
    paragraph_opening_three: countValues(openingThree),
    paragraph_opening_families: countValues(families),
    primary_opening_family: families[0] ?? 'none',
    count_or_directive_opening: ['count-bundle', 'direct-command'].includes(families[0]),
    functional_label_counts: countValues(functionalLabels),
    functional_label_total: functionalLabels.length,
    functional_label_unique: new Set(functionalLabels).size,
    comma_and_clause_construction_count: commaAndClauseConstructions,
  };
}

function voiceProfile(text) {
  const paragraphs = voiceProseParagraphs(text);
  const sentencesByParagraph = paragraphs.map(voiceSentences);
  const sentences = sentencesByParagraph.flat();
  const clausesBySentence = sentences.map(voiceClauses);
  const clauses = clausesBySentence.flat();
  const visibleWordCount = voiceWords(text).length;
  const proseWordCount = voiceWords(paragraphs.join(' ')).length;
  const paragraphWords = paragraphs.map((paragraph) => voiceWords(paragraph).length);
  const paragraphSentences = sentencesByParagraph.map((items) => items.length);
  const sentenceWords = sentences.map((sentence) => voiceWords(sentence).length);
  const clauseWords = clauses.map((clause) => voiceWords(clause).length);
  const clausesPerSentence = clausesBySentence.map((items) => items.length || 1);
  const sentenceOpenings = sentences.map(openingClass);
  const sentenceFirstWords = sentences.map((sentence) => (voiceWords(sentence)[0] ?? '').toLowerCase());
  const clauseOpenings = clauses.map(openingClass);
  const constructions = sentences.map((sentence, index) => sentenceConstruction(sentence, clausesPerSentence[index]));
  const paragraphSkeleton = paragraphSentences.map((count) => Math.min(count, 4)).join('-');
  const constructionMode = Object.entries(countValues(constructions)).sort((a, b) => b[1] - a[1])[0]?.[0] ?? 'none';
  const openerMode = Object.entries(countValues(sentenceOpenings)).sort((a, b) => b[1] - a[1])[0]?.[0] ?? 'none';
  const paragraphCountBand = paragraphs.length <= 1 ? 'one' : (paragraphs.length <= 4 ? 'few' : 'many');
  const paragraphSentenceMode = Object.entries(countValues(paragraphSentences.map((count) => Math.min(count, 4))))
    .sort((a, b) => b[1] - a[1])[0]?.[0] ?? 'none';
  const paragraphLengthMode = Object.entries(countValues(paragraphWords.map(lengthBand)))
    .sort((a, b) => b[1] - a[1])[0]?.[0] ?? 'none';
  const paragraphCadence = `${paragraphCountBand}:${paragraphSentenceMode}:${paragraphLengthMode}`;
  const constructionCadence = `${openerMode}:${constructionMode}`;
  const scaffolding = scaffoldProfile(text, paragraphs);
  return {
    response: {
      words: visibleWordCount,
      prose_words: proseWordCount,
      structured_word_ratio: visibleWordCount ? rounded((visibleWordCount - proseWordCount) / visibleWordCount) : 0,
      paragraphs: paragraphs.length,
      sentences: sentences.length,
      clauses: clauses.length,
      length_band: visibleWordCount <= 60 ? 'brief' : (visibleWordCount <= 160 ? 'standard' : (visibleWordCount <= 320 ? 'deep' : 'document')),
      paragraph_skeleton: paragraphSkeleton,
      paragraph_cadence: paragraphCadence,
    },
    paragraph: {
      word_counts: paragraphWords,
      sentence_counts: paragraphSentences,
      word_stats: lengthStats(paragraphWords),
      sentence_count_stats: lengthStats(paragraphSentences),
    },
    sentence: {
      word_counts: sentenceWords,
      stats: lengthStats(sentenceWords),
      length_bands: countValues(sentenceWords.map(lengthBand)),
      band_coverage: new Set(sentenceWords.map(lengthBand)).size,
      longest_near_equal_run: longestNearEqualRun(sentenceWords),
      forced_alternation_score: rounded(forcedAlternationScore(sentenceWords)),
    },
    clause: {
      word_counts: clauseWords,
      clauses_per_sentence: clausesPerSentence,
      stats: lengthStats(clauseWords),
      length_bands: countValues(clauseWords.map(lengthBand)),
      band_coverage: new Set(clauseWords.map(lengthBand)).size,
    },
    construction: {
      sentence_opening_classes: countValues(sentenceOpenings),
      sentence_first_words: countValues(sentenceFirstWords),
      clause_opening_classes: countValues(clauseOpenings),
      sentence_signatures: countValues(constructions),
      opening_class_dominance: rounded(dominantShare(sentenceOpenings)),
      first_word_unique_ratio: rounded(uniqueRatio(sentenceFirstWords)),
      clause_opening_dominance: rounded(dominantShare(clauseOpenings)),
      signature_dominance: rounded(dominantShare(constructions)),
      signature_unique_ratio: rounded(uniqueRatio(constructions)),
      dominant_sentence_signature: constructionMode,
      cadence_signature: constructionCadence,
    },
    scaffolding,
    fingerprint: `${visibleWordCount <= 60 ? 'brief' : (visibleWordCount <= 160 ? 'standard' : (visibleWordCount <= 320 ? 'deep' : 'document'))}`
      + `|p:${paragraphSkeleton || 'none'}|o:${openerMode}|c:${constructionMode}`,
  };
}

/**
 * Quantify cadence at response, paragraph, sentence and clause scales, then return a
 * length-appropriate composite verdict. Raw distributions are deliberately retained for
 * capture audits; callers should never reduce this to one global CV.
 */
export function measureVoiceDiversity(text, { priors = [] } = {}) {
  const profile = voiceProfile(text);
  const priorProfiles = priors.map(voiceProfile);
  const signals = [];
  const add = (id, scale, detail) => signals.push({ id, scale, detail });
  const eligible = profile.response.prose_words >= 90 && profile.response.sentences >= 6;

  if (eligible && profile.paragraph.word_counts.length >= 3
      && profile.paragraph.word_stats.winsorized_cv < 0.28
      && dominantShare(profile.paragraph.sentence_counts) >= 0.67) {
    add('paragraph_length_uniform', 'paragraph',
      `${profile.paragraph.word_counts.length} paragraphs repeat a narrow word/sentence shape`);
  }
  if (eligible && profile.sentence.word_counts.length >= 6
      && ((profile.sentence.stats.winsorized_cv < 0.36 && profile.sentence.band_coverage <= 2)
        || profile.sentence.longest_near_equal_run >= 5)) {
    add('sentence_length_uniform', 'sentence',
      `sentence CV ${profile.sentence.stats.winsorized_cv}; bands ${profile.sentence.band_coverage}; near-equal run ${profile.sentence.longest_near_equal_run}`);
  }
  if (eligible && profile.clause.word_counts.length >= 8
      && profile.clause.stats.winsorized_cv < 0.34 && profile.clause.band_coverage <= 2) {
    add('clause_length_uniform', 'clause',
      `clause CV ${profile.clause.stats.winsorized_cv} across ${profile.clause.word_counts.length} clauses`);
  }
  if (eligible && profile.construction.opening_class_dominance >= 0.75
      && profile.construction.first_word_unique_ratio < 0.5) {
    add('opening_uniform', 'construction',
      `one opening class covers ${Math.round(100 * profile.construction.opening_class_dominance)}% of sentences`);
  }
  if (eligible && profile.construction.signature_dominance >= 0.55
      && profile.construction.signature_unique_ratio < 0.5) {
    add('construction_uniform', 'construction',
      `one sentence construction covers ${Math.round(100 * profile.construction.signature_dominance)}% of sentences`);
  }
  if (eligible && profile.sentence.forced_alternation_score >= 0.7) {
    add('forced_length_alternation', 'sentence',
      `extreme short/long alternation score ${profile.sentence.forced_alternation_score}`);
  }
  const repeatedLabelStanza = profile.scaffolding.functional_label_total >= 8
    && profile.scaffolding.functional_label_unique >= 3
    && profile.scaffolding.functional_label_unique <= 4;
  if (repeatedLabelStanza) {
    add('functional_label_stanza', 'construction',
      `${profile.scaffolding.functional_label_total} repeated Yours/Mine/On file/The challenge labels impose one template`);
  }

  const allProfiles = [...priorProfiles, profile];
  const responseWordCounts = allProfiles.map((item) => item.response.words);
  const responseBands = responseWordCounts.map((words) => words <= 60 ? 'brief'
    : (words <= 160 ? 'standard' : (words <= 320 ? 'deep' : 'document')));
  const paragraphSkeletons = allProfiles.map((item) => item.response.paragraph_skeleton);
  const paragraphCadences = allProfiles.map((item) => item.response.paragraph_cadence);
  const constructionCadences = allProfiles.map((item) => item.construction.cadence_signature);
  const fingerprints = allProfiles.map((item) => item.fingerprint);
  const sessionSignals = [];
  const addSession = (id, detail, strength = 'shape') => sessionSignals.push({ id, scale: 'response', strength, detail });
  const tail = allProfiles.slice(-10);
  const tailResponseWordCounts = tail.map((item) => item.response.prose_words);
  const tailResponseStats = lengthStats(tailResponseWordCounts);
  const tailResponseBands = tailResponseWordCounts.map((words) => words <= 60 ? 'brief'
    : (words <= 160 ? 'standard' : (words <= 320 ? 'deep' : 'document')));
  if (tail.length >= 4) {
    const responseStats = tailResponseStats;
    if (responseStats.winsorized_cv < 0.2 && new Set(tailResponseBands).size <= 2) {
      addSession('response_length_uniform',
        `${tail.length} recent replies have response-length CV ${responseStats.winsorized_cv}`);
    }
  }
  if (allProfiles.length >= 3) {
    const recentPriors = tail.slice(0, -1);
    if (recentPriors.filter((item) => item.response.paragraph_cadence === profile.response.paragraph_cadence).length >= 2) {
      addSession('paragraph_cadence_repeated',
        `paragraph cadence ${profile.response.paragraph_cadence} has appeared at least three times`);
    }
    if (recentPriors.filter((item) => item.construction.cadence_signature === profile.construction.cadence_signature).length >= 2) {
      addSession('construction_scaffold_repeated',
        `construction scaffold ${profile.construction.cadence_signature} has appeared at least three times`);
    }

    // Three templated monologues are already three replies Bill had to sit through. This
    // early composite is deliberately stricter than the ten-reply saturation checks: all
    // three must be substantial, tightly length-locked, open from the same count/command
    // family, and at least two must carry a count or binary signpost.
    const early = tail.slice(-3);
    const earlyWords = early.map((item) => item.response.prose_words);
    const earlyLengthLock = early.every((item) => item.response.prose_words >= 180)
      && lengthStats(earlyWords).cv <= 0.15;
    const earlyOpenings = early.filter((item) => item.scaffolding.count_or_directive_opening).length;
    const earlyScaffolds = early.filter((item) => item.scaffolding.count_bundle_count > 0
      || item.scaffolding.binary_signpost_count > 0).length;
    const earlyScaffoldLock = earlyOpenings === 3 && earlyScaffolds >= 2;
    if (earlyLengthLock) {
      addSession('three_reply_length_lock',
        `three consecutive substantial replies have response-length CV ${lengthStats(earlyWords).cv}`, 'early-composite');
    }
    if (earlyScaffoldLock) {
      addSession('three_reply_scaffold_lock',
        `${earlyOpenings}/3 open with count/command framing and ${earlyScaffolds}/3 carry count or binary scaffolds`, 'early-composite');
    }
  }

  if (tail.length >= 4) {
    const recentFour = tail.slice(-4);
    const counted = recentFour.filter((item) => item.scaffolding.count_bundle_count > 0).length;
    const binary = recentFour.filter((item) => item.scaffolding.binary_signpost_count > 0).length;
    const framedOpenings = recentFour.filter((item) => item.scaffolding.count_or_directive_opening).length;
    if (counted >= 3) {
      addSession('four_reply_count_bundle_lock',
        `${counted}/4 consecutive replies use a counted bundle or numbered scaffold`, 'scaffold-composite');
    }
    if (binary >= 3) {
      addSession('four_reply_binary_reframe_lock',
        `${binary}/4 consecutive replies use rather/instead/not-but/case-against framing`, 'scaffold-composite');
    }
    if (framedOpenings === 4) {
      addSession('four_reply_opening_family_lock',
        '4/4 consecutive replies open with a count bundle or direct command', 'scaffold-composite');
    }
  }

  // Rolling saturation catches a session that is monotonous in practice even when one tiny
  // close or one huge artefact makes whole-session CV look healthy. These signals inspect no
  // more than the latest ten approved replies, so old extremes cannot launder current cadence.
  if (tail.length >= 6) {
    const n = tail.length;
    const deepReplies = tail.filter((item) => item.response.prose_words > 260).length;
    const briefReplies = tail.filter((item) => item.response.prose_words <= 120).length;
    const countedReplies = tail.filter((item) => item.scaffolding.count_bundle_count > 0).length;
    const binaryReplies = tail.filter((item) => item.scaffolding.binary_signpost_count > 0).length;
    const countOrDirectiveReplies = tail.filter((item) => item.scaffolding.count_or_directive_opening).length;
    if (deepReplies >= Math.ceil(n * 0.75) && briefReplies <= 1) {
      addSession('response_depth_saturation',
        `${deepReplies}/${n} recent replies exceed 260 prose words and only ${briefReplies} are 120 words or fewer`, 'saturation');
    }
    if (countedReplies >= Math.ceil(n * 0.7)) {
      addSession('count_bundle_saturation',
        `${countedReplies}/${n} recent replies use a counted bundle or numbered scaffold`, 'saturation');
    }
    if (binaryReplies >= Math.ceil(n * 0.6)) {
      addSession('binary_reframe_saturation',
        `${binaryReplies}/${n} recent replies use rather/instead/not-but/case-against framing`, 'saturation');
    }
    if (countOrDirectiveReplies >= Math.ceil(n * 0.7)) {
      addSession('opening_family_saturation',
        `${countOrDirectiveReplies}/${n} recent replies open with a count bundle or command`, 'saturation');
    }
    const fingerprintCounts = countValues(tail.map((item) => item.fingerprint));
    const fingerprintMode = Object.entries(fingerprintCounts).sort((a, b) => b[1] - a[1])[0];
    if (tailResponseStats.median > 90 && fingerprintMode?.[1] >= Math.ceil(n * 0.7)) {
      addSession('reply_shape_saturation',
        `${fingerprintMode[1]}/${n} recent replies share response/paragraph/construction fingerprint ${fingerprintMode[0]}`, 'saturation');
    }

    const currentPhrases = Object.keys(profile.scaffolding.paragraph_opening_three);
    const repeatedPhrase = currentPhrases.find((phrase) => tail
      .filter((item) => Object.hasOwn(item.scaffolding.paragraph_opening_three, phrase)).length >= 3);
    if (repeatedPhrase) {
      const hits = tail.filter((item) => Object.hasOwn(item.scaffolding.paragraph_opening_three, repeatedPhrase)).length;
      addSession('paragraph_opening_phrase_repeated',
        `paragraphs open "${repeatedPhrase}" in ${hits}/${n} recent replies`);
    }
  }

  const withinLengthScales = new Set(signals
    .filter((signal) => ['paragraph', 'sentence', 'clause'].includes(signal.scale))
    .map((signal) => signal.scale));
  const hasConstructionFailure = signals.some((signal) => signal.scale === 'construction');
  const outlierLaundering = eligible && profile.sentence.longest_near_equal_run >= 8
    && profile.construction.opening_class_dominance >= 0.8
    && profile.construction.signature_dominance >= 0.8
    && profile.construction.first_word_unique_ratio < 0.3;
  const withinHold = repeatedLabelStanza
    || outlierLaundering
    || (eligible && withinLengthScales.size >= 2 && hasConstructionFailure && signals.length >= 3);
  const saturationSignals = sessionSignals.filter((signal) => signal.strength === 'saturation');
  const earlyCompositeSignals = sessionSignals.filter((signal) => signal.strength === 'early-composite');
  const scaffoldCompositeSignals = sessionSignals.filter((signal) => signal.strength === 'scaffold-composite');
  // The axes are independently load-bearing. A healthy-looking reply cannot excuse a rolling
  // session pattern, and varied history cannot excuse a uniformly built reply. Two distinct
  // tail saturations are enough to hold; ordinary short-answer shape similarities only flag.
  const sessionHold = (tail.length >= 3 && earlyCompositeSignals.length >= 2)
    || (tail.length >= 4 && scaffoldCompositeSignals.length >= 2)
    || (tail.length >= 6 && (saturationSignals.length >= 2
      || (saturationSignals.length >= 1 && sessionSignals.length >= 3)));
  const verdict = withinHold || sessionHold ? 'hold'
    : ((signals.length || sessionSignals.length) ? 'flag' : 'pass');
  return {
    ...profile,
    response: {
      ...profile.response,
      session_word_counts: responseWordCounts,
      session_word_stats: lengthStats(responseWordCounts),
      session_length_bands: countValues(responseBands),
      session_paragraph_skeletons: paragraphSkeletons,
      session_paragraph_cadences: paragraphCadences,
      session_construction_cadences: constructionCadences,
      session_fingerprints: fingerprints,
      recent_window_size: tail.length,
      recent_prose_word_counts: tailResponseWordCounts,
      recent_prose_word_stats: tailResponseStats,
    },
    eligible,
    signals,
    session_signals: sessionSignals,
    within_reply: {
      eligible,
      signals,
      verdict: withinHold ? 'hold' : (signals.length ? 'flag' : 'pass'),
    },
    across_session: {
      eligible: tail.length >= 3,
      window_size: tail.length,
      signals: sessionSignals,
      verdict: sessionHold ? 'hold' : (sessionSignals.length ? 'flag' : 'pass'),
    },
    combined_verdict: verdict,
    verdict,
    guidance: verdict === 'hold'
      ? 'Keep every claim, hard truth and needed question. Rebuild the cadence across paragraphs, sentences, clauses and openings without forced alternation or random extremes.'
      : null,
  };
}

export function checkReply(text, ctx = {}) {
  const found = check(text, MERGED, ctx) ?? [];
  const rank = { block: 0, flag: 1 };
  return [...found].sort((a, b) => (rank[a.severity] ?? 2) - (rank[b.severity] ?? 2));
}

export const STYLE_RULE_COUNT = MERGED.rules.length;
