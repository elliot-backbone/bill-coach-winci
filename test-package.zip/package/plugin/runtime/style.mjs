#!/usr/bin/env node
/**
 * F-140 — deterministic style-register checker.
 *
 * check(text, register, ctx) -> Violation[]
 *
 * Implements exactly the detector_kinds documented in
 * style-prohibition-register.v1.json (`detector_kinds`), and the
 * normalisation / segmentation rules documented alongside them. No network,
 * no model call, no npm dependency — this is what R-010 runs at stage 1.
 *
 * Stage-2 rules (severity: "escalate", e.g. uniform_rhythm, congratulation,
 * usefulness_pitch) are candidate detectors only per R12.7: this checker
 * still runs their stage-1 candidate pattern (so callers can see what would
 * be escalated) but NEVER treats an escalate severity as a block. Only
 * severity "block" fails StyleVerdict.v1.
 *
 * Usage:
 *   node check-style-register.js                 # run the built-in PRD anti-example test
 *   node check-style-register.js --file <path>    # check arbitrary text file
 */

'use strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const REGISTER_PATH = path.join(__dirname, '..', 'authorities', 'style-prohibition-register.v1.json');

// ---------------------------------------------------------------------------
// Normalisation (register.normalisation)
// ---------------------------------------------------------------------------
function normalise(text, register) {
  const n = register.normalisation;
  let s = text.normalize(n.unicode_form || 'NFC');
  for (const ch of n.apostrophes.map) s = s.split(ch).join(n.apostrophes.to);
  for (const ch of n.quotes.map) s = s.split(ch).join(n.quotes.to);
  return s;
}

// ---------------------------------------------------------------------------
// Segmentation (register.segmentation)
// ---------------------------------------------------------------------------
function tokenize(str, tokenRegexSrc) {
  const re = new RegExp(tokenRegexSrc, 'gu');
  return str.match(re) || [];
}

function isLetterBearing(str) {
  return /\p{L}/u.test(str);
}

function splitSentences(text, seg) {
  // Split on the sentence_split_regex, keeping track of absolute offsets.
  const splitRe = new RegExp(seg.sentence_split_regex, 'u');
  const rawParts = [];
  let rest = text;
  let base = 0;
  while (true) {
    const m = rest.match(splitRe);
    if (!m) {
      rawParts.push({ text: rest, start: base, end: base + rest.length });
      break;
    }
    const cut = m.index + m[0].length;
    const piece = rest.slice(0, cut);
    rawParts.push({ text: piece, start: base, end: base + cut });
    base += cut;
    rest = rest.slice(cut);
  }

  // Abbreviation guard: if a segment (trimmed of trailing space) ends with a
  // guard string, re-join it with the following segment.
  const guards = seg.abbreviation_guard;
  const merged = [];
  for (const part of rawParts) {
    if (merged.length > 0) {
      const prevTrim = merged[merged.length - 1].text.replace(/\s+$/, '');
      const endsWithGuard = guards.some((g) => prevTrim.toLowerCase().endsWith(g.toLowerCase()));
      if (endsWithGuard) {
        const prev = merged[merged.length - 1];
        prev.text += part.text;
        prev.end = part.end;
        continue;
      }
    }
    merged.push({ text: part.text, start: part.start, end: part.end });
  }
  return merged.filter((p) => p.text.length > 0);
}

function letterBearingSentences(sentences) {
  return sentences.filter((s) => isLetterBearing(s.text));
}

function resolveScopeSpans(scopeName, normText, seg) {
  const sentences = splitSentences(normText, seg);
  switch (scopeName) {
    case 'response':
      return [{ text: normText, start: 0, end: normText.length }];
    case 'sentence':
      return sentences;
    case 'first_sentence': {
      const lb = letterBearingSentences(sentences);
      return lb.length ? [lb[0]] : [];
    }
    case 'last_sentence': {
      const lb = letterBearingSentences(sentences);
      return lb.length ? [lb[lb.length - 1]] : [];
    }
    case 'paragraph': {
      const paras = [];
      const re = /[^\n]*(\n(?!\n)[^\n]*)*/g; // blocks separated by blank line
      let base = 0;
      for (const block of normText.split(/\n\s*\n/)) {
        const start = normText.indexOf(block, base);
        paras.push({ text: block, start, end: start + block.length });
        base = start + block.length;
      }
      return paras;
    }
    default:
      throw new Error(`unknown scope: ${scopeName}`);
  }
}

// ---------------------------------------------------------------------------
// Violation helper
// ---------------------------------------------------------------------------
function makeViolation(rule, span, matchStart, matchEnd, matchedText) {
  return {
    rule_id: rule.rule_id,
    class: rule.class,
    stage: rule.stage,
    severity: rule.severity,
    start: matchStart,
    end: matchEnd,
    matched_text: matchedText,
    sentence_index: span.sentenceIndex !== undefined ? span.sentenceIndex : null,
    message: rule.message,
  };
}

function unlessSuppresses(text, matchStart, matchEnd, unlessPatterns, windowSize) {
  if (!unlessPatterns || unlessPatterns.length === 0) return false;
  const winStart = Math.max(0, matchStart - windowSize);
  const winEnd = Math.min(text.length, matchEnd + windowSize);
  const window = text.slice(winStart, winEnd);
  return unlessPatterns.some((p) => new RegExp(p, 'iu').test(window));
}

// ---------------------------------------------------------------------------
// Detector kind implementations
// ---------------------------------------------------------------------------
function detectRegex(rule, normText, seg) {
  const d = rule.detector;
  const spans = resolveScopeSpans(d.scope, normText, seg);
  const violations = [];
  const unlessWindow = d.unless_window || 24;
  spans.forEach((span, idx) => {
    span.sentenceIndex = d.scope === 'sentence' ? idx : null;
    for (const patSrc of d.patterns) {
      const flags = (d.flags || 'iu').includes('g') ? d.flags : d.flags + 'g';
      const re = new RegExp(patSrc, flags.replace(/g/g, '') + 'g');
      let m;
      while ((m = re.exec(span.text)) !== null) {
        const absStart = span.start + m.index;
        const absEnd = absStart + m[0].length;
        if (!unlessSuppresses(normText, absStart, absEnd, d.unless, unlessWindow)) {
          violations.push(makeViolation(rule, span, absStart, absEnd, m[0]));
        }
        if (m[0].length === 0) re.lastIndex++; // guard against zero-length loops
      }
    }
  });
  return violations;
}

function detectCountMax(rule, normText, seg) {
  const d = rule.detector;
  const spans = resolveScopeSpans(d.scope, normText, seg);
  const violations = [];
  for (const span of spans) {
    const flags = d.flags.includes('g') ? d.flags : d.flags + 'g';
    const re = new RegExp(d.pattern, flags);
    const matches = [];
    let m;
    while ((m = re.exec(span.text)) !== null) {
      matches.push({ start: span.start + m.index, end: span.start + m.index + m[0].length, text: m[0] });
      if (m[0].length === 0) re.lastIndex++;
    }
    if (matches.length > d.max) {
      const nth = matches[d.max]; // (max+1)th match, 0-indexed
      violations.push(makeViolation(rule, span, nth.start, nth.end, nth.text));
    }
  }
  return violations;
}

function detectPerSentenceCountMax(rule, normText, seg) {
  const d = rule.detector;
  const sentences = splitSentences(normText, seg);
  const violations = [];
  sentences.forEach((span, idx) => {
    span.sentenceIndex = idx;
    const flags = d.flags.includes('g') ? d.flags : d.flags + 'g';
    const re = new RegExp(d.pattern, flags);
    const matches = [];
    let m;
    while ((m = re.exec(span.text)) !== null) {
      matches.push({ start: span.start + m.index, end: span.start + m.index + m[0].length, text: m[0] });
      if (m[0].length === 0) re.lastIndex++;
    }
    if (matches.length > d.max) {
      const nth = matches[d.max];
      violations.push(makeViolation(rule, span, nth.start, nth.end, nth.text));
    }
  });
  return violations;
}

function detectFragmentCountMax(rule, normText, seg) {
  const d = rule.detector;
  const sentences = letterBearingSentences(splitSentences(normText, seg));
  const lexicon = new Set(d.finite_verb_lexicon.map((w) => w.toLowerCase()));
  const fragments = [];
  for (const span of sentences) {
    const tokens = tokenize(span.text, seg.word_token_regex);
    if (tokens.length === 0) continue;
    const hasFiniteVerb = tokens.some((t) => lexicon.has(t.toLowerCase()));
    if (tokens.length <= d.max_tokens && !hasFiniteVerb) {
      fragments.push(span);
    }
  }
  const violations = [];
  if (fragments.length > d.max) {
    const nth = fragments[d.max];
    violations.push(makeViolation(rule, nth, nth.start, nth.end, nth.text));
  }
  return violations;
}

function isAdjectival(token, suffixes, lexicon) {
  const low = token.toLowerCase();
  if (lexicon.includes(low)) return true;
  return suffixes.some((suf) => low.endsWith(suf));
}

function detectAdjectiveTriad(rule, normText, seg) {
  const d = rule.detector;
  const sentences = splitSentences(normText, seg);
  const violations = [];
  sentences.forEach((span, idx) => {
    span.sentenceIndex = idx;
    if (d.forbid_if_sentence_matches.some((p) => new RegExp(p, 'u').test(span.text))) return;
    const re = new RegExp(d.candidate_pattern, d.flags);
    let m;
    while ((m = re.exec(span.text)) !== null) {
      const [x, y, z] = [m[1], m[2], m[3]];
      if (
        isAdjectival(x, d.adjective_suffixes, d.adjective_lexicon) &&
        isAdjectival(y, d.adjective_suffixes, d.adjective_lexicon) &&
        isAdjectival(z, d.adjective_suffixes, d.adjective_lexicon)
      ) {
        const absStart = span.start + m.index;
        const absEnd = absStart + m[0].length;
        violations.push(makeViolation(rule, span, absStart, absEnd, m[0]));
      }
      if (m[0].length === 0) re.lastIndex++;
    }
  });
  return violations;
}

function detectShortReplyOpener(rule, normText, seg) {
  const d = rule.detector;
  const words = tokenize(normText, seg.word_token_regex);
  const lbSentences = letterBearingSentences(splitSentences(normText, seg));
  const isShort = words.length <= d.short_reply_max_words || lbSentences.length <= d.short_reply_max_sentences;
  if (!isShort || lbSentences.length === 0) return [];
  const span = lbSentences[0];
  const violations = [];
  for (const patSrc of d.patterns) {
    const flags = d.flags.includes('g') ? d.flags : d.flags + 'g';
    const re = new RegExp(patSrc, flags);
    let m;
    while ((m = re.exec(span.text)) !== null) {
      const absStart = span.start + m.index;
      const absEnd = absStart + m[0].length;
      violations.push(makeViolation(rule, span, absStart, absEnd, m[0]));
      if (m[0].length === 0) re.lastIndex++;
    }
  }
  return violations;
}

function detectSentenceShapeRepeat(rule, normText, seg) {
  // Stage-2 candidate only (R12.7). We still compute a candidate signal so
  // callers can see what would be escalated, but per the register's own
  // description this NEVER blocks on its own.
  const d = rule.detector;
  const sentences = letterBearingSentences(splitSentences(normText, seg));
  const openingClass = (s) => {
    const first = tokenize(s.text, seg.word_token_regex)[0] || '';
    const low = first.toLowerCase();
    if (['a', 'an', 'the'].includes(low)) return 'article';
    if (['i', 'you', 'he', 'she', 'it', 'we', 'they', 'this', 'that', 'these', 'those'].includes(low)) return 'pronoun';
    if (['and', 'but', 'or', 'so', 'because', 'although', 'while'].includes(low)) return 'conjunction';
    return 'other';
  };
  const violations = [];
  for (let i = 0; i + d.run <= sentences.length; i++) {
    const windowSents = sentences.slice(i, i + d.run);
    const counts = windowSents.map((s) => tokenize(s.text, seg.word_token_regex).length);
    const spanLen = Math.max(...counts) - Math.min(...counts);
    const sameOpening = d.compare_opening_class
      ? windowSents.every((s) => openingClass(s) === openingClass(windowSents[0]))
      : true;
    const sameTerminal = d.compare_terminal_punctuation
      ? windowSents.every((s) => {
          const t = s.text.trim();
          return t[t.length - 1] === windowSents[0].text.trim().slice(-1);
        })
      : true;
    if (spanLen <= d.length_tolerance_tokens && sameOpening && sameTerminal) {
      const span = windowSents[0];
      violations.push(makeViolation(rule, span, span.start, windowSents[windowSents.length - 1].end, span.text));
      break; // one candidate signal is enough
    }
  }
  return violations;
}

function detectLexiconRegex(rule, normText, seg, ctx) {
  // lexicon_ref is unresolved at this stage (package-time binding, B-012's
  // job to report). Only the literal `patterns[]` are active, per the
  // register's own note on OP-3.
  const d = rule.detector;
  const spans = resolveScopeSpans(d.scope, normText, seg);
  const violations = [];
  const patterns = [...(d.patterns || [])];
  if (d.lexicon_ref && ctx && ctx.resolvedLexicons && ctx.resolvedLexicons[d.lexicon_ref]) {
    for (const entry of ctx.resolvedLexicons[d.lexicon_ref]) {
      patterns.push(d.lexicon_pattern_template.replace('{{entry}}', entry));
    }
  }
  for (const span of spans) {
    for (const patSrc of patterns) {
      const flags = (d.flags || 'u').includes('g') ? d.flags : d.flags + 'g';
      const re = new RegExp(patSrc, flags);
      let m;
      while ((m = re.exec(span.text)) !== null) {
        const absStart = span.start + m.index;
        const absEnd = absStart + m[0].length;
        violations.push(makeViolation(rule, span, absStart, absEnd, m[0]));
        if (m[0].length === 0) re.lastIndex++;
      }
    }
  }
  return violations;
}

// ---------------------------------------------------------------------------
// Dispatcher — F-140 check(text, register, ctx) -> Violation[]
// ---------------------------------------------------------------------------
function check(text, register, ctx) {
  const seg = register.segmentation;
  const normText = normalise(text, register);
  const violations = [];
  for (const rule of register.rules) {
    const kind = rule.detector.kind;
    let found;
    switch (kind) {
      case 'regex':
        found = detectRegex(rule, normText, seg);
        break;
      case 'count_max':
        found = detectCountMax(rule, normText, seg);
        break;
      case 'per_sentence_count_max':
        found = detectPerSentenceCountMax(rule, normText, seg);
        break;
      case 'fragment_count_max':
        found = detectFragmentCountMax(rule, normText, seg);
        break;
      case 'adjective_triad':
        found = detectAdjectiveTriad(rule, normText, seg);
        break;
      case 'short_reply_opener':
        found = detectShortReplyOpener(rule, normText, seg);
        break;
      case 'sentence_shape_repeat':
        found = detectSentenceShapeRepeat(rule, normText, seg);
        break;
      // The structural detectors return plain strings; the regex path returns violation
      // objects. Wrapping here keeps one shape coming out of check().
      case 'unterminated_ending': found = asViolations(rule, unterminatedEnding(text)); break;
      case 'heading_title_case': found = asViolations(rule, headingTitleCase(text, rule.detector)); break;
      case 'heading_empty_parent': found = asViolations(rule, headingEmptyParent(text)); break;
      case 'heading_level_skip': found = asViolations(rule, headingLevelSkip(text)); break;
      case 'bold_density': found = asViolations(rule, boldDensity(text, rule.detector)); break;
      case 'break_per_heading': found = asViolations(rule, breakPerHeading(text, rule.detector)); break;
      case 'length_variance_floor': found = asViolations(rule, lengthVarianceFloor(text, rule.detector)); break;
      case 'lexicon_regex':
        found = detectLexiconRegex(rule, normText, seg, ctx);
        break;
      default:
        throw new Error(`unknown detector kind: ${kind}`);
    }
    violations.push(...found);
  }
  return violations;
}

export { check, normalise, splitSentences };



// ---------------------------------------------------------------------------
const proseOnly = (t) => t
  .replace(/```[\s\S]*?```/g, ' ')          // fenced code
  .replace(/^\s*\|.*\|\s*$/gm, ' ')         // table rows, header and separator alike
  .replace(/^\s{0,3}#{1,6}\s+/gm, '')       // heading hashes, keep the heading text
  .replace(/^\s{0,3}>\s?/gm, '')            // blockquote marker
  .replace(/^\s*\d+[.)]\s+/gm, '')          // "1. " ordered-list markers — the false positive
  .replace(/^\s*[-*+]\s+/gm, '');           // bullets

/* SOURCE-CLASS PROSE SURFACE (enforcer gen-35 F-ENF35-style-scope, master dual-agreed
 * 2026-08-21). A source file's prose surface is its COMMENTS and its USER-FACING STRINGS.
 * Executable syntax is not prose and must not be scored as prose, exactly as fenced code
 * blocks are already stripped from markdown above. MEASURED CAUSE: style-check FAILED
 * fleet/shell/rail-feed.mjs on three rules, all three firing on CLI syntax read as English,
 * SP-017b on a usage separator " - ", AW-011 on the POSIX argument form <query>, and AW-017
 * on a complete usage line plus JavaScript.
 *
 * REVERT CONDITION, WRITTEN HERE SO A FUTURE AUTHOR CANNOT LOSE IT: the fixture
 * tools/fixtures/style-source-wrongcase.mjs carries an em dash inside a COMMENT and must
 * continue to FAIL. If it ever passes, this is no longer a scope repair, it has become an
 * exemption, and this change reverts. The em-dash ban and the AI-writing signs are untouched
 * inside comments and user-facing strings; only non-prose spans stop being scored. */
const CLI_SPANS = [
  /(^|\s)--?[A-Za-z][\w-]*/g,        // --sessions, -n
  /<[A-Za-z][\w -]*>/g,               // <query>, the POSIX required-argument form
  /\[[^\]]*\]/g,                      // [--limit N], optional-argument form
  /\s\|\s/g,                          // alternation between flags
];

const proseOnlySource = (t) => {
  const kept = [];
  /* Block comments, line comments and string literals are the retained surface. Everything
   * outside them is executable syntax and is dropped rather than blanked, so no rule can
   * read a statement as an unfinished sentence. */
  const re = /\/\*[\s\S]*?\*\/|(?:^|\s)\/\/[^\n]*|(?:^|\s)#[^\n]*|'(?:[^'\\\n]|\\.)*'|"(?:[^"\\\n]|\\.)*"|`(?:[^`\\]|\\.)*`/gm;
  let m;
  while ((m = re.exec(t)) !== null) {
    let span = m[0]
      .replace(/^\s*/, '')
      .replace(/^\/\*+/, '').replace(/\*+\/$/, '')
      .replace(/^\/\//, '').replace(/^#/, '')
      .replace(/^\s*\*\s?/gm, '')     // leading stars of a block-comment continuation line
      .replace(/^['"`]/, '').replace(/['"`]$/, '');
    /* A STRING CONTAINING CLI SYNTAX IS INTERFACE TEXT, NOT PROSE, AND IS DROPPED WHOLE
     * rather than stripped and retained. Stripping the spans left residues like
     * "usage: rail-feed.mjs" which AW-017 then read as a sentence stopping mid-way, so the
     * span strip alone moved the false positive rather than ending it. THE TRADEOFF IS
     * STATED, NOT HIDDEN: a user-facing sentence that names a flag is dropped with it. That
     * is accepted because prose needing to name a flag belongs in a comment, which is
     * retained in full, and because the alternative silently scores machine-interface text
     * as English. */
    const isInterface = CLI_SPANS.some((c) => { c.lastIndex = 0; return c.test(span); });
    if (isInterface) continue;
    if (span.trim()) kept.push(span.trim());
  }
  return proseOnly(kept.join('\n'));
};

const sentencesOf = (t) => proseOnly(t)
  .replace(/\n+/g, ' ')
  .split(/(?<=[.!?])\s+/)
  .map((x) => x.trim())
  .filter(Boolean);

function asViolations(rule, results) {
  return (results ?? []).map((r) => (typeof r === 'string'
    ? { rule_id: rule.rule_id, class: rule.class, severity: rule.severity, matched_text: r, start: 0, end: 0 }
    : r));
}

// Structural detectors for the AI-writing register. The authority declares these
// kinds; without an implementation they read as enforced and are not.

const tokensOf = (s) => s.split(/\s+/).filter(Boolean);

const headingsOf = (text) => [...text.matchAll(/^(#{1,6})\s+(.+?)\s*$/gm)]
  .map((m) => ({ level: m[1].length, text: m[2], index: m.index }));

/** AW-017 · the text stops mid-sentence. */
function unterminatedEnding(text) {
  const t = text.trimEnd();
  if (!t) return [];
  const last = t.split('\n').filter((l) => l.trim()).pop() ?? '';
  /* Strip trailing markdown emphasis and link syntax before judging completeness. A line
   * ending "...it is a defect.*" is a finished sentence inside italics, not a truncation. */
  const line = last.trim().replace(/[*_`~\]\)]+$/, '');
  // Structure is not a sentence and does not need terminal punctuation.
  if (/^[#>|]/.test(line) || /^\s*([-*+]|\d+[.)])\s/.test(line)) return [];
  if (/^```/.test(line) || /^\s*(-{3,}|\*{3,}|_{3,})\s*$/.test(line)) return [];
  if (/[.!?:…"')\]}]$/.test(line)) return [];
  return [line.slice(-60)];
}

/** AW-018 · Title Case headings. Sentence case is the house style. */
function headingTitleCase(text, d) {
  const min = d.min_words ?? 3;
  const out = [];
  for (const h of headingsOf(text)) {
    // Strip markup and anything that is legitimately capitalised: identifiers, acronyms,
    // numbers, and rule ids. Otherwise "E-09 Company Hygiene" scores as Title Case for
    // reasons that have nothing to do with the writing.
    const words = h.text
      .replace(/`[^`]*`/g, '')
      .replace(/[*_]/g, '')
      .split(/[\s·:,-]+/)
      .filter((w) => /^[A-Za-z][a-z]*$/.test(w) || /^[A-Z][a-z]+$/.test(w));
    if (words.length < min) continue;
    const capped = words.filter((w) => /^[A-Z]/.test(w)).length;
    // The first word is capitalised in sentence case too, so it is excluded from the ratio.
    const rest = words.slice(1);
    if (!rest.length) continue;
    const cappedRest = rest.filter((w) => /^[A-Z]/.test(w)).length;
    if (cappedRest / rest.length >= 0.6 && capped >= 2) out.push(h.text);
  }
  return out;
}

/** AW-019 · a heading whose only content is more headings. */
function headingEmptyParent(text) {
  const hs = headingsOf(text);
  const out = [];
  for (let i = 0; i < hs.length - 1; i++) {
    const between = text.slice(hs[i].index + hs[i].text.length, hs[i + 1].index);
    const prose = between.replace(/^#{1,6}.*$/gm, '').replace(/[\s>|*_-]/g, '');
    if (!prose && hs[i + 1].level > hs[i].level) out.push(hs[i].text);
  }
  return out;
}

/** AW-020 · a heading level skipped, e.g. h1 straight to h3. */
function headingLevelSkip(text) {
  const hs = headingsOf(text);
  const out = [];
  for (let i = 1; i < hs.length; i++) {
    if (hs[i].level > hs[i - 1].level + 1) out.push(`h${hs[i - 1].level} -> h${hs[i].level}: ${hs[i].text}`);
  }
  return out;
}

/** AW-022 · what share of the prose is bold. Thresholded, because bold has a real job. */
function boldDensity(text, d) {
  const max = d.max_ratio ?? 0.12;
  const body = text.replace(/```[\s\S]*?```/g, ' ').replace(/^#{1,6}.*$/gm, ' ');
  const total = body.replace(/\s+/g, ' ').trim().length;
  if (total < 400) return [];                       // too short for a ratio to mean anything
  const bold = [...body.matchAll(/\*\*([^*\n]{1,200})\*\*/g)].map((m) => m[1]);
  const bolded = bold.join('').length;
  const ratio = bolded / total;
  return ratio > max
    ? [`${(100 * ratio).toFixed(1)}% of the text is bold (limit ${(100 * max).toFixed(0)}%)`]
    : [];
}

/** AW-021 · thematic breaks as decoration. RELATIVE to headings, because the tell is a rule
 *  under every heading, not a rule existing at all. */
function breakPerHeading(text, d) {
  const min = d.min_breaks ?? 3;
  const breaks = [...text.matchAll(/^\s*(-{3,}|\*{3,}|_{3,})\s*$/gm)].length;
  if (breaks < min) return [];
  const headings = headingsOf(text).length;
  if (headings === 0) return breaks > min ? [`${breaks} horizontal rules and no headings`] : [];
  return breaks >= headings
    ? [`${breaks} horizontal rules against ${headings} headings`]
    : [];
}

/** AW-023 · how much sentence length varies across the whole response.
 *
 *  SP-020 only looks at three neighbours and only nominates a draft for a model pass, so a
 *  response that is uniformly paced end to end can pass it completely. This measures the
 *  response. The THRESHOLD is an open parameter belonging to the operator (AW-OP-1): it is a
 *  definition of how Coach should sound, and no corpus can settle it. In particular it is NOT
 *  taken from Dan's own writing, which describes Dan and prescribes nothing for Coach. */
function lengthVarianceFloor(text, d) {
  const ss = sentencesOf(text).filter((s) => /[A-Za-z]/.test(s) && tokensOf(s).length > 1);
  if (ss.length < (d.min_sentences ?? 12)) return [];
  const L = ss.map((s) => tokensOf(s).length);
  const mean = L.reduce((a, b) => a + b, 0) / L.length;
  if (!mean) return [];
  const sd = Math.sqrt(L.reduce((a, b) => a + (b - mean) ** 2, 0) / L.length);
  const cv = sd / mean;
  const floor = d.min_cv ?? 0.55;
  return cv < floor
    ? [`sentence-length variation ${cv.toFixed(3)}, floor ${floor} (mean ${mean.toFixed(1)} words over ${ss.length} sentences)`]
    : [];
}

// ---------------------------------------------------------------------------
// One entry point over both authorities.
//
// The style register governs Coach's own prose; the AI-writing register extends it
// with the signs catalogued from the Wikipedia page. They share a segmentation and
// a violation shape, so a caller checks a reply once and gets one ranked list.

const SP = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'authorities', 'style-prohibition-register.v1.json'), 'utf8'));
const AW = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'authorities', 'ai-writing-signs-register.v1.json'), 'utf8'));
const MERGED = { ...SP, rules: [...SP.rules, ...AW.rules] };

/** Every violation in one reply, worst first. */
/**
 * SESSION SCOPE. Every detector in the registers scores ONE reply, so a fault that only exists
 * across replies cannot be seen by any of them.
 *
 * MEASURED 2026-08-23 on a live nine-turn interview: five consecutive replies opened with the
 * identical words "Three questions", each carrying exactly three numbered items. The registers
 * returned zero block violations on those nine turns and were right to, reply by reply. The
 * sameness was the whole problem and it lived between the replies, not inside any of them.
 *
 * `priors` is every earlier assistant reply in this session, oldest first.
 */
export function checkSession(draft, priors = []) {
  const found = [];
  const norm = (s) => String(s).trim().toLowerCase().replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim();
  const firstLine = (s) => norm(String(s).trim().split('\n')[0]).slice(0, 40);
  const all = [...priors, draft];

  // 1. The same opening, twice or more.
  const op = firstLine(draft);
  if (op.length >= 10) {
    const same = priors.filter((p) => firstLine(p) === op).length;
    if (same >= 1) {
      found.push({
        rule_id: 'SS-001', class: 'repeated_opening', severity: 'block',
        message: `${same + 1} replies in this session open with the same words: "${String(draft).trim().split('\n')[0].slice(0, 60)}". `
          + 'Open somewhere else: react to what he just said, or ask the question cold with no preamble.',
      });
    }
  }

  // 2. The same structural skeleton every time — a numbered list of the same length, repeatedly.
  const shape = (s) => {
    const n = (String(s).match(/^\s*\d+\.\s/gm) || []).length;
    const b = (String(s).match(/^\s*[-*]\s/gm) || []).length;
    return n ? `numbered:${n}` : (b ? `bulleted:${b}` : 'prose');
  };
  const mine = shape(draft);
  if (mine !== 'prose') {
    const same = priors.filter((p) => shape(p) === mine).length;
    if (same >= 2) {
      found.push({
        rule_id: 'SS-002', class: 'repeated_structure', severity: 'block',
        message: `${same + 1} replies in this session have the identical shape (${mine}). Bill is reading a `
          + 'template. Write this one as plain sentences, or change how many things you put in it.',
      });
    }
  }

  // 3. A phrase of yours becoming a tic across the session.
  const phrases = (s) => {
    const words = norm(s).split(' ');
    const out = new Set();
    for (let i = 0; i + 3 <= words.length; i += 1) out.add(words.slice(i, i + 3).join(' '));
    return out;
  };
  if (priors.length >= 2) {
    const mineP = phrases(draft);
    for (const ph of mineP) {
      if (ph.split(' ').some((w) => w.length < 3)) continue;
      const hits = priors.filter((p) => phrases(p).has(ph)).length;
      if (hits >= 3) {
        found.push({
          rule_id: 'SS-003', class: 'session_tic', severity: 'flag',
          message: `"${ph}" has now appeared in ${hits + 1} replies this session. Say it a different way or not at all.`,
        });
        break;
      }
    }
  }
  return found;
}

export function checkReply(text, ctx = {}) {
  const found = check(text, MERGED, ctx) ?? [];
  const rank = { block: 0, flag: 1 };
  return [...found].sort((a, b) => (rank[a.severity] ?? 2) - (rank[b.severity] ?? 2));
}

export const STYLE_RULE_COUNT = MERGED.rules.length;
